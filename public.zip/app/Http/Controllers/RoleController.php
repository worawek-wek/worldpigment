<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Yajra\DataTables\Facades\DataTables;
use App\Models\Role;
use App\Models\RolePermission;
use App\Models\Emp;

class RoleController extends Controller
{
    public function index()
    {
        return view('role.index');
    }

    public function datatable(Request $request)
    {
        // ⚠ select() ต้องมาก่อน withCount() — ถ้า withCount() มาก่อน select() จะไปล้าง
        // subquery COUNT ที่ withCount เติมไว้ ทำให้ employees_count เป็น NULL ทุกแถว (แก้ 08/09/2569)
        $roles = Role::query()
            ->select(['id', 'name', 'description', 'is_active', 'is_default'])
            ->withCount('employees');

        if ($request->filled('search')) {
            $search = $request->search;
            $roles->where(function ($query) use ($search) {
                $query->where('name', 'LIKE', '%'.$search.'%')
                    ->orWhere('description', 'LIKE', '%'.$search.'%');
            });
        }

        // หมายเหตุ: ไม่ hard-code orderBy ที่นี่แล้ว — ให้ Yajra จัดการเรียงตามที่คลิกหัวคอลัมน์
        // (ลำดับเริ่มต้นตามชื่อ Role ถูกกำหนดเป็นค่า default order ในฝั่ง DataTables ของ role/index)

        $rownum = 0;

        return DataTables::of($roles)
            ->addColumn('rownum', function () use (&$rownum) {
                return ++$rownum;
            })
            ->addColumn('employees_count', function ($role) {
                return $role->employees_count;
            })
            // แสดงชื่อ Role พร้อม badge "ค่าเริ่มต้น" เมื่อ role นี้เป็นค่าเริ่มต้นของพนักงานใหม่
            ->editColumn('name', function ($role) {
                $name = e($role->name);
                if ($role->is_default === 'Y') {
                    $name .= ' <span class="badge bg-label-primary">ค่าเริ่มต้น</span>';
                }
                return $name;
            })
            ->addColumn('status_badge', function ($role) {
                if ($role->is_active === 'Y') {
                    return '<span class="badge bg-label-success">เปิดใช้งาน</span>';
                }
                return '<span class="badge bg-label-secondary">ปิดใช้งาน</span>';
            })
            ->addColumn('btnedit', function ($role) {
                // ปุ่มลบถูกซ่อนไว้ชั่วคราวตามที่ผู้ใช้สั่ง (08/09/2569) — เปิดคืนโดยเอาคอมเมนต์ปุ่ม btn_delete ออก
                // backend (route role.delete + destroy()) ยังอยู่ครบ ไม่ถูกแตะ
                return '<button type="button" class="btn btn-sm btn-icon btn-warning btn_edit me-1" data-id="'.$role->id.'" title="แก้ไข">
                            <i class="ti ti-pencil ti-sm"></i>
                        </button>';
                        // <button type="button" class="btn btn-sm btn-icon btn-danger btn_delete" data-id="'.$role->id.'" title="ลบ">
                        //     <i class="ti ti-trash ti-sm"></i>
                        // </button>
            })
            ->rawColumns(['name', 'status_badge', 'btnedit'])
            ->make(true);
    }

    public function edit(Request $request)
    {
        $id   = $request->id;
        $role = $id ? Role::with('permissions')->find($id) : null;

        $html = view('role.role-form', [
            'role'         => $role,
            'menu'         => config('menu'),
            'selectedKeys' => $role ? $role->menuKeys() : [],
        ])->render();

        return response()->json([
            'status' => 200,
            'data'   => $html,
        ]);
    }

    public function store(Request $request)
    {
        $is_edit = $request->filled('id');

        $validator = Validator::make($request->all(), [
            'name'          => [
                'required', 'string', 'max:255',
                Rule::unique('roles', 'name')->ignore($is_edit ? $request->id : null),
            ],
            'description'   => 'nullable|string|max:255',
            'is_active'     => 'nullable|in:Y,N',
            'is_default'    => 'nullable|in:Y,N',
            'permissions'   => 'nullable|array',
            'permissions.*' => 'string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'errors' => $validator->errors(),
            ]);
        }

        // รับเฉพาะ menu_key ที่มีอยู่จริงใน config/menu.php (กันค่าปลอม)
        $validKeys = $this->allMenuKeys();
        $selected  = array_values(array_intersect((array) $request->permissions, $validKeys));

        // switch ในฟอร์ม: ติ๊ก = ตั้งเป็นค่าเริ่มต้นของพนักงานใหม่ (Y) มีได้ role เดียวในระบบ
        $isDefault = $request->has('is_default');

        $fields = [
            'name'        => $request->name,
            'description' => $request->description,
            'is_active'   => $request->has('is_active') ? 'Y' : 'N',
            'is_default'  => $isDefault ? 'Y' : 'N',
        ];

        try {
            DB::transaction(function () use ($request, $is_edit, $fields, $selected, $isDefault, &$role) {
                if ($is_edit) {
                    $role = Role::find($request->id);
                    if ($role) {
                        $role->update($fields);
                    }
                } else {
                    $role = Role::create($fields);
                }

                // บังคับให้มี role ค่าเริ่มต้นได้แค่ตัวเดียว: เมื่อตั้ง role นี้เป็น default ให้ปลด default ของตัวอื่นทั้งหมด
                if ($role && $isDefault) {
                    Role::where('id', '!=', $role->id)
                        ->where('is_default', 'Y')
                        ->update(['is_default' => 'N']);
                }

                if ($role) {
                    RolePermission::where('role_id', $role->id)->delete();
                    if (!empty($selected)) {
                        $rows = array_map(fn ($key) => [
                            'role_id'  => $role->id,
                            'menu_key' => $key,
                        ], $selected);
                        RolePermission::insert($rows);
                    }
                }
            });
        } catch (\Exception $e) {
            return response()->json([
                'status'  => 500,
                'message' => 'เกิดข้อผิดพลาด: '.$e->getMessage(),
            ]);
        }

        if (empty($role)) {
            return response()->json([
                'status'  => 404,
                'message' => 'ไม่พบ Role ที่ต้องการแก้ไข',
            ]);
        }

        return response()->json([
            'status'  => 200,
            'message' => $is_edit ? 'แก้ไข Role สำเร็จ' : 'เพิ่ม Role สำเร็จ',
        ]);
    }

    public function destroy(Request $request)
    {
        $role = Role::find($request->id);

        if (!$role) {
            return response()->json([
                'status'  => 404,
                'message' => 'ไม่พบ Role ที่ต้องการลบ',
            ]);
        }

        try {
            DB::transaction(function () use ($role) {
                // ปลด role ออกจากพนักงานที่ผูกอยู่ก่อน แล้วค่อยลบ role + สิทธิ์
                Emp::where('role_id', $role->id)->update(['role_id' => null]);
                RolePermission::where('role_id', $role->id)->delete();
                $role->delete();
            });
        } catch (\Exception $e) {
            return response()->json([
                'status'  => 500,
                'message' => 'เกิดข้อผิดพลาด: '.$e->getMessage(),
            ]);
        }

        return response()->json([
            'status'  => 200,
            'message' => 'ลบ Role สำเร็จ',
        ]);
    }

    // รวบรวม key เมนูทั้งหมด (รวม sub_menu ทุกระดับ) ที่เลือกเป็นสิทธิ์ได้ — ข้าม header
    private function allMenuKeys(): array
    {
        $keys = [];
        foreach (config('menu') as $key => $menu) {
            if (isset($menu['type']) && $menu['type'] === 'header') {
                continue;
            }
            $keys[] = $key;
            $this->collectSubMenuKeys($menu, $keys);
        }
        return $keys;
    }

    // เก็บ key ของ sub_menu แบบ recursive (รองรับเมนูซ้อนหลายชั้น)
    private function collectSubMenuKeys(array $menu, array &$keys): void
    {
        if (!isset($menu['sub_menu'])) {
            return;
        }
        foreach ($menu['sub_menu'] as $subKey => $sub) {
            $keys[] = $subKey;
            $this->collectSubMenuKeys($sub, $keys);
        }
    }
}
