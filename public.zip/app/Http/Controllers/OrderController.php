<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Morder;
use App\Models\SubOrder;
use App\Services\ProductPriceService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

/**
 * ใบสั่งซื้อ (O-Order) — แปลงมาจากฟอร์ม Access "บันทึกคำสั่งซื้อ"
 *
 * ตารางที่ใช้ (legacy ทั้งหมด อ่านอย่างเดียวในเฟสนี้):
 *   morder    หัวใบสั่งซื้อ (PK = Orderno)
 *   suborder  รายการในใบสั่งซื้อ (PK = Runno + Orderno)
 *   orderrun  เลขรันของแต่ละประเภทใบสั่ง
 *   naddress  สถานที่ส่งของลูกค้าแต่ละราย (Custno + DVpoint)
 *   ordrem    ข้อความหมายเหตุสำเร็จรูป (dropdown ในตารางรายการ)
 *   customer  ข้อมูลลูกค้า + ค่าตั้งต้นของ RP / CER / PO / MSDS
 *   c_type    ประเภทอุตสาหกรรมของลูกค้า (ปุ่ม itype บนฟอร์มเดิม)
 *   uprice / appvreq / zcustprice / pdprice   ข้อมูลราคาที่โชว์บนฟอร์ม
 */
class OrderController extends Controller
{
    /**
     * ประเภทใบสั่งซื้อ = ตัวอักษร 2 ตัวหน้าของเลขที่ใบสั่ง (radio บนหัวฟอร์ม)
     * ค่า = คอลัมน์เลขรันใน orderrun ที่ประเภทนั้นใช้ (หลายประเภทใช้ตัวรันร่วมกัน เช่น CM/CI ใช้ c)
     */
    private const ORDER_TYPES = [
        'CM' => 'c',  'CI' => 'c',
        'HM' => 'h',  'HI' => 'h',
        'WM' => 'w',  'WI' => 'w',
        'CE' => 'ce', 'CR' => 'CR',
        'HE' => 'he', 'HR' => 'HR',
        'WE' => 'we', 'WR' => 'WR',
    ];

    /** ผังปุ่มบนฟอร์ม Access — 2 แถว แถวละ 6 ประเภท (เรียงตามภาพต้นฉบับ) */
    private const TYPE_ROWS = [
        ['CM', 'CI', 'HM', 'HI', 'WM', 'WI'],
        ['CE', 'CR', 'HE', 'HR', 'WE', 'WR'],
    ];

    /**
     * สถานะการอนุมัติของใบสั่งซื้อ — คอลัมน์ "สถานะ" ในตารางรายการ + ตัวกรอง (19/09/2569)
     *
     * กติกาเดียวกับ OrderApprovalController::approvableQuery():
     *   - ใบจอง R (ตัวอักษรที่ 2 ของ Orderno = R) ไม่ต้องอนุมัติ
     *   - ที่เหลือ: appv = -1 คือ อนุมัติแล้ว · NULL/0 คือ รออนุมัติ
     *     (ข้อมูลจริงมีแค่ -1 กับ NULL — เผื่อ 0 ไว้ให้ตรงกับที่ approve() เขียนได้)
     */
    /**
     * `icon` = ไอคอน tabler ของ badge สถานะบนหัวฟอร์มใบสั่งซื้อ (21/09/2569)
     * — ต้องสื่อความหมายให้ตรงสถานะ (เครื่องหมายถูกใช้ได้เฉพาะ "อนุมัติแล้ว")
     * คอลัมน์ "สถานะ" ในตารางรายการไม่ได้ใช้ key นี้ (ไม่มีไอคอน) จึงไม่กระทบ
     */
    public const APPV_STATUSES = [
        'waiting'  => ['label' => 'รออนุมัติ',    'badge' => 'bg-label-warning',   'icon' => 'ti-clock'],
        'approved' => ['label' => 'อนุมัติแล้ว',   'badge' => 'bg-label-success',   'icon' => 'ti-circle-check'],
        'reserve'  => ['label' => 'ใบจอง',        'badge' => 'bg-label-secondary', 'icon' => 'ti-bookmark'],
    ];

    /**
     * นิพจน์ SQL ของสถานะ — **แหล่งความจริงเดียว** ใช้ทั้งคอลัมน์ที่แสดงและตัวกรอง
     * ถ้าแก้กติกา ต้องแก้ที่นี่ที่เดียว (ไม่งั้นตัวกรองกับสิ่งที่เห็นจะไม่ตรงกัน)
     */
    private const APPV_STATUS_SQL = "CASE
            WHEN SUBSTRING(morder.Orderno, 2, 1) = 'R' THEN 'reserve'
            WHEN morder.appv IS NULL OR morder.appv = 0 THEN 'waiting'
            ELSE 'approved' END";

    /**
     * สถานะอนุมัติของใบเดียว (คืน key ของ APPV_STATUSES) — ใช้ตอนเปิดใบในฟอร์ม (21/09/2569)
     *
     * คิดด้วย APPV_STATUS_SQL ตัวเดียวกับตารางรายการ/ตัวกรอง — **ห้ามเขียนกติกาซ้ำใน PHP**
     * ไม่งั้นสถานะบนฟอร์มกับที่เห็นในตารางจะไม่ตรงกัน
     */
    private static function appvStatusOf(?string $orderno): ?string
    {
        if (!$orderno) {
            return null;
        }

        return DB::table('morder')->where('Orderno', $orderno)
            ->selectRaw(self::APPV_STATUS_SQL . ' as s')
            ->value('s');
    }

    /** คอลัมน์ checkbox ของ Access เก็บ -1 = ติ๊ก, 0/NULL = ไม่ติ๊ก */
    private static function checked($value): bool
    {
        return (int) $value !== 0 && $value !== null;
    }

    // ─────────────────────────────────────────────────────────────
    //  หน้าหลัก + ตารางรายการ
    // ─────────────────────────────────────────────────────────────

    public function index(Request $request)
    {
        $data['page_url']  = 'order';
        $data['type_rows'] = self::TYPE_ROWS;

        // "ผลิตที่" — ค่าที่เคยใช้จริงใน morder (MB / DB / SPP / CP)
        $data['companies'] = DB::table('morder')
            ->whereRaw("TRIM(COALESCE(Company, '')) <> ''")
            ->distinct()
            ->orderBy('Company')
            ->pluck('Company');

        // รหัสพนักงานขาย (morder.supno) — ตัวเลือกของหน้าต่าง "ประมาณการยอดขาย" (15/10/2569)
        $data['sale_codes'] = SalesForecastController::saleCodes();

        // ข้อความหมายเหตุสำเร็จรูปของตารางรายการ
        $data['remarks'] = DB::table('ordrem')->orderBy('rem')->pluck('rem');

        // ค่า "รหัส" (suborder.nold) ที่เคยใช้จริงในระบบ — ใช้เป็นตัวเลือกในตารางรายการ
        $data['nold_options'] = DB::table('suborder')
            ->whereRaw("TRIM(COALESCE(nold, '')) <> ''")
            ->distinct()
            ->orderBy('nold')
            ->pluck('nold');

        // ตัวเลือกของตัวกรอง "สถานะ" (การอนุมัติใบสั่งซื้อ)
        $data['appv_statuses'] = self::APPV_STATUSES;

        // ผู้บันทึก = พนักงานที่ล็อกอินอยู่ (เติมให้อัตโนมัติเมื่อเปิดใบใหม่)
        $data['current_emp'] = optional(Auth::user())->empno;

        // ค่าเริ่มต้นของช่อง "อนุมัติราคาถึง" ในฟอร์มขออนุมัติราคาพิเศษ = วันทำการถัดไป (ข้ามวันหยุด)
        // ต้องมาจาก server เพราะ JS ไม่รู้จักวันหยุดใน tb_holiday — ดู PriceApprovalController::defaultValidTo()
        $data['default_valid_to'] = PriceApprovalController::defaultValidTo();

        // ลูกค้าที่ต้องผ่านฟอร์มตรวจราคาเม็ด CP ก่อนบันทึก (16/10/2569)
        $data['cp_check_customers'] = config('order.cp_check_customers', []);

        return view('order.index', $data);
    }

    /**
     * GET — ตารางรายการใบสั่งซื้อ (HTML partial ใส่ #table-data)
     */
    public function datatable(Request $request)
    {
        // whitelist การเรียง: key หัวตาราง → คอลัมน์/alias จริง (กัน SQL injection)
        $sortable = [
            'Mdate'      => 'morder.Mdate',
            'Orderno'    => 'morder.Orderno',
            'Custno'     => 'morder.Custno',
            'Company'    => 'morder.Company',
            'item_count' => 'agg.item_count',
            'total_prod' => 'agg.total_prod',
        ];
        $sortKey = (string) $request->sort_col;
        $sortKey = isset($sortable[$sortKey]) ? $sortKey : 'Mdate';   // default = วันที่สั่ง
        $sortDir = strtolower((string) $request->sort_dir) === 'asc' ? 'asc' : 'desc';

        // สรุปรายการต่อ 1 ใบสั่ง — คำนวณครั้งเดียวแล้ว join (เร็วกว่า correlated subquery ตอน ORDER BY)
        $agg = DB::table('suborder')
            ->select('Orderno')
            ->selectRaw('COUNT(*) as item_count')
            ->selectRaw('COALESCE(SUM(Production), 0) as total_prod')
            ->selectRaw('COALESCE(SUM(Stock), 0) as total_stock')
            ->selectRaw('MIN(senddate) as first_senddate')
            ->selectRaw("GROUP_CONCAT(DISTINCT NULLIF(TRIM(Itemno), '') SEPARATOR ', ') as itemno_list")
            ->groupBy('Orderno');

        $results = Morder::query()
            ->leftJoin('customer as c', 'morder.Custno', '=', 'c.code')
            ->leftJoinSub($agg, 'agg', 'agg.Orderno', '=', 'morder.Orderno')
            ->select('morder.*', 'c.name as cust_name')
            ->selectRaw('COALESCE(agg.item_count, 0) as item_count')
            ->selectRaw('COALESCE(agg.total_prod, 0) as total_prod')
            ->selectRaw('COALESCE(agg.total_stock, 0) as total_stock')
            ->addSelect('agg.first_senddate', 'agg.itemno_list')
            // สถานะการอนุมัติ — คิดที่ SQL ด้วยนิพจน์ตัวเดียวกับที่ตัวกรองใช้ (19/09/2569)
            ->selectRaw(self::APPV_STATUS_SQL . ' as appv_status')
            ->orderBy($sortable[$sortKey], $sortDir);

        // เรียงรองด้วยเลขที่ใบสั่ง ให้ลำดับคงที่เมื่อค่าคอลัมน์หลักซ้ำกัน
        if ($sortable[$sortKey] !== 'morder.Orderno') {
            $results->orderBy('morder.Orderno', 'desc');
        }

        $this->applyFilters($results, $request);

        $limit = $request->input('limit') ?: 15;
        $results = $results->paginate($limit);

        $data['list_data']     = $results;
        $data['sort_col']      = $sortKey;
        $data['sort_dir']      = $sortDir;
        $data['appv_statuses'] = self::APPV_STATUSES;   // ป้าย/สี badge ของคอลัมน์สถานะ

        return view('order.table', $data);
    }

    /** ตัวกรองของหน้ารายการ */
    private function applyFilters($query, Request $request): void
    {
        // ค้นหารวมช่องเดียว: เลขที่ใบสั่ง / P.O. / รหัสลูกค้า / ชื่อลูกค้า / รหัสสินค้าในใบ
        // ⚠ รหัสสินค้ายังค้นจากช่องนี้ได้เหมือนเดิม — ช่อง "รหัสสินค้า" ที่แยกออกมา (16/09/2569)
        //   เป็นช่องเพิ่ม ไม่ได้ย้ายออกจากช่องนี้
        if ($search = trim((string) $request->input('search'))) {
            $like = '%' . $search . '%';
            $query->where(function ($q) use ($like) {
                $q->where('morder.Orderno', 'like', $like)
                    ->orWhere('morder.PO', 'like', $like)
                    ->orWhere('morder.Custno', 'like', $like)
                    ->orWhere('morder.Custname', 'like', $like)
                    ->orWhere('c.name', 'like', $like)
                    ->orWhereExists(function ($sub) use ($like) {
                        $sub->from('suborder')
                            ->whereColumn('suborder.Orderno', 'morder.Orderno')
                            ->where('suborder.Itemno', 'like', $like);
                    });
            });
        }

        // ค้นหาด้วยรหัสสินค้าในใบ (suborder.Itemno) — ช่องแยกของตัวเอง (16/09/2569)
        if ($itemno = trim((string) $request->input('itemno'))) {
            $query->whereExists(function ($sub) use ($itemno) {
                $sub->from('suborder')
                    ->whereColumn('suborder.Orderno', 'morder.Orderno')
                    ->where('suborder.Itemno', 'like', '%' . $itemno . '%');
            });
        }

        // ประเภทใบสั่ง = 2 ตัวอักษรหน้าเลขที่
        $type = strtoupper((string) $request->input('order_type'));
        if (isset(self::ORDER_TYPES[$type])) {
            $query->where('morder.Orderno', 'like', $type . '%');
        }

        // ผลิตที่
        if ($company = trim((string) $request->input('company'))) {
            $query->where('morder.Company', $company);
        }

        // สถานะการอนุมัติ — เทียบกับนิพจน์ตัวเดียวกับที่ใช้คิดคอลัมน์ "สถานะ" (19/09/2569)
        // ⇒ สิ่งที่กรองได้ตรงกับ badge ที่เห็นในตารางเสมอ
        $appvStatus = (string) $request->input('appv_status');
        if (isset(self::APPV_STATUSES[$appvStatus])) {
            $query->whereRaw(self::APPV_STATUS_SQL . ' = ?', [$appvStatus]);
        }

        // ช่วงวันที่สั่ง (ช่องกรอกเป็น d/m/Y จาก flatpickr)
        if ($from = $this->parseDate($request->input('date_from'))) {
            $query->whereDate('morder.Mdate', '>=', $from);
        }
        if ($to = $this->parseDate($request->input('date_to'))) {
            $query->whereDate('morder.Mdate', '<=', $to);
        }
    }

    /** แปลงวันที่จากช่องกรอก d/m/Y → Y-m-d (ค่าว่าง/รูปแบบผิด = null) */
    private function parseDate($value): ?string
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        if (preg_match('#^(\d{1,2})/(\d{1,2})/(\d{4})$#', $value, $m)) {
            return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
        }
        if (preg_match('#^\d{4}-\d{2}-\d{2}#', $value)) {
            return substr($value, 0, 10);
        }

        return null;
    }

    // ─────────────────────────────────────────────────────────────
    //  ฟอร์มบันทึกใบสั่งซื้อ
    // ─────────────────────────────────────────────────────────────

    /**
     * GET — ข้อมูลทั้งใบสำหรับเติมฟอร์ม (JSON)
     *   ?orderno=WM23946
     */
    public function form(Request $request)
    {
        $orderno = trim((string) $request->query('orderno', ''));
        if ($orderno === '') {
            return response()->json(['found' => false]);
        }

        $order = Morder::where('Orderno', $orderno)->first();
        if (!$order) {
            return response()->json(['found' => false]);
        }

        $items = SubOrder::where('Orderno', $orderno)
            ->orderBy('Runno')
            ->get();

        // รหัสสินค้าหลักของใบ (ฟอร์มเดิมโชว์ช่องเดียวมุมขวาบน) = รหัสแรกที่พบในรายการ
        $itemno = optional($items->first(function ($r) {
            return trim((string) $r->Itemno) !== '';
        }))->Itemno;

        return response()->json([
            'found'     => true,
            'order'     => $this->orderPayload($order),
            'items'     => $items->map(fn ($r) => $this->itemPayload($r))->values(),
            'customer'  => $this->customerPayload($order->Custno),
            'dvpoints'  => $this->dvpoints($order->Custno),
            'itemno'    => $itemno,
            'price'     => $this->priceData($order->Custno, $itemno, $order->netqty),
        ]);
    }

    /** หัวใบสั่งซื้อ → รูปแบบที่ฟอร์มใช้ (แปลง checkbox แบบ Access, ตัดเวลาออกจากวันที่) */
    private function orderPayload(Morder $order): array
    {
        return [
            'Orderno'  => $order->Orderno,
            'type'     => strtoupper(substr((string) $order->Orderno, 0, 2)),
            'Mdate'    => $order->Mdate,
            'Company'  => $order->Company,
            'PO'       => $order->PO,
            'Custno'   => $order->Custno,
            'Custname' => $order->Custname,
            'Emp'      => $order->Emp,
            'supno'    => $order->supno,
            'DVpoint'  => $order->DVpoint,
            'RsvNo'    => $order->RsvNo,
            'netqty'   => $order->netqty,
            'price'    => $order->price,
            // อนุมัติใบสั่งซื้อแล้วหรือยัง — ฝั่งจอใช้ล็อกช่อง "ราคาขาย" (21/09/2569)
            'appv'     => self::checked($order->appv),
            // สถานะอนุมัติ (key ของ APPV_STATUSES) + เวลาที่อนุมัติ — ช่อง "สถานะ" บนฟอร์ม (21/09/2569)
            'appv_status' => self::appvStatusOf($order->Orderno),
            'appvDT'      => $order->appvDT,
            // กรณีสั่งทำสต๊อก
            'sendend'  => $order->sendend,
            'SendCust' => $order->SendCust,
            'HMStore'  => $order->HMStore,
            'sendmth'  => $order->sendmth,
            // checkbox (Access เก็บ -1 = ติ๊ก)
            'Send'     => self::checked($order->Send),
            'RP'       => self::checked($order->RP),
            'Spec'     => self::checked($order->Spec),
            'Cer'      => self::checked($order->Cer),
            'MSDS'     => self::checked($order->MSDS),
            // Require Document — ติ๊ก + ข้อความเอกสารที่ต้องใช้ (15/10/2569)
            'ReqDoc'    => self::checked($order->ReqDoc ?? null),
            'ReqDocRem' => $order->ReqDocRem ?? null,
            // ประเภทสินค้าที่สั่ง = key จาก config/order.php → itypes
            'itype'    => $order->itype,
        ];
    }

    /** 1 รายการในตารางล่างของฟอร์ม */
    private function itemPayload(SubOrder $row): array
    {
        return [
            'Runno'      => $row->Runno,
            'Itemno'     => $row->Itemno,
            'nold'       => $row->nold,   // ช่อง "รหัส" — เดิมไม่ได้ส่งกลับ เปิดใบแล้วว่าง บันทึกซ้ำจึงทับเป็นค่าว่าง (แก้ 12/09/2569)
            'prodname'   => $row->prodname,
            'Lotno'      => $row->Lotno,
            'Stock'      => $row->Stock,
            'Production' => $row->Production,
            'custwant'   => $row->custwant,
            'senddate'   => $row->senddate,
            'EndP'       => $row->EndP,
            'DVDate'     => $row->DVDate,
            'outno'      => $row->outno,
            'Remark'     => $row->Remark,
        ];
    }

    /**
     * GET — ค้นลูกค้าจากรหัส (เติมชื่อ + สถานที่ส่ง + ค่าตั้งต้น RP/CER บนฟอร์ม)
     */
    public function customerLookup($code)
    {
        $cust = $this->customerPayload($code);

        if (!$cust) {
            return response()->json(['found' => false]);
        }

        return response()->json([
            'found'    => true,
            'customer' => $cust,
            'dvpoints' => $this->dvpoints($code),
        ]);
    }

    /** ข้อมูลลูกค้า + ค่าตั้งต้นของ checkbox บนฟอร์ม (null ถ้าไม่พบ) */
    private function customerPayload($code): ?array
    {
        $code = trim((string) $code);
        if ($code === '') {
            return null;
        }

        $cust = DB::table('customer')->where('code', $code)->first();
        if (!$cust) {
            return null;
        }

        // ประเภทอุตสาหกรรมของลูกค้า (ปุ่ม itype บนฟอร์ม Access)
        $typeName = $cust->type
            ? DB::table('c_type')->where('type', $cust->type)->value('t_namee')
            : null;

        return [
            'code'      => $cust->code,
            'name'      => $cust->name,
            'nameEN'    => $cust->nameEN,
            'sale'      => $cust->sale,     // รหัสผู้ขายประจำลูกค้า → เติมช่อง "รหัสผู้ขาย" (morder.supno)
            'term'      => $cust->term,
            'type'      => $cust->type,
            'type_name' => $typeName,
            'RP'        => self::checked($cust->RP),
            'CER'       => self::checked($cust->CER),
            'PO'        => self::checked($cust->PO),
            'MSDS'      => self::checked($cust->MSDS),
            // สถานะ Blacklist — ฝั่งจอใช้เตือนแล้วล้างรหัสลูกค้าทิ้ง (19/09/2569)
            'is_black'  => self::isBlacklisted($cust->black),
            'blackrem'  => $cust->blackrem,
            'blackdate' => $cust->blackdate,
        ];
    }

    /**
     * ลูกค้าติด Blacklist หรือไม่ — **`customer.black` ไม่ใช่ 0** (ผู้ใช้ยืนยัน 19/09/2569)
     *
     * ⚠ ไม่ใช่แค่ `-1` อย่างที่เคยเข้าใจ — ค่าจริงในตารางมี -3 (2,734 ราย) · 0 (1,088) ·
     *   -1 (220) · 2 (49) · 5 (2) · NULL (1)
     * ⚠ **NULL ถือว่า "ไม่ติด"** (ข้อมูลว่าง ไม่ใช่การขึ้นบัญชีดำ) — ยังไม่ได้ยืนยันกับผู้ใช้
     */
    public static function isBlacklisted($black): bool   // public — ฟอร์ม MK (PriceApprovalController) ใช้เกณฑ์เดียวกัน (05/10/2569)
    {
        return $black !== null && (int) $black !== 0;
    }

    /** สถานที่ส่งของลูกค้ารายนี้ (dropdown "สถานที่ส่ง") */
    private function dvpoints($custno): array
    {
        $custno = trim((string) $custno);
        if ($custno === '') {
            return [];
        }

        return DB::table('naddress')
            ->where('Custno', $custno)
            ->orderBy('DVpoint')
            ->pluck('DVpoint')
            ->all();
    }

    /**
     * POST — เพิ่ม "สถานที่ส่ง" ให้ลูกค้ารายนี้จากฟอร์มใบสั่งซื้อ (19/09/2569)
     *
     * เขียนลง `naddress` (PK = Custno + DVpoint) ซึ่งเป็น**ตารางเดียวกับที่เมนู "ฐานข้อมูลลูกค้า" ดูแล**
     * ⇒ ค่าที่เพิ่มจากตรงนี้จะไปโผล่ในฟอร์มลูกค้าด้วย (ตั้งใจ — เป็นสถานที่ส่งประจำของลูกค้า)
     *
     * ⚠ มีอยู่แล้ว = ไม่ error แต่ตอบกลับพร้อมธง `existed` ให้ฝั่งจอเลือกตัวนั้นให้เลย
     */
    public function addDvpoint(Request $request)
    {
        $custno  = trim((string) $request->input('custno'));
        $dvpoint = trim((string) $request->input('dvpoint'));

        if ($custno === '') {
            return response()->json(['status' => false, 'message' => 'ต้องระบุลูกค้าก่อนเพิ่มสถานที่ส่ง'], 422);
        }

        if (!DB::table('customer')->where('code', $custno)->exists()) {
            return response()->json(['status' => false, 'message' => 'ไม่พบรหัสลูกค้า '.$custno], 422);
        }

        if ($dvpoint === '') {
            return response()->json(['status' => false, 'message' => 'กรุณากรอกสถานที่ส่ง'], 422);
        }

        /* naddress.DVpoint เป็น varchar สั้น (ตอนนี้ 20) — อ่านความยาวจริงจาก schema ไม่ hardcode
           ⚠ ที่นี่ "ตีกลับให้ผู้ใช้แก้เอง" ไม่ใช่ตัดเงียบ ๆ แบบ clampToColumns() ที่ใช้ตอนบันทึกใบสั่งซื้อ
             เพราะอันนั้นเป็นค่าที่ระบบเติมให้ ส่วนอันนี้ผู้ใช้พิมพ์เองและกำลังสร้างค่าใหม่ในตาราง master */
        $max = 20;
        foreach (DB::select("SHOW COLUMNS FROM naddress LIKE 'DVpoint'") as $col) {
            if (preg_match('/^(?:var)?char\((\d+)\)/i', $col->Type, $m)) {
                $max = (int) $m[1];
            }
        }

        if (mb_strlen($dvpoint) > $max) {
            return response()->json([
                'status'  => false,
                'message' => 'สถานที่ส่งยาวเกิน '.$max.' ตัวอักษร (กรอกมา '.mb_strlen($dvpoint).')',
            ], 422);
        }

        $existed = DB::table('naddress')
            ->where(['Custno' => $custno, 'DVpoint' => $dvpoint])
            ->exists();

        if (!$existed) {
            DB::table('naddress')->insert(['Custno' => $custno, 'DVpoint' => $dvpoint]);
        }

        return response()->json([
            'status'   => true,
            'existed'  => $existed,
            'message'  => $existed ? 'สถานที่ส่งนี้มีอยู่แล้ว — เลือกให้แล้ว' : 'เพิ่มสถานที่ส่งเรียบร้อย',
            'dvpoint'  => $dvpoint,
            'dvpoints' => $this->dvpoints($custno),
        ]);
    }

    /**
     * GET — ข้อมูลราคาของคู่ (ลูกค้า, รหัสสินค้า) สำหรับกล่องราคาบนฟอร์ม
     *   ?custno=41008&itemno=CP-WPIN[NH900L]
     */
    public function priceInfo(Request $request)
    {
        return response()->json($this->priceData(
            $request->query('custno'),
            $request->query('itemno'),
            $request->query('weight')
        ));
    }

    /**
     * กล่องราคาบนฟอร์ม
     *
     * ราคา 1/2/3 มาจาก **ระบบกำหนดราคา** (`ProductPriceService` ตัวเดียวกับที่หน้า
     * "ค้นหาราคาสินค้า" ใน /saleinfo ใช้) — คำนวณจากราคาทุนใน `access_pdprice`
     * ตามเงื่อนไขที่จับคู่ด้วยตัวขึ้นต้นรหัส: ราคา1 = ทุน × mul ÷ div + add,
     * ราคา2 = ราคา1 × 1.14, ราคา3 = ราคา2 × 1.30 (ตัวคูณอยู่ที่ `product_price.tier`)
     * → **อ้างอิงจากรหัสสินค้าอย่างเดียว ไม่เกี่ยวกับลูกค้า**
     *
     *   price2      ราคาช่อง 2           = ราคาขาย 2
     *   min_price    ราคาต้องไม่ต่ำกว่า    = ราคาขาย 2
     *   cost_price   ราคาทุน              = ราคาทุนที่ใช้คำนวณ
     *
     * ส่วนที่ผูกกับลูกค้า (ใช้ custno ด้วย):
     *   fixed_price  ราคาที่กำหนดไว้      uprice.PRICE (เมนู "กำหนดราคา") — 08/10/2569 เดิมเป็นราคาขาย 1
     *   appv_price   ราคาอนุมัติ          appvreq.price
     *   valid_to     ยืนราคาถึง           zcustprice.enddate
     *
     * หมายเหตุ: "ราคาขาย" (morder.price) ผู้ใช้พิมพ์เอง ไม่ได้ดึงมาจากที่นี่
     */
    private function priceData($custno, $itemno, $weight = null): array
    {
        $custno = trim((string) $custno);
        $itemno = trim((string) $itemno);

        $empty = [
            'found'       => false, 'message' => null, 'others' => [],
            'fixed_price' => null, 'fixed_src' => null,
            'price1'      => null, 'price2' => null, 'price3' => null,
            'appv_price'  => null, 'appv'   => null, 'valid_to' => null,
            'cost_price'  => null, 'remark' => null,
            'group'       => null, 'min_price' => null, 'min_from' => null,
            'min_rate'    => null,
        ];

        // ต้องมีรหัสสินค้าเป็นอย่างน้อย — ราคา 1/2/3 คำนวณจากรหัสสินค้าล้วน ไม่ต้องรู้ลูกค้า
        if ($itemno === '') {
            return $empty + ['message' => 'ยังไม่ได้กรอกรหัสสินค้าในตารางรายการ'];
        }

        // ราคาที่ตกลงไว้กับลูกค้ารายนี้
        $uprice = $custno === '' ? null : DB::table('uprice')
            ->where('CustNo', $custno)
            ->where('ITEMNO', $itemno)
            ->orderByDesc('DATE')
            ->first(['PRICE', 'REM2']);

        // ใบขออนุมัติราคาล่าสุดของคู่นี้ (ใช้เฉพาะ "ราคาอนุมัติ")
        $appv = $custno === '' ? null : DB::table('appvreq')
            ->where('custno', $custno)
            ->where('itemno', $itemno)
            ->orderByDesc('ReqDate')
            ->first(['price', 'price1', 'price2', 'price3', 'Appv']);

        // วันสิ้นสุดการยืนราคา
        $zcust = $custno === '' ? null : DB::table('zcustprice')
            ->where('custno', $custno)
            ->where('colorno', $itemno)
            ->first(['exprice', 'enddate']);

        // ── ราคา 1/2/3 จากระบบกำหนดราคา (ตัวเดียวกับหน้า "ค้นหาราคาสินค้า" ใน /saleinfo) ──
        $calc   = app(ProductPriceService::class)->lookup($itemno);
        $prices = $calc['prices'] ?? null;

        // กลุ่มราคาตามปริมาณที่สั่ง (A ≥1,000 / B ≥500 / C ต่ำกว่า 500) — แสดงประกอบเฉย ๆ
        $group = PriceApprovalController::groupOf($weight);

        // ขั้นต่ำ = ค่าของกลุ่มราคานั้นจาก zcolorrate (rate_A / rate_B / rate_C ของรหัสสินค้า) — 12/09/2569
        $colorRate = DB::table('zcolorrate')->where('colorno', $itemno)->first(['rate_A', 'rate_B', 'rate_C']);
        $minRate   = ($group && $colorRate) ? $colorRate->{'rate_' . $group['group']} : null;

        // คำนวณไม่ได้ → บอกเหตุผลที่ระบบกำหนดราคาให้มา (ไม่พบราคาทุน / ไม่มีเงื่อนไขรองรับ ฯลฯ)
        $message = $prices ? null : ($calc['reason'] ?? 'คำนวณราคาไม่ได้');

        /* "ราคาต้องไม่ต่ำกว่า" ต้องเป็นตัวเดียวกับที่ checkPriceFloor() ใช้จริงตอนบันทึก (28/08/2569)
           มีราคาอนุมัติที่ยังไม่เลยวันยืนราคา → ใช้ราคาอนุมัติ
           ไม่มี แต่รหัสอยู่ในตารางกลุ่มราคา   → ใช้ราคาของกลุ่มนั้น (12/09/2569)
           ไม่มีทั้งคู่                        → ราคาช่อง 2 เหมือนเดิม */
        $approvedFloor = $this->approvedFloor($custno, $itemno);

        if ($approvedFloor) {
            $minPrice = round($approvedFloor->price, 2);
            $minFrom  = 'approved';
        } elseif ($minRate !== null && $minRate != 0) {
            $minPrice = round((float) $minRate, 2);
            $minFrom  = 'color_rate';
        } else {
            $minPrice = $prices['price_2'] ?? null;
            $minFrom  = 'price_2';
        }

        // ต้องไม่ต่ำกว่า "ราคาที่กำหนดไว้" ด้วย — ใช้ค่าที่สูงกว่า (15/10/2569 ตรงกับ checkPriceFloor())
        $fixedFloor = $this->fixedPriceFloor($custno, $itemno);
        if ($fixedFloor !== null && ($minPrice === null || $fixedFloor > $minPrice)) {
            $minPrice = round($fixedFloor, 2);
            $minFrom  = 'fixed';
        }

        return [
            'found'       => (bool) $prices,
            'message'     => $message,
            'others'      => [],
            'group'       => $group ? $group['group'] : null,
            'group_label' => $group ? $group['label'] : null,
            'min_rate'    => $minRate,
            // ราคาที่กำหนดไว้ = ราคาจากเมนู "กำหนดราคา" (uprice.PRICE ของคู่ ลูกค้า+เบอร์ แถวล่าสุด) — 08/10/2569
            // เดิมใช้ราคาขาย 1 ที่คำนวณจากราคาทุน · ราคาช่อง 2 = ราคาขาย 2 เหมือนเดิม
            'fixed_price' => $uprice->PRICE ?? null,
            'price2'      => $prices['price_2'] ?? null,
            // ราคาต้องไม่ต่ำกว่า = ราคาอนุมัติ → ราคากลุ่ม (zcolorrate) → ราคาช่อง 2
            'min_price'   => $minPrice,
            'min_from'    => $minFrom,
            'price1'      => $prices['price_1'] ?? null,
            'price3'      => $prices['price_3'] ?? null,
            // ที่มาของราคา — ราคาทุน + เงื่อนไขที่จับคู่ได้ + สูตร (โชว์ใต้กล่องราคา)
            'cost_price'  => $calc['base_price'] ?? null,
            'rule_label'  => $calc['rule']['label'] ?? null,
            'formula'     => isset($calc['rule'])
                ? '× ' . $calc['rule']['mul'] . ' ÷ ' . $calc['rule']['div'] . ' + ' . $calc['rule']['add']
                : null,
            // ส่วนที่ผูกกับลูกค้า
            'appv_price'  => $appv->price ?? null,
            'appv'        => isset($appv->Appv) ? self::checked($appv->Appv) : null,
            'valid_to'    => $zcust->enddate ?? null,
            'remark'      => $uprice->REM2 ?? null,
        ];
    }

    /**
     * GET — เลขที่ใบสั่งถัดไปของประเภทที่เลือก (ปุ่ม "เพิ่มใบสั่งซื้อใหม่")
     *   ?type=WM  →  { orderno: "WM24565" }
     *
     * ค่าใน orderrun คือ "เลขล่าสุดที่ใช้ไปแล้ว" → เลขถัดไป = ค่านั้น + 1
     * แล้วข้ามเลขที่มีใบสั่งอยู่จริง (เผื่อค่าใน orderrun ไม่ตรงกับข้อมูลจริง)
     *
     * เป็นแค่ "เลขที่คาดว่าจะได้" ไว้โชว์บนฟอร์ม — ยังไม่เดินเลขจริง
     * การเดินเลขจริงต้องทำตอนบันทึก ซึ่งยังไม่เปิดใช้งานในเฟสนี้
     */
    public function nextOrderno(Request $request)
    {
        $type = strtoupper(trim((string) $request->query('type', '')));
        if (!isset(self::ORDER_TYPES[$type])) {
            return response()->json(['found' => false]);
        }

        $column   = self::ORDER_TYPES[$type];
        $run      = DB::table('orderrun')->first();
        // ประเภทอื่นที่ใช้เลขรันคอลัมน์เดียวกัน (เช่น CM กับ CI ใช้ c ร่วมกัน) — ต้องไม่ชนกัน
        $siblings = array_keys(self::ORDER_TYPES, $column, true);

        $next = $run ? (int) ($run->{$column} ?? 0) : 0;
        do {
            $next++;
            $taken = DB::table('morder')
                ->whereIn('Orderno', array_map(fn ($p) => $p . $next, $siblings))
                ->exists();
        } while ($taken);

        return response()->json([
            'found'   => true,
            'type'    => $type,
            'run'     => $next,
            'orderno' => $type . $next,
        ]);
    }

    /**
     * GET — ค้นข้อมูลสินค้าจากรหัสที่กรอกในตารางรายการ
     *   ?itemno=CP8F247B&custno=40028
     *
     * คืนชื่อสินค้า + หมายเหตุ (uprice.Label) ไว้เติมให้อัตโนมัติ + คำเตือน "ต้อง Match ใหม่"
     * (ฟอร์มเดิมขึ้นแถบแดง "สีที่สั่งซื้อล่าสุดเกิน 3 ปี จะต้อง Match ใหม่")
     */
    public function itemLookup(Request $request)
    {
        $itemno = trim((string) $request->query('itemno', ''));
        $custno = trim((string) $request->query('custno', ''));
        if ($itemno === '') {
            return response()->json(['found' => false]);
        }

        // แถวราคาที่ใช้อ้างอิง — เบอร์เดียวกันของคนละลูกค้า Label ต่างกันได้ (1,177 จาก 36,432 เบอร์)
        // จึงเอาแถวของลูกค้ารายนี้ก่อน ไม่มีค่อยใช้แถวล่าสุดของลูกค้าใดก็ได้
        $up = null;
        if ($custno !== '') {
            $up = DB::table('uprice')
                ->where('ITEMNO', $itemno)
                ->where('CustNo', $custno)
                ->orderByDesc('DATE')
                ->first(['Label', 'PackRem', 'st_code']);
        }
        if (!$up) {
            $up = DB::table('uprice')
                ->where('ITEMNO', $itemno)
                ->orderByDesc('DATE')
                ->first(['Label', 'PackRem', 'st_code']);
        }

        // ชื่อสินค้า — ใช้ชื่อที่เคยบันทึกไว้ในใบสั่งก่อนหน้าเป็นหลัก ไม่มีค่อยดูจากตารางราคา
        $prodname = DB::table('suborder')
            ->where('Itemno', $itemno)
            ->whereRaw("TRIM(COALESCE(prodname, '')) <> ''")
            ->orderByDesc('Runno')
            ->value('prodname');

        if (!$prodname) {
            $prodname = $up->Label ?? $up->PackRem ?? $up->st_code ?? null;
        }

        // หมายเหตุของรายการ (suborder.Remark) — เติมจาก uprice.Label ให้เป็นค่าตั้งต้น
        $remark = trim((string) ($up->Label ?? ''));

        /* ใบก่อนหน้าของ "ลูกค้ารายนี้" ที่สั่งเบอร์นี้ — 15/10/2569 ตามที่ผู้ใช้สั่ง (เดิมนับทุกลูกค้า)
           ยึด "วันที่" ของใบที่เปิดอยู่ (mdate ที่ฟอร์มส่งมา, ไม่ส่ง = ตอนนี้) เป็นจุดเทียบ:
             - นับเฉพาะใบที่วันที่ก่อนหน้าวันนั้น และไม่ใช่ใบที่เปิดอยู่ (orderno)
             - เกิน 3 ปีนับย้อนจากวันนั้น
           ยังไม่ระบุลูกค้า = ยังตัดสินไม่ได้ ไม่ขึ้นเตือน */
        $refDate = Carbon::parse($this->parseDateTime($request->query('mdate')) ?? now());
        $orderno = trim((string) $request->query('orderno', ''));

        $lastDate = $custno === '' ? null : DB::table('suborder')
            ->join('morder', 'morder.Orderno', '=', 'suborder.Orderno')
            ->where('suborder.Itemno', $itemno)
            ->where('morder.Custno', $custno)
            ->when($orderno !== '', fn ($q) => $q->where('morder.Orderno', '<>', $orderno))
            ->where('morder.Mdate', '<', $refDate->format('Y-m-d H:i:s'))
            ->max('morder.Mdate');

        return response()->json([
            'found'           => (bool) ($prodname || $lastDate),
            'itemno'          => $itemno,
            'prodname'        => $prodname,
            'remark'          => $remark !== '' ? $remark : null,
            'last_order_date' => $lastDate,
            // ลูกค้ารายนี้สั่งเบอร์นี้ครั้งล่าสุดเกิน 3 ปี (หรือไม่เคยสั่งเลย) → ต้อง Match ใหม่
            'need_match'      => $custno !== ''
                && (!$lastDate || Carbon::parse($lastDate)->lt($refDate->copy()->subYears(3))),
        ]);
    }

    // ─────────────────────────────────────────────────────────────
    //  บันทึกใบสั่งซื้อ
    // ─────────────────────────────────────────────────────────────

    /**
     * POST — ปุ่ม "เพิ่มใบสั่งซื้อใหม่" ในฟอร์ม: สร้างใบสั่งซื้อทันที (12/09/2569)
     *   type=WM  →  { status: true, orderno: "WM24565" }
     *
     * ออกเลขที่จาก orderrun แล้ว insert morder เลย (แบบเดียวกับ save() โหมด insert)
     * เพื่อไม่ให้เลขที่ชนกันเมื่อหลายคนเปิดฟอร์มพร้อมกัน — จากนั้นฟอร์มบันทึกใบนี้ด้วยโหมด update
     */
    public function create(Request $request)
    {
        $type = strtoupper(trim((string) $request->input('type')));
        if (!isset(self::ORDER_TYPES[$type])) {
            return response()->json(['status' => false, 'message' => 'ประเภทใบสั่งไม่ถูกต้อง'], 422);
        }

        try {
            $orderno = DB::transaction(function () use ($type) {
                $orderno = $this->allocateOrderno($type);
                DB::table('morder')->insert([
                    'Orderno' => $orderno,
                    'Mdate'   => now(),
                    'Emp'     => $this->nullIfBlank(optional(Auth::user())->empno),
                ]);

                return $orderno;
            });
        } catch (\Throwable $e) {
            return response()->json([
                'status'  => false,
                'message' => 'สร้างใบสั่งซื้อไม่สำเร็จ: ' . $e->getMessage(),
            ], 500);
        }

        return response()->json([
            'status'  => true,
            'message' => 'สร้างใบสั่งซื้อใหม่เรียบร้อย',
            'orderno' => $orderno,
        ]);
    }

    /**
     * POST — บันทึกใบสั่งซื้อ (สร้างใหม่ / แก้ไขใบเดิม)
     *
     * insert: จองเลขที่ใบสั่งจาก orderrun ในทรานแซกชันเดียวกับการบันทึก
     *         และปล่อย appv ว่างไว้ → ใบจะไปเข้าคิวอนุมัติเอง (ดู OrderApprovalController)
     * update: ไม่แตะเลขที่ใบสั่ง, วันที่เปิดใบ และสถานะอนุมัติ (appv / appvDT)
     */
    public function save(Request $request)
    {
        $mode = $request->input('mode') === 'update' ? 'update' : 'insert';

        $rules = [
            'Custno' => 'required|string|max:10',
            'items'  => 'required|array|min:1',
        ];
        $rules[$mode === 'insert' ? 'order_type' : 'Orderno'] = 'required|string';

        $validator = Validator::make($request->all(), $rules, [
            'Custno.required'     => 'ต้องระบุรหัสลูกค้า',
            'items.required'      => 'ต้องมีรายการสินค้าอย่างน้อย 1 รายการ',
            'items.min'           => 'ต้องมีรายการสินค้าอย่างน้อย 1 รายการ',
            'order_type.required' => 'ต้องเลือกประเภทใบสั่ง',
            'Orderno.required'    => 'ไม่พบเลขที่ใบสั่งที่จะแก้ไข',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => false, 'message' => $validator->errors()->first()], 422);
        }

        $custno = trim((string) $request->input('Custno'));
        $cust   = DB::table('customer')->where('code', $custno)->first(['code', 'name', 'type']);
        if (!$cust) {
            return response()->json(['status' => false, 'message' => 'ไม่พบรหัสลูกค้า ' . $custno], 422);
        }

        // แถวที่ยังไม่กรอกรหัสสินค้า = แถวเปล่า ข้ามไป
        $items = array_values(array_filter(
            (array) $request->input('items', []),
            fn ($row) => trim((string) ($row['Itemno'] ?? '')) !== ''
        ));
        if (empty($items)) {
            return response()->json(['status' => false, 'message' => 'ต้องกรอกรหัสสินค้าอย่างน้อย 1 รายการ'], 422);
        }

        $type = strtoupper(trim((string) $request->input('order_type')));
        if ($mode === 'insert' && !isset(self::ORDER_TYPES[$type])) {
            return response()->json(['status' => false, 'message' => 'ประเภทใบสั่งไม่ถูกต้อง'], 422);
        }

        /* ── ด่าน itype: ใบที่ขึ้นต้นด้วย W ต้องมี itype — ปิดไว้ชั่วคราว (29/08/2569) ──
         *
         * โค้ดข้างล่างตรวจกับ customer.type (ประเภทอุตสาหกรรมของลูกค้า) ซึ่งเป็นความหมาย
         * "เดิม" ของช่อง itype. ตอนนี้ช่อง itype บนฟอร์มเปลี่ยนเป็น "ประเภทสินค้าที่สั่ง"
         * ที่ผู้ใช้ติ๊กเลือกเองรายใบ (ตัวเลือกอยู่ที่ config/order.php → itypes) และ
         * **ยังไม่มีที่เก็บใน DB** ⇒ ค่านั้นไม่ได้ถูกส่งมาที่นี่เลย
         *
         * ถ้าเปิดด่านนี้ทิ้งไว้ ผู้ใช้จะโดน 422 เพราะค่าที่มองไม่เห็นและแก้ในฟอร์มนี้ไม่ได้
         * ⇒ ตอนนี้บังคับ "ต้องเลือก itype" ที่ฝั่งจอเท่านั้น (saveOrder() ใน order/index.blade.php)
         *
         * เปิดคืนเมื่อได้ที่เก็บ itype แล้ว โดยเปลี่ยนไปตรวจค่าที่ส่งมาจากฟอร์มแทน customer.type
         */
        // $orderPrefix = strtoupper(substr(
        //     $mode === 'insert' ? $type : trim((string) $request->input('Orderno')),
        //     0,
        //     1
        // ));
        // if ($orderPrefix === 'W' && trim((string) $cust->type) === '') {
        //     return response()->json([
        //         'status'        => false,
        //         'itype_missing' => true,
        //         'custno'        => $custno,
        //         'message'       => 'ใบสั่งซื้อที่ขึ้นต้นด้วย W ต้องระบุ itype',
        //     ], 422);
        // }

        /* ใบนี้อนุมัติแล้วหรือยัง — ยึดค่าจริงใน DB ไม่ใช่ค่าที่ฟอร์มส่งมา (21/09/2569)
           ใช้ 2 ที่: ข้ามด่านราคาด้านล่าง + สั่ง headerPayload ไม่เขียนทับ price */
        $approved = false;
        if ($mode === 'update') {
            $current  = DB::table('morder')->where('Orderno', trim((string) $request->input('Orderno')))->first(['appv']);
            $approved = $current && self::checked($current->appv);
        }

        /* ด่านราคา — บังคับตอนสร้างใหม่ และตอนแก้ใบที่ "ยังไม่อนุมัติ"
           ส่งน้ำหนักรวมไปด้วย — ใช้หากลุ่มราคา (A/B/C) ของเกณฑ์จาก zcolorrate

           ⚠ ใบที่อนุมัติแล้วข้ามด่านนี้ (21/09/2569 ตามที่ผู้ใช้สั่ง) เพราะราคาขายถูกล็อกไม่ให้แก้
           อยู่แล้ว การตรวจราคาที่ส่งมาจึงไม่มีผลกับค่าที่จะเขียน — ถ้าไม่ข้าม ใบที่ราคาเดิมต่ำกว่า
           เกณฑ์ปัจจุบัน (วัดได้ 33.7% ของใบที่อนุมัติแล้ว) จะแก้ช่องอื่นแล้วบันทึกไม่ได้เลย

           ⚠ ใบประเภท HM ไม่ต้องเช็คราคา (15/10/2569 ตามที่ผู้ใช้สั่ง)
             ประเภท = 2 ตัวหน้าเลขที่ใบ (insert ใช้ order_type ที่ส่งมา) */
        $typePrefix = strtoupper(substr(
            $mode === 'insert' ? $type : trim((string) $request->input('Orderno')),
            0,
            2
        ));
        if (!$approved && $typePrefix !== 'HM') {
            $blocked = $this->checkPriceFloor(
                $custno,
                $items,
                $this->numOrNull($request->input('price')),
                $this->numOrNull($request->input('netqty'))
            );
            if ($blocked) {
                return response()->json($blocked, 422);
            }
        }

        try {
            $orderno = DB::transaction(function () use ($request, $mode, $type, $custno, $cust, $items, $approved) {
                if ($mode === 'insert') {
                    $orderno = $this->allocateOrderno($type);
                    DB::table('morder')->insert(
                        ['Orderno' => $orderno] + $this->headerPayload($request, $custno, $cust, 'insert')
                    );
                } else {
                    $orderno = trim((string) $request->input('Orderno'));
                    if (!DB::table('morder')->where('Orderno', $orderno)->exists()) {
                        throw new \RuntimeException('ไม่พบใบสั่งซื้อเลขที่ ' . $orderno);
                    }

                    // $approved = อ่านจาก DB ไว้ก่อนเข้าทรานแซกชัน (ดูหัวข้อด่านราคาด้านบน)
                    // อนุมัติแล้ว = headerPayload จะไม่เขียนทับ price
                    DB::table('morder')->where('Orderno', $orderno)
                        ->update($this->headerPayload($request, $custno, $cust, 'update', $approved));
                }

                $this->syncItems($orderno, $items);

                // ฟอร์มตรวจราคาเม็ด CP (16/10/2569) — ส่งมาเฉพาะใบที่เข้าเงื่อนไข (ฝั่งจอเป็นคนตัดสิน)
                if (is_array($request->input('cp'))) {
                    $this->saveCpItemPrice(
                        $orderno,
                        trim((string) $items[0]['Itemno']),
                        $this->numOrNull($request->input('price')),
                        (array) $request->input('cp')
                    );
                }

                return $orderno;
            });
        } catch (\Throwable $e) {
            return response()->json([
                'status'  => false,
                'message' => 'บันทึกไม่สำเร็จ: ' . $e->getMessage(),
            ], 500);
        }

        return response()->json([
            'status'  => true,
            'message' => $mode === 'insert' ? 'บันทึกใบสั่งซื้อใหม่เรียบร้อย' : 'แก้ไขใบสั่งซื้อเรียบร้อย',
            'orderno' => $orderno,
        ]);
    }

    // ─────────────────────────────────────────────────────────────
    //  ฟอร์มตรวจราคาเม็ด CP ก่อนบันทึก (cp_itemprice) — 16/10/2569
    //  ผังตามฟอร์ม Access เดิม · 1 แถวต่อคู่ (Orderno, itemno)
    // ─────────────────────────────────────────────────────────────

    public const CP_STATUS_PASS = 'อนุมัติได้';
    public const CP_STATUS_FAIL = 'ราคาไม่ผ่าน แจ้งปรับลูกค้า';

    /** GET — ค่าที่เคยบันทึกไว้ของคู่ (เลขที่ใบสั่ง, รหัสสินค้า) ใช้เติมฟอร์มตอนเปิดใบเดิม */
    public function cpPrice(Request $request)
    {
        $row = DB::table('cp_itemprice')
            ->where('Orderno', trim((string) $request->query('orderno')))
            ->where('itemno', trim((string) $request->query('itemno')))
            ->first();

        return response()->json(['found' => (bool) $row, 'row' => $row]);
    }

    /**
     * เขียน cp_itemprice — ข้อ 4 / ข้อ 5 / สถานะ คำนวณใหม่ที่ server (ไม่เชื่อค่าจากจอ)
     *   ข้อ 4 (wageCal) = ราคาขาย − ค่าเม็ด#1 × %#1 / 100 − ค่าเม็ด#2 × %#2 / 100
     *   ข้อ 5 (Diff)    = ข้อ 4 − ข้อ 2 (wage)
     *   สถานะ          = ข้อ 5 ≥ 0 → อนุมัติได้ · ไม่งั้น ราคาไม่ผ่าน แจ้งปรับลูกค้า
     * สูตรตรวจกับข้อมูลเดิมแล้ว ตรง 472 จาก 482 แถว
     */
    private function saveCpItemPrice(string $orderno, string $itemno, $price, array $cp): void
    {
        $num = fn ($k) => $this->numOrNull($cp[$k] ?? null);
        $txt = fn ($k) => ($v = trim((string) ($cp[$k] ?? ''))) === '' ? null : mb_substr($v, 0, 20);

        $wage = $num('wage');
        $r1p  = $num('Resin1Price');
        $r1   = $num('Resin1Per');
        $r2p  = $num('Resin2Price');
        $r2   = $num('Resin2Per');

        $wageCal = $price === null ? null
            : round($price - ($r1p ?? 0) * ($r1 ?? 0) / 100 - ($r2p ?? 0) * ($r2 ?? 0) / 100, 4);
        $diff = ($wageCal === null || $wage === null) ? null : round($wageCal - $wage, 4);

        $from  = (int) ($cp['ResinFrom'] ?? 0);
        $qdate = null;
        $raw   = trim((string) ($cp['Qdate'] ?? ''));
        if ($raw !== '' && ($d = \DateTime::createFromFormat('!d/m/Y', $raw)) !== false) {
            $qdate = $d->format('Y-m-d');
        }

        DB::table('cp_itemprice')->updateOrInsert(
            ['Orderno' => $orderno, 'itemno' => mb_substr($itemno, 0, 20)],
            [
                'OrderPrice'  => $price,
                'Qdate'       => $qdate,
                'wage'        => $wage,
                'ResinFrom'   => ($from >= 1 && $from <= 4) ? $from : null,
                'Resin1Code'  => $txt('Resin1Code'),
                'Resin1Price' => $r1p,
                'Resin1Per'   => $r1 === null ? null : (int) round($r1),
                'Resin2Code'  => $txt('Resin2Code'),
                'Resin2Price' => $r2p,
                'Resin2Per'   => $r2 === null ? null : (int) round($r2),
                'wageCal'     => $wageCal,
                'Diff'        => $diff,
                'status'      => $diff === null ? null
                    : ($diff >= -0.005 ? self::CP_STATUS_PASS : self::CP_STATUS_FAIL),
            ]
        );
    }

    // ─────────────────────────────────────────────────────────────
    //  ด่านราคา: ราคาขายต้องไม่ต่ำกว่าราคาช่อง 2
    // ─────────────────────────────────────────────────────────────

    /**
     * ตรวจว่า "ราคาขาย" (morder.price) ผ่านเกณฑ์ขั้นต่ำหรือยัง
     *
     * ขั้นตอนของงานจริง:
     *   1. ราคาขาย >= ราคาช่อง 2                        → บันทึกได้เลย
     *   2. ต่ำกว่า แต่มีราคาอนุมัติพิเศษที่ยังไม่หมดอายุรองรับ → บันทึกได้
     *   3. ต่ำกว่า และไม่มีราคาอนุมัติรองรับ                 → บันทึกไม่ได้
     *      พนักงานต้องไปทำใบ "ขออนุมัติราคาพิเศษ" ให้ผ่านก่อน (ดู PriceApprovalController)
     *   จากนั้นใบจึงไหลเข้าคิว "อนุมัติใบสั่งซื้อ" ต่อ (ดู OrderApprovalController)
     *
     * เกณฑ์ = ราคาช่อง 2 จาก `ProductPriceService` — ตัวเดียวกับที่กล่องราคาบนฟอร์มโชว์ในช่อง
     * "ราคาต้องไม่ต่ำกว่า" (ดู priceData()) จึงเทียบกับตัวเลขที่ผู้ใช้เห็นตรงหน้าเสมอ
     *
     * ⚠ **คำนวณราคาช่อง 2 ไม่ได้ = ปล่อยผ่าน** — รหัสสินค้าที่ใช้จริงในใบสั่ง 98.6%
     *   ไม่มีอยู่ใน `access_pdprice` (ตารางราคาทุน) ระบบจึงไม่มีเพดานให้เทียบ
     *   ถ้าบล็อกไว้จะบันทึกใบสั่งแทบไม่ได้เลย — ด่านนี้จึงทำงานเฉพาะรหัสที่คำนวณราคาได้
     *
     * ⚠ ตรวจกับ **รหัสสินค้าแถวแรกที่กรอก** เท่านั้น — ให้ตรงกับกล่องราคาบนฟอร์ม
     *   (ผู้ใช้กรอกรหัสเบอร์เดียวทั้งใบอยู่แล้ว ดู syncItemnoToPrice ใน order/index.blade.php)
     *   ไม่งั้นจะขึ้นเตือนด้วยตัวเลขที่ผู้ใช้ไม่เห็นบนจอ
     *
     * @return array|null  null = ผ่าน · array = ไม่ผ่าน (ใช้เป็น response body ได้เลย)
     */
    private function checkPriceFloor(string $custno, array $items, $price, $weight = null): ?array
    {
        $itemno = trim((string) ($items[0]['Itemno'] ?? ''));
        if ($itemno === '') {
            return null;
        }

        // รหัสลูกค้าขึ้นต้นด้วย E (ตัวเล็ก/ใหญ่) ไม่ต้องเช็คราคา (16/10/2569 ตามที่ผู้ใช้สั่ง)
        if (strtoupper(substr(trim($custno), 0, 1)) === 'E') {
            return null;
        }

        /* เกณฑ์ที่ใช้เทียบ (28/08/2569 — เปลี่ยนตามที่ผู้ใช้สั่ง):
             มีราคาอนุมัติที่ยังไม่เลยวันยืนราคา → ใช้ "ราคาอนุมัติ" เป็นเกณฑ์แทนเสมอ
             ไม่มี                              → ใช้ราคาช่อง 2 เหมือนเดิม
           เดิมใช้ราคาช่อง 2 เป็นหลักแล้วให้ราคาอนุมัติเป็นทางรอดสำรอง — ต่างกันตรงกรณีที่
           ราคาอนุมัติ "สูงกว่า" ราคาช่อง 2 ซึ่งตอนนี้จะยึดราคาอนุมัติ (เกณฑ์เข้มขึ้น) */
        $approved  = $this->approvedFloor($custno, $itemno);
        $colorRate = $this->colorRateFloor($itemno, $weight);

        if ($approved) {
            $floor     = (float) $approved->price;
            $floorFrom = 'approved';
        } elseif ($colorRate !== null) {
            // รหัสที่มีในตารางกลุ่มราคา → เทียบกับราคาของกลุ่มนั้นแทนราคาช่อง 2 (12/09/2569)
            $floor     = $colorRate;
            $floorFrom = 'color_rate';
        } else {
            $calc      = app(ProductPriceService::class)->lookup($itemno)['prices']['price_2'] ?? null;
            $floor     = $calc === null ? null : (float) $calc;
            $floorFrom = 'price_2';
        }

        /* ต้องไม่ต่ำกว่า "ราคาที่กำหนดไว้" (uprice.PRICE) ด้วย — 15/10/2569 ตามที่ผู้ใช้สั่ง
           ใช้ค่าที่สูงกว่าระหว่างเกณฑ์ข้างบนกับราคาที่กำหนดไว้ */
        $fixed = $this->fixedPriceFloor($custno, $itemno);
        if ($fixed !== null && ($floor === null || $fixed > $floor)) {
            $floor     = $fixed;
            $floorFrom = 'fixed';
        }

        if ($floor === null) {
            return null;   // ไม่มีเพดานให้เทียบ
        }

        $price = $price === null ? null : (float) $price;

        // เทียบด้วย epsilon กันเศษทศนิยมของ float ทำให้ราคาที่เท่ากันพอดีถูกตีว่าต่ำกว่า
        if ($price !== null && $price + 0.001 >= $floor) {
            return null;
        }

        return [
            'status'        => false,
            'price_blocked' => true,
            'itemno'        => $itemno,
            'custno'        => $custno,
            'min_price'     => round($floor, 2),
            'floor_from'    => $floorFrom,          // 'approved' = เทียบกับราคาอนุมัติ · 'price_2' = ราคาช่อง 2
            'price'         => $price,
            'approved'      => $approved ? [
                'exprice' => round((float) $approved->price, 2),
                'enddate' => $approved->enddate,
            ] : null,
            'message'       => $this->priceBlockedMessage($price, $floor, $custno, $itemno, $approved, $floorFrom),
        ];
    }

    /**
     * "ราคาที่กำหนดไว้" — `uprice.PRICE` ของคู่ (ลูกค้า, เบอร์) แถว `DATE` ล่าสุด (15/10/2569)
     * ตัวเดียวกับช่อง "ราคาที่กำหนดไว้" ในกล่องราคา (priceData) · ไม่มีแถว / ค่าว่าง / 0 = null
     */
    private function fixedPriceFloor(string $custno, string $itemno): ?float
    {
        if ($custno === '' || $itemno === '') {
            return null;
        }

        $price = DB::table('uprice')
            ->where('CustNo', $custno)
            ->where('ITEMNO', $itemno)
            ->orderByDesc('DATE')
            ->value('PRICE');

        return ($price === null || (float) $price <= 0) ? null : (float) $price;
    }

    /**
     * ราคาขั้นต่ำของ "กลุ่มราคา" — `zcolorrate.rate_A/B/C` ของรหัสสินค้า (12/09/2569)
     *
     * กลุ่ม (A/B/C) มาจากน้ำหนักรวมของใบ (`morder.netqty`) ตาม PriceApprovalController::groupOf()
     * รหัสที่มีในตารางนี้จะใช้ค่านี้เป็นเกณฑ์ "ราคาต้องไม่ต่ำกว่า" แทนราคาช่อง 2
     *
     * คืน null เมื่อ: ไม่ได้กรอกน้ำหนักรวม (หากลุ่มไม่ได้) · รหัสไม่มีในตาราง · ค่าในกลุ่มนั้นว่าง/0
     */
    private function colorRateFloor(string $itemno, $weight): ?float
    {
        $group = PriceApprovalController::groupOf($weight);
        if ($itemno === '' || !$group) {
            return null;
        }

        $row = DB::table('zcolorrate')->where('colorno', $itemno)->first(['rate_A', 'rate_B', 'rate_C']);
        $rate = $row->{'rate_' . $group['group']} ?? null;

        return ($rate === null || (float) $rate == 0.0) ? null : (float) $rate;
    }

    /**
     * ราคาอนุมัติพิเศษของคู่ (ลูกค้า, เบอร์) ที่ยังใช้ได้อยู่
     *
     * อ่านจาก `zcustprice` = "ราคาที่ยืนไว้กับลูกค้าถึงวันที่ ..." ซึ่ง
     * `PriceApprovalController::save()` เขียนให้ตอนที่ MD กดอนุมัติ
     *
     * เงื่อนไข: มี `exprice` (ไม่ใช่ 0) และ **ยังไม่เลย `enddate`**
     * — `enddate` ว่างถือว่าไม่กำหนดวันหมดอายุ (ข้อมูลจริงตอนนี้ไม่มีแถวไหนว่าง)
     */
    private function activeApprovedPrice(string $custno, string $itemno)
    {
        if ($custno === '') {
            return null;
        }

        return DB::table('zcustprice')
            ->where('custno', $custno)
            ->where('colorno', $itemno)
            ->whereNotNull('exprice')
            ->where('exprice', '<>', 0)
            ->where(function ($q) {
                $q->whereNull('enddate')
                    ->orWhereDate('enddate', '>=', now()->toDateString());
            })
            ->orderByDesc('enddate')
            ->first(['exprice', 'enddate']);
    }

    /**
     * ราคาอนุมัติที่ใช้เป็น "ราคาต้องไม่ต่ำกว่า" ได้ — ตรงกับ 2 ช่องที่ผู้ใช้เห็นในกล่องราคา
     *
     *   ราคาอนุมัติ  = `appvreq.price` ของใบล่าสุดของคู่ (ลูกค้า, เบอร์) ที่ **อนุมัติแล้ว**
     *   ยืนราคาถึง   = `zcustprice.enddate` ของคู่เดียวกัน
     *
     * ใช้ได้ก็ต่อเมื่อ **ยังไม่เลยวันยืนราคา** — `enddate` ว่าง = ไม่กำหนดวันหมดอายุ (ตาม
     * convention เดิมของ activeApprovedPrice) ส่วนคู่ที่ไม่มีแถวใน `zcustprice` เลย
     * ถือว่ายังไม่ได้ยืนราคา จึงใช้ไม่ได้
     *
     * ⚠ กรอง `Appv` ด้วยเสมอ — ไม่งั้นแค่ "ขอ" ราคาต่ำ ๆ ก็ปลดล็อกด่านได้เองโดยไม่ต้องผ่าน MD
     *
     * คืน object {price, enddate} หรือ null
     */
    private function approvedFloor(string $custno, string $itemno)
    {
        if ($custno === '' || $itemno === '') {
            return null;
        }

        $appv = DB::table('appvreq')
            ->where('custno', $custno)
            ->where('itemno', $itemno)
            ->whereNotNull('price')
            ->where('price', '<>', 0)
            ->where('Appv', '<>', 0)->whereNotNull('Appv')   // Access เก็บ -1 = ติ๊ก
            ->orderByDesc('ReqDate')
            ->first(['price']);

        if (!$appv) {
            return null;
        }

        $zcust = DB::table('zcustprice')
            ->where('custno', $custno)
            ->where('colorno', $itemno)
            ->orderByDesc('enddate')
            ->first(['enddate']);

        if (!$zcust) {
            return null;                                     // ยังไม่เคยยืนราคา
        }

        if ($zcust->enddate !== null
            && Carbon::parse($zcust->enddate)->startOfDay()->lt(now()->startOfDay())) {
            return null;                                     // เลยวันยืนราคาแล้ว
        }

        return (object) ['price' => (float) $appv->price, 'enddate' => $zcust->enddate];
    }

    /** ข้อความบอกสาเหตุที่บันทึกไม่ได้ — แยกกรณีให้ผู้ใช้รู้ว่าต้องทำอะไรต่อ */
    private function priceBlockedMessage($price, float $floor, string $custno, string $itemno, $approved, string $floorFrom = 'price_2'): string
    {
        // ชื่อเกณฑ์ที่ใช้เทียบ — ต้องตรงกับช่องที่ผู้ใช้เห็นในกล่องราคา จะได้ไม่งงว่าตัวเลขมาจากไหน
        $label = [
            'approved'   => 'ราคาอนุมัติ',
            'color_rate' => 'ราคาขั้นต่ำของกลุ่มราคา',
            'fixed'      => 'ราคาที่กำหนดไว้',
        ][$floorFrom] ?? 'ราคาช่อง 2';

        if ($price === null) {
            return 'ต้องกรอกราคาขาย และต้องไม่ต่ำกว่า ' . number_format($floor, 2)
                 . ' บาท (' . $label . ' ของ ' . $itemno . ')';
        }

        $msg = 'ราคาขาย ' . number_format($price, 2) . ' บาท ต่ำกว่า' . $label . ' ('
             . number_format($floor, 2) . ' บาท) ของรหัส ' . $itemno;

        if ($floorFrom === 'approved' && $approved) {
            $msg .= $approved->enddate
                ? ' — ราคาที่อนุมัติไว้ยืนราคาถึง ' . Carbon::parse($approved->enddate)->format('d/m/Y')
                : ' — ราคาที่อนุมัติไว้ไม่กำหนดวันหมดอายุ';
        } elseif ($floorFrom === 'fixed') {
            $msg .= ' — ราคาที่กำหนดไว้ของลูกค้า ' . $custno . ' (เมนู "กำหนดราคา")';
        } else {
            $msg .= ' — ยังไม่มีราคาอนุมัติที่ใช้ได้ของลูกค้า ' . $custno
                  . ' (ไม่เคยขอ ยังไม่อนุมัติ หรือเลยวันยืนราคาแล้ว)';
        }

        return $msg;
    }

    /**
     * ค่าที่จะเขียนลง morder (ใช้ร่วมทั้ง insert / update)
     *
     * @param bool $approved ใบนี้อนุมัติแล้วหรือยัง (ขา update เท่านั้น) — อนุมัติแล้ว = ไม่เขียนทับ `price`
     */
    private function headerPayload(Request $request, string $custno, $cust, string $mode = 'insert', bool $approved = false): array
    {
        // ตัดข้อความให้พอดีคอลัมน์ก่อนเขียน (ตาราง legacy คอลัมน์สั้น + MySQL strict mode)
        $data = $this->clampToColumns('morder', [
            // วันที่เปิดใบ — ใช้เฉพาะขา insert (ขา update ถูก unset ทิ้งท้ายเมธอด)
            'Mdate'    => $this->parseDateTime($request->input('Mdate')) ?? now(),
            'Company'  => $this->nullIfBlank($request->input('Company')),
            'PO'       => $this->nullIfBlank($request->input('PO')),
            'Custno'   => $custno,
            'Custname' => $cust->name,
            'Emp'      => $this->nullIfBlank($request->input('Emp')),
            'supno'    => $this->nullIfBlank($request->input('supno')),
            'DVpoint'  => $this->nullIfBlank($request->input('DVpoint')),
            'RsvNo'    => $this->nullIfBlank($request->input('RsvNo')),
            'netqty'   => $this->numOrNull($request->input('netqty')),
            'price'    => $this->numOrNull($request->input('price')),
            // กรณีสั่งทำสต๊อก
            'sendend'  => $this->parseDate($request->input('sendend')),
            'SendCust' => (int) $this->numOrNull($request->input('SendCust')),
            'HMStore'  => (float) $this->numOrNull($request->input('HMStore')),
            'sendmth'  => $this->numOrNull($request->input('sendmth')),
            // checkbox — Access เก็บ -1 = ติ๊ก
            'Send'     => $this->flag($request->input('Send')),
            'RP'       => $this->flag($request->input('RP')),
            'Spec'     => $this->flag($request->input('Spec')),
            'Cer'      => $this->flag($request->input('Cer')),
            'MSDS'     => $this->flag($request->input('MSDS')),
            // Require Document (15/10/2569) — ไม่ติ๊ก = ไม่เก็บข้อความ
            'ReqDoc'    => $this->flag($request->input('ReqDoc')),
            'ReqDocRem' => $this->flag($request->input('ReqDoc'))
                ?$this->nullIfBlank($request->input('ReqDocRem'))
                : null,
            // itype — รับเฉพาะ key ที่มีใน config/order.php → itypes (ไม่ติ๊ก/ค่าแปลก = null)
            'itype'    => in_array((string) $request->input('itype'), array_column(config('order.itypes', []), 'key'), true)
                ? (string) $request->input('itype')
                : null,
        ]);

        /* 19/09/2569: แก้ใบเดิม = ห้ามแตะ "วันที่เปิดใบ"
           ช่องบนฟอร์มเป็น readonly แล้ว แต่ต้องกันฝั่ง server ด้วย (ยิง POST ตรงยังส่งค่ามาได้)
           ขา insert ยังต้องมี Mdate ไม่งั้นคอลัมน์จะว่าง */
        if ($mode === 'update') {
            unset($data['Mdate']);

            /* 21/09/2569: ใบที่อนุมัติแล้ว = ห้ามแก้ "ราคาขาย" (morder.price)
               ช่องบนฟอร์มเป็น readonly แล้ว แต่ต้องกันฝั่ง server ด้วย (ยิง POST ตรงยังส่งค่ามาได้)
               ⚠ ยกเลิกอนุมัติแล้วใบกลับเข้าคิว → แก้ราคาได้อีกครั้ง (ยึดสถานะ ณ ตอนบันทึก) */
            if ($approved) {
                unset($data['price']);
            }
        }

        return $data;
    }

    /**
     * ตัดข้อความให้พอดีความยาวคอลัมน์ก่อนเขียน DB
     *
     * ตาราง legacy หลายคอลัมน์สั้นมาก (เช่น `suborder.prodname` = varchar(20)) แต่ค่าที่
     * ระบบเติมให้อัตโนมัติมาจากคอลัมน์ที่ยาวกว่า (`uprice.Label` = varchar(85) — ยาวเกิน 20
     * อยู่ 15.5% ของข้อมูลจริง) และ MySQL เปิด `STRICT_TRANS_TABLES` ⇒ ยาวเกินจะได้
     * **error 1406 Data too long** ทิ้งไปเลย ไม่ใช่ตัดให้เงียบ ๆ แบบระบบ Access เดิม
     *
     * อ่านความยาวจริงจาก schema (ไม่ hardcode) แล้วตัดด้วย `mb_substr` เพื่อไม่ให้ตัวอักษรไทย
     * ขาดกลางตัว — คอลัมน์ text / ตัวเลข / วันที่ ไม่แตะ
     */
    private function clampToColumns(string $table, array $data): array
    {
        static $limits = [];

        if (!isset($limits[$table])) {
            $limits[$table] = [];
            foreach (DB::select('SHOW COLUMNS FROM ' . $table) as $col) {
                if (preg_match('/^(?:var)?char\((\d+)\)/i', $col->Type, $m)) {
                    $limits[$table][$col->Field] = (int) $m[1];
                }
            }
        }

        foreach ($data as $field => $value) {
            if (is_string($value) && isset($limits[$table][$field])) {
                $data[$field] = mb_substr($value, 0, $limits[$table][$field]);
            }
        }

        return $data;
    }

    /**
     * เขียนรายการลง suborder แบบเทียบกับของเดิม:
     * แถวที่มี Runno = แก้ไข · แถวใหม่ = เพิ่ม · แถวที่หายไปจากฟอร์ม = ลบ
     * (คง Runno เดิมไว้ ไม่ลบทั้งใบแล้วใส่ใหม่ เพราะ Runno เป็นเลขอ้างอิงของระบบเดิม)
     */
    private function syncItems(string $orderno, array $items): void
    {
        $keep = [];

        foreach ($items as $row) {
            $data = [
                'Itemno'     => trim((string) ($row['Itemno'] ?? '')),
                'nold'       => $this->nullIfBlank($row['nold'] ?? null),
                'prodname'   => $this->nullIfBlank($row['prodname'] ?? null),
                'Lotno'      => $this->nullIfBlank($row['Lotno'] ?? null),
                'Stock'      => (float) $this->numOrNull($row['Stock'] ?? null),
                'Production' => (float) $this->numOrNull($row['Production'] ?? null),
                'custwant'   => $this->parseDate($row['custwant'] ?? null),
                'senddate'   => $this->parseDate($row['senddate'] ?? null),
                'EndP'       => $this->parseDate($row['EndP'] ?? null),
                'DVDate'     => $this->parseDate($row['DVDate'] ?? null),
                'outno'      => $this->nullIfBlank($row['outno'] ?? null),
                'Remark'     => $this->nullIfBlank($row['Remark'] ?? null),
            ];

            // prodname = varchar(20) แต่ชื่อที่เติมอัตโนมัติจาก uprice.Label ยาวกว่านั้นได้
            $data = $this->clampToColumns('suborder', $data);

            $runno = (int) ($row['Runno'] ?? 0);
            $isOld = $runno > 0 && DB::table('suborder')
                ->where('Orderno', $orderno)->where('Runno', $runno)->exists();

            if ($isOld) {
                DB::table('suborder')->where('Orderno', $orderno)->where('Runno', $runno)->update($data);
                $keep[] = $runno;
            } else {
                $data['Orderno'] = $orderno;
                $keep[] = DB::table('suborder')->insertGetId($data);
            }
        }

        // แถวที่ผู้ใช้ลบออกจากฟอร์ม
        DB::table('suborder')
            ->where('Orderno', $orderno)
            ->whereNotIn('Runno', $keep)
            ->delete();
    }

    /**
     * จองเลขที่ใบสั่งของประเภทที่เลือก — ต้องเรียกภายใน transaction เท่านั้น
     *
     * ล็อกแถว orderrun ไว้ก่อน กันสองคนกดบันทึกพร้อมกันแล้วได้เลขซ้ำ
     * แล้วเดินเลขต่อจากค่าล่าสุด ข้ามเลขที่มีใบสั่งอยู่จริง (เผื่อค่าใน orderrun ไม่ตรงกับข้อมูลจริง)
     */
    private function allocateOrderno(string $type): string
    {
        $column = self::ORDER_TYPES[$type];

        $run = DB::table('orderrun')->lockForUpdate()->first();
        if (!$run) {
            throw new \RuntimeException('ไม่พบข้อมูลเลขรันในตาราง orderrun');
        }

        $siblings = array_keys(self::ORDER_TYPES, $column, true);

        $next = (int) ($run->{$column} ?? 0);
        do {
            $next++;
            $taken = DB::table('morder')
                ->whereIn('Orderno', array_map(fn ($p) => $p . $next, $siblings))
                ->exists();
        } while ($taken);

        DB::table('orderrun')->update([$column => $next]);

        return $type . $next;
    }

    /**
     * แปลงวันที่+เวลาจากช่องกรอก (flatpickr ส่งมาเป็น d/m/Y H:i) → Y-m-d H:i:s
     * รับรูปแบบไม่มีเวลา (d/m/Y) และรูปแบบของ DB (Y-m-d H:i:s) ได้ด้วย
     */
    private function parseDateTime($value): ?string
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }

        if (preg_match('#^(\d{1,2})/(\d{1,2})/(\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$#', $value, $m)) {
            return sprintf(
                '%04d-%02d-%02d %02d:%02d:%02d',
                $m[3], $m[2], $m[1], $m[4] ?? 0, $m[5] ?? 0, $m[6] ?? 0
            );
        }

        if (preg_match('#^\d{4}-\d{2}-\d{2}#', $value)) {
            return substr($value . ' 00:00:00', 0, 19);
        }

        return null;
    }

    /** ค่าว่าง → null (กันช่องว่างกลายเป็นสตริงว่างใน DB) */
    private function nullIfBlank($value)
    {
        $value = trim((string) $value);

        return $value === '' ? null : $value;
    }

    /** ตัวเลขจากฟอร์ม (ผ่าน stripCommaFields มาแล้ว) — ว่าง/ไม่ใช่ตัวเลข = null */
    private function numOrNull($value)
    {
        $value = str_replace(',', '', trim((string) $value));

        return ($value === '' || !is_numeric($value)) ? null : (float) $value;
    }

    /** checkbox บนฟอร์ม → รูปแบบของ Access (-1 = ติ๊ก, 0 = ไม่ติ๊ก) */
    private function flag($value): int
    {
        return in_array((string) $value, ['1', 'true', 'on', '-1'], true) ? -1 : 0;
    }
}
