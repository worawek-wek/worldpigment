{{-- ═══════════════════════════════════════════════════════════════════ --}}
{{-- Modal: ใบนำส่งเทียบสี (Color Matching Delivery Doc)                 --}}
{{-- Trigger: data-bs-target="#colorMatchingModal"                       --}}
{{-- ═══════════════════════════════════════════════════════════════════ --}}
<div class="modal modalHeadDecor fade" id="colorMatchingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">

            <!-- Header -->
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="ti ti-file-text me-1"></i>
                    ใบนำส่งเทียบสี (Color Matching)
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <form id="form_color_matching" enctype="multipart/form-data">
                @csrf
                {{-- _mode = 'create' หรือ 'edit' (set by JS เมื่อเปิด modal) --}}
                <input type="hidden" name="_mode" value="create">
                {{-- _pk = SendNo เดิม ตอน edit --}}
                <input type="hidden" name="_pk" value="">

                <!-- Body -->
                <div class="modal-body px-5 py-3" style="background-color: #f8f9fb;">

                    <div class="card shadow-sm mb-3"
                        style="border: 1px solid #cfe4e3; border-bottom-width: 0;">

                        <div class="card-header py-2 px-3 d-flex align-items-center"
                            style="background-color: #cdeceb; border-bottom: 2px solid #54BAB9; border-radius: 0.375rem 0.375rem 0 0;">
                            <h6 class="mb-0 fw-semibold" style="color: #1f5d5c;">
                                <i class="ti ti-file-text me-1"></i>
                                ใบนำส่งเทียบสี
                            </h6>
                        </div>

                        <div class="card-body p-3">

                            {{-- ─── กลุ่ม: ข้อมูลลูกค้า ─── --}}
                            <div class="mb-3 pb-2 border-bottom">
                                <div class="d-flex align-items-center mb-2 ps-2"
                                    style="border-left: 3px solid #54BAB9;">
                                    <i class="ti ti-user-circle me-2" style="color: #2a8a89;"></i>
                                    <span class="fw-semibold" style="font-size: 0.95rem; color: #2a8a89;">
                                        ข้อมูลลูกค้า
                                    </span>
                                </div>

                                <div class="row gx-3 gy-2">
                                    <div class="col-md-2">
                                        <label class="form-label small mb-1">รหัสลูกค้า <span class="text-muted fw-normal">(เช่น 00004)</span></label>
                                        <input type="text" name="custno" class="form-control">
                                    </div>
                                    <div class="col-md-5">
                                        <label class="form-label small mb-1">
                                            <span class="badge bg-label-secondary me-1">TH</span>
                                            ชื่อบริษัท (ไทย)
                                        </label>
                                        <input type="text" name="custname" class="form-control">
                                    </div>
                                    <div class="col-md-5">
                                        <label class="form-label small mb-1">
                                            <span class="badge bg-label-secondary me-1">EN</span>
                                            ชื่อบริษัท (อังกฤษ)
                                        </label>
                                        <input type="text" name="custnameEN" class="form-control">
                                    </div>
                                </div>
                            </div>

                            {{-- ─── กลุ่ม: ข้อมูลใบนำส่ง ─── --}}
                            <div class="mb-3 pb-2 border-bottom">
                                <div class="d-flex align-items-center mb-2 ps-2"
                                    style="border-left: 3px solid #54BAB9;">
                                    <i class="ti ti-file-invoice me-2" style="color: #2a8a89;"></i>
                                    <span class="fw-semibold" style="font-size: 0.95rem; color: #2a8a89;">
                                        ข้อมูลใบนำส่ง
                                    </span>
                                </div>

                                <div class="row gx-3 gy-2">
                                    <div class="col-md-3">
                                        <label class="form-label small mb-1">เลขที่ใบนำส่งเทียบสี <span class="text-muted fw-normal">(เช่น 26/0001)</span></label>
                                        <input type="text" name="SendNo" class="form-control" required>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small mb-1">วันที่ส่งเทียบสี</label>
                                        <input type="text" name="DsendT"
                                            class="form-control flatpickr-date"
                                            value="{{ date('d/m/Y') }}">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small mb-1">ประเภทงาน</label>
                                        <select name="Type_Work" class="form-select select2-tags">
                                            <option value="">-- เลือก --</option>
                                            @foreach ($options['Type_Work'] as $opt)
                                                <option>{{ $opt }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small mb-1 text-danger">
                                            <i class="ti ti-asterisk-simple"></i>
                                            ปรับแก้ไขครั้งที่
                                        </label>
                                        <select name="Adj" class="form-select select2-tags">
                                            @foreach ($options['Adj'] as $opt)
                                                <option>{{ $opt }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>

                            {{-- ─── กลุ่ม: ข้อมูลสี ─── --}}
                            <div class="mb-3 pb-2 border-bottom">
                                <div class="d-flex align-items-center mb-2 ps-2"
                                    style="border-left: 3px solid #54BAB9;">
                                    <i class="ti ti-palette me-2" style="color: #2a8a89;"></i>
                                    <span class="fw-semibold" style="font-size: 0.95rem; color: #2a8a89;">
                                        ข้อมูลสี
                                    </span>
                                </div>

                                <div class="row gx-3 gy-2">
                                    <div class="col-md-4">
                                        <label class="form-label small mb-1">สี <span class="text-muted fw-normal">(ชื่อสี เช่น DB PINK-Y)</span></label>
                                        <input type="text" name="color" class="form-control">
                                    </div>
                                    <div class="col-md-2">
                                        <label class="form-label small mb-1">ลักษณะสี</label>
                                        @php $colorCharFixed = ['ทึบ', 'ใส', 'กึ่งทึบ', 'ตาม ตย.']; @endphp
                                        <select name="ColorChar" class="form-select select2-tags">
                                            <option value="">-- เลือก --</option>
                                            {{-- ตัวเลือกตายตัว (บนสุด) --}}
                                            @foreach ($colorCharFixed as $opt)
                                                <option>{{ $opt }}</option>
                                            @endforeach
                                            {{-- ค่าที่เคยบันทึกใน DB (ต่อท้าย) — ตัดที่ซ้ำกับตัวตายตัวออก --}}
                                            @foreach (array_diff($options['ColorChar'], $colorCharFixed) as $opt)
                                                <option>{{ $opt }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <label class="form-label small mb-1">ประเภท</label>
                                        <select name="TestType" class="form-select">
                                            <option value="">-- เลือก --</option>
                                            {{-- ประเภทตัวอย่าง 1–4 (ค่าเดิมจาก Access) — นิยามที่ config/color_matching.php --}}
                                            @foreach (config('color_matching.test_type_options') as $code => $label)
                                                <option value="{{ $code }}">{{ $code }} : {{ $label }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <label class="form-label small mb-1">คุณสมบัติ</label>
                                        <select name="pop" class="form-select select2-tags">
                                            <option value="">-- เลือก --</option>
                                            @foreach ($options['pop'] as $opt)
                                                <option>{{ $opt }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    {{-- ขึ้นแถวใหม่ --}}
                                    <div class="w-100"></div>

                                    {{-- เม็ดที่ลูกค้าใช้ — เก็บลง column CustPigment --}}
                                    <div class="col-md-4">
                                        <label class="form-label small mb-1">เม็ดที่ลูกค้าใช้ <span class="text-muted fw-normal">(เช่น AS50%+ABS50%)</span></label>
                                        <input type="text" name="CustPigment" class="form-control">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small mb-1">Standard <span class="text-muted fw-normal">(เช่น PT 494 C)</span></label>
                                        <input type="text" name="STD" class="form-control">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small mb-1">นำไปทำชิ้นงาน (Model)</label>
                                        <select name="Model" class="form-select select2-tags">
                                            <option value="">-- เลือก --</option>
                                            @foreach ($options['Model'] as $opt)
                                                <option>{{ $opt }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    {{-- ยี่ห้อของชิ้นงานที่นำไปทำ — วางคู่กับ Model --}}
                                    <div class="col-md-2">
                                        <label class="form-label small mb-1">ยี่ห้อ <span class="text-muted fw-normal">(ยี่ห้อของชิ้นงาน)</span></label>
                                        <input type="text" name="Brand" class="form-control">
                                    </div>
                                    {{-- ขึ้นแถวใหม่ --}}
                                    <div class="w-100"></div>
                                    {{-- Chemical Safety — มาตรฐานความปลอดภัยสารเคมี (เลือกได้หลายค่า 29/08/2569) --}}
                                    {{-- select2 ของ modal นี้ตั้ง tags:true → พิมพ์ค่านอกรายการเองได้ (= ช่อง "อื่นๆ ระบุ" ในฟอร์มกระดาษ) --}}
                                    {{-- หลายค่าเก็บลง testmain.ChemSafety คอลัมน์เดียว คั่นด้วย ", " (ดู ColorMatchingController::joinMulti) --}}
                                    <div class="col-md-4">
                                        <label class="form-label small mb-1">
                                            <i class="ti ti-shield-check me-1"></i>
                                            Chemical Safety <span class="text-muted fw-normal">(เลือกได้หลายค่า หรือพิมพ์ค่าอื่นได้)</span>
                                        </label>
                                        @php $chemSafetyFixed = [
                                            'EN 71:3',
                                            'AP (89)',
                                            'EU 94/62/EC',
                                            'JHOSPA',
                                            'EU 2002/72/EC',
                                            'RoHS2 (EU2011/65/EU)',
                                        ]; @endphp
                                        {{-- ถ้าไม่เลือกอะไรเลย <select multiple> จะไม่ส่ง key มา → ล้างค่าเดิมไม่ได้
                                             hidden ตัวนี้ทำให้ ChemSafety ถูกส่งมาเสมอ (ค่าว่าง = ล้างค่า) --}}
                                        <input type="hidden" name="ChemSafety[]" value="">
                                        <select name="ChemSafety[]" multiple class="form-select select2-tags"
                                                data-placeholder="เลือก หรือพิมพ์ค่าอื่นได้">
                                            {{-- ตัวเลือกตายตัวตามฟอร์มกระดาษ (บนสุด) --}}
                                            @foreach ($chemSafetyFixed as $opt)
                                                <option>{{ $opt }}</option>
                                            @endforeach
                                            {{-- ค่าที่เคยบันทึกใน DB (ต่อท้าย) — ตัดที่ซ้ำกับตัวตายตัวออก --}}
                                            @foreach (array_diff($options['ChemSafety'], $chemSafetyFixed) as $opt)
                                                <option>{{ $opt }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>

                            {{-- ─── กลุ่ม: วันที่ดำเนินการ และผู้เทียบสี ─── --}}
                            <div class="mb-3 pb-2 border-bottom">
                                <div class="d-flex align-items-center mb-2 ps-2"
                                    style="border-left: 3px solid #54BAB9;">
                                    <i class="ti ti-calendar-event me-2" style="color: #2a8a89;"></i>
                                    <span class="fw-semibold" style="font-size: 0.95rem; color: #2a8a89;">
                                        วันที่ดำเนินการ และผู้เทียบสี
                                    </span>
                                </div>

                                <div class="row gx-3 gy-2">
                                    <div class="col-md-3">
                                        <label class="form-label small mb-1">Start Date <span class="text-muted fw-normal">(วว/ดด/ปปปป)</span></label>
                                        <input type="text" name="startdate" class="form-control flatpickr-date">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small mb-1">Sample Date <span class="text-muted fw-normal">(วว/ดด/ปปปป)</span></label>
                                        <input type="text" name="SampleDate" class="form-control flatpickr-date">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small mb-1">Ready Date <span class="text-muted fw-normal">(วว/ดด/ปปปป)</span></label>
                                        <input type="text" name="ReadyDate" class="form-control flatpickr-date">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small mb-1">Color Matcher <span class="text-muted fw-normal">(ชื่อพนักงาน)</span></label>
                                        <input type="text" name="ColorMatcher" class="form-control">
                                    </div>
                                </div>
                            </div>

                            {{-- ─── กลุ่ม: การติดตามงาน ─── --}}
                            <div class="mb-2">
                                <div class="d-flex align-items-center mb-2 ps-2"
                                    style="border-left: 3px solid #54BAB9;">
                                    <i class="ti ti-clipboard-check me-2" style="color: #2a8a89;"></i>
                                    <span class="fw-semibold" style="font-size: 0.95rem; color: #2a8a89;">
                                        การติดตามงาน
                                    </span>
                                </div>

                                <div class="row gx-3 gy-2">
                                    <div class="col-md-4">
                                        <label class="form-label small mb-1">ผู้รับเอกสาร <span class="text-muted fw-normal">(ชื่อพนักงาน)</span></label>
                                        <input type="text" name="TNname" class="form-control">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label small mb-1">รอวัตถุดิบ <span class="text-muted fw-normal">(ระบุวัตถุดิบที่รอ)</span></label>
                                        <input type="text" name="RminWating" class="form-control">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label small mb-1">กำหนดเทียบสีเสร็จ <span class="text-muted fw-normal">(วว/ดด/ปปปป)</span></label>
                                        <input type="text" name="TNDate" class="form-control flatpickr-date">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label small mb-1">
                                            <i class="ti ti-note me-1"></i>
                                            หมายเหตุ <span class="text-muted fw-normal">(หมายเหตุเพิ่มเติม)</span>
                                        </label>
                                        <input type="text" name="Mems" class="form-control">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>

                <!-- Footer -->
                <div class="modal-footer justify-content-between flex-wrap gap-2">
                    <div class="d-flex gap-2 flex-wrap">
                        {{-- ลบใบนำส่งเทียบสี — แสดงเฉพาะโหมดแก้ไข (JS ถอด d-none ให้ตอนเปิดจากปุ่มแก้ไข) --}}
                        <button type="button" id="btn_delete_cm" class="btn btn-label-danger d-none">
                            <i class="ti ti-trash me-1"></i>
                            ลบใบนำส่งเทียบสี
                        </button>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">
                            ปิด
                        </button>
                        <button type="submit" class="btn btn-success px-5">
                            <i class="ti ti-device-floppy me-1"></i>
                            บันทึกใบนำส่งเทียบสี
                        </button>
                    </div>
                </div>

            </form>

        </div>
    </div>
</div>
