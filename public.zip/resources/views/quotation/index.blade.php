<!doctype html>

<html lang="en" class="light-style layout-navbar-fixed layout-menu-fixed layout-compact" dir="ltr"
    data-theme="theme-default" data-assets-path="assets/" data-template="vertical-menu-template">

<head>
    @include('layout/inc_header')
    <title>ใบเสนอราคา - World Pigment</title>

</head>
<style>
.modalHeadDecor .modal-header {
    padding: 0;
}

.modalHeadDecor .modal-title {
    padding: 1.25rem 1.5rem 1.25rem;
    color: white;
    background-color: #54BAB9;
    position: relative;
}

.modalHeadDecor .modal-title::after {
    position: absolute;
    top: 0;
    right: -65px;
    content: '';
    width: 0;
    height: 0;
    border-top: 65px solid #54BAB9;
    border-right: 65px solid transparent;
}

/* กล่อง section ในฟอร์มสร้าง/แก้ไข */
.qf-sec {
    border: 1px solid #e2e7ea;
    border-radius: .6rem;
    padding: 1rem 1.15rem 1.15rem;
    margin-bottom: 1rem;
}
.qf-sec:last-child { margin-bottom: 0; }
.qf-sec-title {
    font-size: 1.15rem;
    font-weight: 700;
    color: #2f7a78;
    letter-spacing: .2px;
    margin-bottom: .9rem;
    padding-bottom: .55rem;
    border-bottom: 2px solid #d9e6e6;
    display: flex;
    align-items: center;
    gap: .5rem;
}
.qf-sec-title i { font-size: 1.25rem; }

/* ช่องกรอกในตารางรายการ (โชว์ทุกคอลัมน์ → ตารางกว้าง เลื่อนแนวนอนได้) */
/* หัวคอลัมน์ตัดบรรทัดได้ (16/10/2569) — เดิม nowrap ทำให้ช่องราคากว้างตามหัว (เช่น "ราคาเม็ดพลาสติก") หดไม่ได้ */
#quotationItemsTable th { white-space: normal; font-size: .82rem; line-height: 1.25; vertical-align: middle; }
/* ความกว้างขั้นต่ำตอนช่องว่าง — qAutoGrow() ตั้ง min-width แบบ inline ทับให้โตตามข้อความที่พิมพ์
   ⚠ ค่าเหล่านี้ต้องตรงกับ Q_BASE_W ใน JS (ใช้เป็นพื้นขั้นต่ำของ auto-grow) */
.qitem-input { min-width: 72px; }                    /* ช่องตัวเลข/ราคา — หดลง 16/10/2569 (เดิม 90) */
.qitem-input:not(.text-end) { min-width: 110px; }   /* คอลัมน์ข้อความ (หมายเหตุ ฯลฯ) */
.qitem-input.qitem-code { min-width: 150px; }        /* รหัสสินค้า — ขยาย 16/10/2569 (เดิม 130) */
.qitem-input.qitem-name { min-width: 200px; }        /* ชื่อสินค้า/รายละเอียด — หด 16/10/2569 (เดิม 340) */
/* เรียงตาม — คลิกหัวตาราง + เน้นคอลัมน์ที่กำลังเรียง (เหมือนหน้าเทียบสี) */
#table-data th.th-sort { cursor: pointer; user-select: none; }
#table-data th.th-sort:hover { background-color: #e9ecef; }
.th-sort-icon { font-size: .9rem; opacity: .35; vertical-align: middle; }
.th-sort-icon.active { opacity: 1; color: #ffd43b; font-size: 1.05rem; font-weight: 700; margin-left: .15rem; }
#table-data thead th.col-sorted { background-color: #696cff; color: #fff; box-shadow: inset 0 -3px 0 #ffd43b; }
#table-data thead th.col-sorted:hover { background-color: #5a5ef0; }
#table-data thead th.col-sorted small { color: rgba(255,255,255,.8) !important; }
#table-data tbody td.col-sorted { box-shadow: inset 2px 0 0 #696cff, inset -2px 0 0 #696cff; }
/* สลับภาษา section หมายเหตุ — โชว์เฉพาะ span ของภาษาที่เลือก (ข้อมูลชุดเดียว) */
#remarkSection.lang-th .i18n-en { display: none; }
#remarkSection.lang-en .i18n-th { display: none; }
/* สวิตช์ TH/EN — segmented control (กล่องเดียวมี border รอบ กัน border ขาดจาก btn-group) */
.lang-switch { display: inline-flex; border: 1px solid #CBD5E1; border-radius: .375rem; overflow: hidden; }
.lang-switch .btn { border: 0; border-radius: 0; margin: 0; color: #0D6EFD; background: #fff; font-weight: 600; min-width: 46px; }
.lang-switch .btn + .btn { border-left: 1px solid #CBD5E1; }
.lang-switch .btn:hover:not(.active) { background: #e7f0ff; color: #0a58ca; }
.lang-switch .btn.active { background: #0D6EFD; color: #fff; }
/* เน้นพื้นหลังคอลัมน์ปรับราคา (ปัจจุบัน/ใหม่) — สีเข้ม */
#quotationItemsTable th.qcol-rev { background: #3e8c8b !important; color: #fff; }
#quotationItemsTable td.qcol-rev { background: #8fcfc8 !important; }
/* กรอบล้อมบล็อกปรับราคา (บน/ล่าง/ซ้าย/ขวา) + เส้นคั่นกลาง ปัจจุบัน|ใหม่ */
#quotationItemsTable th.qcol-rev { border-top: 3px solid #2f6f6e !important; }
#quotationItems tr:last-child td.qcol-rev { border-bottom: 3px solid #2f6f6e !important; }
#quotationItemsTable th.qcol-rev-start,
#quotationItemsTable td.qcol-rev-start { border-left: 3px solid #2f6f6e !important; }
#quotationItemsTable th.qcol-rev-end,
#quotationItemsTable td.qcol-rev-end { border-right: 3px solid #2f6f6e !important; }
#quotationItemsTable th.qcol-sep,
#quotationItemsTable td.qcol-sep { border-left: 3px solid #2f6f6e !important; }

/* กล่อง "ราคา" (แยกต่างหาก — สีน้ำเงิน) */
#quotationItemsTable th.qcol-price { background: #5b7fa6 !important; color: #fff; border-top: 3px solid #3f5f85 !important; }
#quotationItemsTable td.qcol-price { background: #e9f0f7 !important; }
#quotationItems tr:last-child td.qcol-price { border-bottom: 3px solid #3f5f85 !important; }
#quotationItemsTable th.qcol-price-start,
#quotationItemsTable td.qcol-price-start { border-left: 3px solid #3f5f85 !important; }
#quotationItemsTable th.qcol-price-end,
#quotationItemsTable td.qcol-price-end { border-right: 3px solid #3f5f85 !important; }

/* ช่อง "รวม VAT" — คำนวณอัตโนมัติ แก้เองไม่ได้ (readonly) → ทำให้ดูออกว่าพิมพ์ไม่ได้ */
#quotationItemsTable input.qitem-readonly {
    background-color: #eef1f4;
    color: #495057;
    cursor: not-allowed;
    font-weight: 600;
}

/* ─── ช่องวันที่ในฟอร์ม: ให้ label อยู่บนหัวช่องเสมอ (เรียงตรงแถวกับช่องอื่น) ───
   flatpickr(static:true) ห่อ input ด้วย .flatpickr-wrapper ที่เป็น inline-block
   ซึ่ง .form-label ของ Bootstrap ก็ inline-block → label สั้น ๆ อย่าง "Revise Date"
   จึงไปอยู่บรรทัดเดียวกับช่องกรอก (label ยาวกว่าถึงจะดันตกบรรทัด)
   scope เฉพาะในฟอร์ม — ช่องวันที่ในตัวกรองอยู่ใน d-flex ต้องคง inline-block ไว้ */
#quotationForm .flatpickr-wrapper {
    display: block;
    width: 100%;
}

/* ─── ฟอร์มแบบ label อยู่ซ้าย (06/10/2569) — โครง .of-row / .of-ctl, CSS กลางอยู่ใน layout/inc_header ───
   --of-lw = ความกว้าง label ตั้งให้พอกับ label ที่ยาวที่สุดของแต่ละกล่อง */
#quotationForm .of-form { --of-lw: 130px; }          /* ข้อมูลเอกสาร / ลูกค้า / รูปแบบตาราง */
#quotationForm .of-form .qf-lw-wide { --of-lw: 150px; }   /* คอลัมน์ขวาของกล่องลูกค้า — "ชื่อลูกค้า (ภาษาอังกฤษ)" */
#quotationForm #remarkSection { --of-lw: 150px; }    /* หมายเหตุ — เผื่อ label ภาษาอังกฤษ เช่น "Price validity from *" */
/* 06/10/2569: โหมดภาษาไทย label สั้นกว่า — ลดให้พอดี label ไทยที่ยาวสุด ("จำนวนส่งมอบขั้นต่ำ *")
   ไม่งั้น label กับช่องกรอกห่างกันเกิน (ผู้ใช้ทัก) */
#quotationForm #remarkSection.lang-th { --of-lw: 132px; }
</style>

<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->
            @include('layout/inc_sidemenu')
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->

                @include('layout/inc_topmenu')

                <!-- / Navbar -->

                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->

                    <div class="container-xxl flex-grow-1 container-p-y">

    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body d-flex justify-content-between align-items-center flex-wrap gap-3">

                    <div>
                        <h3 class="mb-1">
                            <i class="ti ti-file-invoice text-primary"></i>
                            ใบเสนอราคา
                        </h3>
                        <p class="text-muted mb-0">
                            จัดการใบเสนอราคาและ Revision
                        </p>
                    </div>

                    <div class="d-flex gap-2 flex-wrap">
                        <button class="btn btn-label-primary border" style="color: #1f158e;" onclick="quotationCustomers()">
                            <i class="ti ti-users me-1"></i>
                            ประวัติตามลูกค้า
                        </button>
                        <button class="btn btn-primary" onclick="openCreate()">
                            <i class="ti ti-plus me-1"></i>
                            สร้างใบเสนอราคา
                        </button>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- Table -->
    <div class="card">

        <div class="card-header border-bottom">

            {{-- แถบหัว: ปุ่มพับ/กางตัวกรอง + ปุ่มล้างตัวกรอง (ชิดขวาทั้งคู่) — ค่าเริ่มต้นคือ "ซ่อนไว้" --}}
            <div class="d-flex justify-content-end align-items-center gap-2">
                {{-- รายละเอียดการค้นหา — สรุปเงื่อนไขที่กรองอยู่ โชว์เฉพาะตอนพับตัวกรอง --}}
                <div id="filterSummary" class="d-flex flex-wrap align-items-center gap-1 me-auto"></div>
                <button type="button" id="btnToggleFilters" class="btn btn-label-primary btn-sm"
                    data-bs-toggle="collapse" data-bs-target="#quotationFilterBox"
                    aria-expanded="false" aria-controls="quotationFilterBox">
                    <i class="ti ti-filter me-1"></i>ตัวกรอง
                    <i class="ti ti-chevron-down ms-1 toggle-caret"></i>
                </button>
                <button type="button" id="btnResetFilters" class="btn btn-label-secondary btn-sm" onclick="resetFilters()">
                    <i class="ti ti-x me-1"></i>ล้างตัวกรอง<span class="filter-count ms-1"></span>
                </button>
            </div>

            <div class="collapse" id="quotationFilterBox">
            <div class="pt-3">

            {{-- แถวตัวกรอง 1: ค้นหา + ช่วงวันที่ --}}
            <div class="row g-3 align-items-end">
                <div class="col-md-6">
                    <label class="form-label small fw-medium mb-1">ค้นหา <span class="text-muted fw-normal">(เลขที่ใบเสนอราคา / รหัสลูกค้า / ชื่อลูกค้า)</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="ti ti-search"></i></span>
                        <input type="text" name="search" class="form-control p_search"
                            oninput="loadData(page)">
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-medium mb-1">วันที่เสนอราคา</label>
                    <div class="d-flex align-items-center gap-2">
                        <span class="small fw-medium">ตั้งแต่</span>
                        <input type="text" name="date_from" class="form-control flatpickr-date p_search" autocomplete="off" placeholder="วว/ดด/ปปปป">
                        <span class="small fw-medium">ถึง</span>
                        <input type="text" name="date_to" class="form-control flatpickr-date p_search" autocomplete="off" placeholder="วว/ดด/ปปปป">
                    </div>
                </div>
            </div>

            {{-- แถวตัวกรอง 2: ชนิดสินค้า --}}
            <div class="row g-3 align-items-end mt-1">
                <div class="col-md-4">
                    <label class="form-label small fw-medium mb-1">ชนิดสินค้า</label>
                    <select name="product_type" class="form-select w-100 p_search" onchange="loadData(page)">
                        <option value="">ทั้งหมด</option>
                        @foreach ($pdtypes as $pt)
                            <option value="{{ $pt->PDType }}">{{ $pt->PDType }} — {{ $pt->PDHead1 }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            </div>
            </div>
            {{-- /#quotationFilterBox --}}

            {{-- state การเรียง — เก็บนอก #table-data เพื่อคงค่าเมื่อตารางโหลดใหม่ (default = id desc = ล่าสุด) --}}
            <input type="hidden" name="sort_col" value="id" class="p_search">
            <input type="hidden" name="sort_dir" value="desc" class="p_search">

            {{-- เรียงตามลำดับการเพิ่ม (id) + จำนวนต่อหน้า --}}
            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                <div class="d-flex align-items-center">
                    <label class="form-label small fw-medium mb-0 me-2 d-flex align-items-center"
                        title="เรียงตามลำดับการเพิ่มข้อมูลเข้าระบบ">
                        เรียงตามลำดับการเพิ่ม
                        <i class="ti ti-info-circle ms-1 text-muted"></i>
                    </label>
                    <select name="sort" class="form-select form-select-sm" style="width: 210px;"
                        onchange="onSortDropdown(this.value)">
                        <option value="desc">ล่าสุด</option>
                        <option value="asc">เก่าสุด</option>
                        <option value="" hidden>เรียงตามคอลัมน์ (คลิกหัวตาราง)</option>
                    </select>
                </div>
                <div class="d-flex align-items-center">
                    <label class="form-label small fw-medium mb-0 me-2">แสดง</label>
                    <select name="limit" class="form-select form-select-sm p_search" style="width: 90px;"
                        onchange='loadData("{{$page_url}}/datatable")'>
                        <option value="15">15</option>
                        <option value="50">50</option>
                        <option value="75">75</option>
                        <option value="100">100</option>
                    </select>
                    <span class="ms-2 small fw-medium">รายการ/หน้า</span>
                </div>
            </div>
        </div>

        <div id="table-data">
            {{-- Table โหลดผ่าน AJAX จาก quotation/datatable --}}
            <div class="text-center py-5 text-muted">
                <div class="spinner-border spinner-border-sm me-2"></div>
                กำลังโหลดข้อมูล...
            </div>
        </div>

    </div>

</div>
                    <!-- / Content -->

                    <!-- Footer -->
                    @include('layout/inc_footer')
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>

        <!-- Drag Target Area To SlideIn Menu On Small Screens -->
        <div class="drag-target"></div>
    </div>

<!-- ═══════════════════════════════════════════════════════════════ -->
<!-- Modal: สร้าง / แก้ไข ใบเสนอราคา (ใช้ฟอร์มร่วมกัน)                  -->
<!-- ═══════════════════════════════════════════════════════════════ -->
<div class="modal modalHeadDecor fade" id="quotationModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="quotationModalTitle">สร้างใบเสนอราคา</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <form id="quotationForm">
                <input type="hidden" name="mode" id="q_mode" value="insert">
                {{-- qno เดิม (ใช้ตอน update/หา key) --}}
                <input type="hidden" name="qno" id="q_qno_key">

                {{-- 06/10/2569: เปลี่ยนช่องกรอกส่วนหัวฟอร์มเป็น "label อยู่ซ้าย ต่อด้วยช่องกรอก" แบบเดียวกับฟอร์ม Order
                     (โครง .of-row / .of-ctl — CSS กลางใน layout/inc_header) · ความกว้าง label (--of-lw) ตั้งใน <style> ของหน้านี้
                     id / name / attribute ของทุกช่องคงเดิม JS ไม่ได้แก้ --}}
                <div class="modal-body px-4 py-4 of-form">

                    {{-- ── Section 1: ข้อมูลเอกสาร ── --}}
                    <div class="qf-sec">
                        <div class="qf-sec-title"><i class="ti ti-clipboard-text"></i>ข้อมูลเอกสาร</div>
                        {{-- หัวกระดาษ (บนสุด) — เลือกก่อน เพราะกำหนด prefix ของเลขที่ --}}
                        <div class="row gx-3 gy-2">
                            <div class="col-md-4 of-row">
                                <label class="form-label">หัวกระดาษ</label>
                                <div class="of-ctl">
                                    <select name="letterhead" id="q_letterhead" class="form-select w-100" onchange="onLetterheadChange()">
                                        <option value="WPI">WPI</option>
                                        <option value="WPC">WPC</option>
                                        <option value="WH">WH</option>
                                    </select>
                                </div>
                            </div>
                            {{-- 06/10/2569: คำอธิบายในวงเล็บย้ายออกจาก label (label ซ้ายแคบ) มาอยู่ข้างช่องแทน --}}
                            <div class="col-md-8 d-flex align-items-center">
                                <span class="text-muted fw-normal small">(หัวเอกสารที่พิมพ์)</span>
                            </div>
                        </div>
                        {{-- แถว: เลขที่ / วันที่ / Revise Date --}}
                        {{-- mt-0 = หักล้าง margin ติดลบของ gy-2 ไม่งั้นแถวชิดกันเกิน --}}
                        <div class="row gx-3 gy-2 mt-0">
                            <div class="col-md-4 of-row">
                                <label class="form-label">เลขที่ใบเสนอราคา <span class="text-danger">*</span></label>
                                <div class="of-ctl">
                                    <input type="text" name="Qno" id="q_Qno" class="form-control" maxlength="20" required>
                                </div>
                            </div>
                            <div class="col-md-4 of-row">
                                <label class="form-label">วันที่เสนอราคา <span class="text-danger">*</span></label>
                                <div class="of-ctl">
                                    <input type="text" name="Qdate" id="q_Qdate" class="form-control flatpickr-date" autocomplete="off" placeholder="วว/ดด/ปปปป" required>
                                </div>
                            </div>
                            <div class="col-md-4 of-row">
                                <label class="form-label text-danger">Revise Date</label>
                                <div class="of-ctl">
                                    <input type="text" name="Revisedate" id="q_Revisedate" class="form-control flatpickr-date" autocomplete="off" placeholder="วว/ดด/ปปปป">
                                </div>
                            </div>
                        </div>
                        {{-- แถวล่าง: ชนิดสินค้า / พร้อมตัวอย่าง --}}
                        <div class="row gx-3 gy-2 mt-0">
                            {{-- ชนิดสินค้า — ซ่อนไว้ก่อน (16/10/2569 ตามที่ผู้ใช้สั่ง) · ใช้ d-none ไม่ใช่ลบทิ้ง
                                 เพราะ select ยังต้องส่งค่า PDtype ไปกับฟอร์ม ไม่งั้นแก้ใบเดิมแล้ว PDtype ถูกทับเป็นค่าว่าง
                                 (PDtype ยังใช้เดารูปแบบตารางของใบเก่าฝั่ง server) · เปิดคืน: ถอด d-none ออก --}}
                            <div class="col-md-4 of-row d-none">
                                <label class="form-label">ชนิดสินค้า</label>
                                <div class="of-ctl">
                                    <select name="PDtype" id="q_PDtype" class="form-select w-100">
                                        @foreach ($pdtypes as $pt)
                                            @php
                                                // CP: แสดงเป็น "Compound" ในฟอร์ม (เข้าใจง่ายกว่า)
                                                // — ไม่แก้ pdtype.PDHead1 ใน DB เพราะค่านั้นถูกใช้เป็นหัวเรื่องบนใบเสนอราคาที่พิมพ์ออก
                                                $ptLabel = $pt->PDType === 'CP' ? 'Compound' : $pt->PDHead1;
                                            @endphp
                                            <option value="{{ $pt->PDType }}">{{ $pt->PDType }} — {{ $ptLabel }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            {{-- ไม่มี label — จัดให้อยู่กลางแนวตั้งของแถว (เดิมชิดล่างเพราะ label อยู่บน) --}}
                            <div class="col-md-4 d-flex align-items-center">
                                <div class="form-check mb-0">
                                    <input class="form-check-input" id="q_exam" name="exam" type="checkbox" value="1">
                                    <label class="form-check-label" for="q_exam">พร้อมตัวอย่าง</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- ── Section 2: ข้อมูลลูกค้า ── --}}
                    {{-- 06/10/2569: label ซ้าย — จัดเป็น 2 แถว (4 + 8): รหัสลูกค้า | ชื่อลูกค้า  /  รหัสพนักงานขาย | ชื่อลูกค้า (อังกฤษ)
                         รหัสลูกค้า col-md-2 → 4 · รหัสพนักงานขาย col-md-3 → 4 · ชื่อลูกค้าทั้งสองช่อง col-md-5 → 8
                         สลับลำดับ รหัสพนักงานขาย กับ ชื่อลูกค้า (อังกฤษ) ให้ช่องกรอกตรงแนวกันทั้งสองแถว --}}
                    <div class="qf-sec">
                        <div class="qf-sec-title"><i class="ti ti-building-store"></i>ข้อมูลลูกค้า</div>
                        <div class="row gx-3 gy-2">
                            <div class="col-md-4 of-row">
                                <label class="form-label">รหัสลูกค้า <span class="text-danger">*</span></label>
                                <div class="of-ctl">
                                    <input type="text" name="Custid" id="q_Custid" class="form-control" maxlength="6"
                                        oninput="lookupCustomer(this.value)" required>
                                </div>
                            </div>
                            <div class="col-md-8 of-row qf-lw-wide">
                                <label class="form-label">ชื่อลูกค้า <span class="text-danger">*</span></label>
                                <div class="of-ctl">
                                    <input type="text" name="CustName" id="q_CustName" class="form-control text-primary fw-bold" required>
                                </div>
                            </div>
                            <div class="col-md-4 of-row">
                                <label class="form-label">รหัสพนักงานขาย</label>
                                <div class="of-ctl">
                                    <input type="number" name="EmpID" id="q_EmpID" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-8 of-row qf-lw-wide">
                                <label class="form-label">ชื่อลูกค้า (ภาษาอังกฤษ)</label>
                                <div class="of-ctl">
                                    <input type="text" name="Engname" id="q_Engname" class="form-control" maxlength="70">
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- ── Section 3: รายการสินค้า ──  ---}}
                    <div class="qf-sec">
                        <div class="qf-sec-title"><i class="ti ti-list-details"></i>รายการสินค้า</div>

                        {{-- รูปแบบตาราง: เลือก preset (1.1–2.3) → ตารางกรอก + PDF ใช้คอลัมน์ชุดนั้น
                             ไม่เลือก = อัตโนมัติ (โชว์ทุกคอลัมน์ในฟอร์ม, PDF ตัดคอลัมน์ที่ไม่มีใครกรอกออกเอง) --}}
                        {{-- 06/10/2569: label ซ้าย (โครง .of-row / .of-ctl) --}}
                        <div class="row gx-3 gy-2 mb-3">
                            <div class="col-md-6 of-row">
                                <label class="form-label" for="q_col_format">รูปแบบตารางรายการ</label>
                                <div class="of-ctl">
                                <select name="col_format" id="q_col_format" class="form-select w-100" onchange="onColFormatChange()">
                                    <option value="">อัตโนมัติ — โชว์ทุกคอลัมน์</option>
                                    <optgroup label="1. ใบเสนอราคา">
                                        @foreach ($formatLabels as $code => $label)
                                            @if (str_starts_with($code, '1.'))
                                                <option value="{{ $code }}">{{ $code }} — {{ $label }}</option>
                                            @endif
                                        @endforeach
                                    </optgroup>
                                    <optgroup label="2. ใบขอปรับราคา (ปัจจุบัน / ใหม่)">
                                        @foreach ($formatLabels as $code => $label)
                                            @if (str_starts_with($code, '2.'))
                                                <option value="{{ $code }}">{{ $code }} — {{ $label }}</option>
                                            @endif
                                        @endforeach
                                    </optgroup>
                                </select>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <div class="alert alert-info py-2 px-3 mb-0 small">
                                <i class="ti ti-info-circle me-1"></i>กรอกเฉพาะคอลัมน์ที่ต้องการ — คอลัมน์ที่ปล่อยว่างทั้งหมดจะไม่แสดงในใบเสนอราคา
                                (หัวจดหมาย เสนอราคา/ปรับราคา ระบบตั้งให้อัตโนมัติ)
                            </div>
                            <div class="d-flex align-items-center gap-3">
                                {{-- รหัสสินค้าใน PDF: กรอกรหัสไว้เพื่อค้นหาชื่อ/ราคาเสมอ แต่เลือกได้ว่าจะโชว์ให้ลูกค้าเห็นไหม --}}
                                <div class="form-check mb-0 mt-2">
                                    <input type="hidden" name="show_code" value="0">
                                    <input class="form-check-input" id="q_show_code" name="show_code" type="checkbox" value="1" checked>
                                    <label class="form-check-label" for="q_show_code">
                                        แสดงรหัสสินค้าใน PDF
                                        <i class="ti ti-info-circle text-muted"
                                            title="ไม่ติ๊ก = ยังกรอกรหัสเพื่อค้นหาสินค้าได้ แต่คอลัมน์รหัสจะไม่ขึ้นบนใบเสนอราคาที่พิมพ์"></i>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="table-responsive mt-3">
                            <table class="table table-bordered align-middle mb-0" id="quotationItemsTable">
                                <thead class="table-light"><tr id="quotationItemsHead"></tr></thead>
                                <tbody id="quotationItems"></tbody>
                            </table>
                        </div>

                        {{-- ปุ่มเพิ่มรายการ — อยู่ใต้ตาราง (แถวใหม่จะไปต่อท้ายตรงนี้พอดี) --}}
                        <div class="mt-3">
                            <button type="button" class="btn btn-label-warning" onclick="addQuotationItem()">
                                <i class="ti ti-plus me-1"></i>เพิ่มรายการ
                            </button>
                        </div>
                    </div>

                    {{-- ── Section 4: หมายเหตุ (2 ภาษา — สลับแค่ label ด้วยสวิตช์ TH/EN) ── --}}
                    <input type="hidden" name="remark_lang" id="q_remark_lang" value="th">
                    <div class="qf-sec lang-th" id="remarkSection">
                        <div class="qf-sec-title d-flex align-items-center">
                            <span><i class="ti ti-note me-2"></i><span class="i18n-th">หมายเหตุ</span><span class="i18n-en">Remarks</span></span>
                            {{-- สวิตช์ภาษา: สลับเฉพาะคำ (label) ข้อมูลชุดเดียว --}}
                            <div class="lang-switch" role="group">
                                <button type="button" class="btn btn-sm active" id="btnLangTh" onclick="setRemarkLang('th')">TH</button>
                                <button type="button" class="btn btn-sm" id="btnLangEn" onclick="setRemarkLang('en')">EN</button>
                            </div>
                        </div>
                        <div class="alert alert-info py-2 px-3 mb-3 small">
                            <i class="ti ti-info-circle me-1"></i>ช่องที่มี <span class="text-danger fw-bold">*</span> ต้องกรอก — ช่องที่ปล่อยว่างจะไม่แสดงในใบเสนอราคา
                        </div>

                        {{-- 06/10/2569: label ซ้าย (โครง .of-row / .of-ctl) — ตัวอย่างในวงเล็บ "(เช่น ...)" ย้ายจาก label
                             ลงมาเป็น form-text ใต้ช่องกรอก (label ซ้ายแคบ ใส่ไม่พอ) · class i18n-th คงไว้ จึงยังซ่อนตอนสลับเป็น EN เหมือนเดิม --}}
                        <div class="row gx-3 gy-2">
                            {{-- ราคาเม็ดพลาสติก --}}
                            <div class="col-md-6 of-row">
                                <label class="form-label">
                                    <span class="i18n-th">ราคาเม็ดพลาสติก</span><span class="i18n-en">Resin Price</span>
                                </label>
                                <div class="of-ctl">
                                    <input type="text" name="resin_price_note" id="q_resin_price_note" class="form-control"
                                        maxlength="100">
                                    <div class="form-text text-muted fw-normal i18n-th">(เช่น 60.50 บาท เดือน มิย 2026)</div>
                                </div>
                            </div>

                            {{-- ราคานี้มีผลวันที่ (from → to) --}}
                            <div class="col-md-6 of-row">
                                <label class="form-label">
                                    <span class="i18n-th">ราคานี้มีผลวันที่</span><span class="i18n-en">Price validity from</span>
                                    <span class="text-danger">*</span>
                                </label>
                                <div class="of-ctl">
                                    <div class="d-flex align-items-center gap-2">
                                        <input type="text" name="ValidFrom" id="q_ValidFrom" class="form-control flatpickr-date" autocomplete="off" placeholder="วว/ดด/ปปปป" required>
                                        <span class="small fw-medium"><span class="i18n-th">ถึง</span><span class="i18n-en">to</span></span>
                                        <input type="text" name="Validto" id="q_Validto" class="form-control flatpickr-date" autocomplete="off" placeholder="วว/ดด/ปปปป" required>
                                    </div>
                                </div>
                            </div>

                            {{-- จำนวนส่งมอบขั้นต่ำ --}}
                            <div class="col-md-6 of-row">
                                <label class="form-label">
                                    <span class="i18n-th">จำนวนส่งมอบขั้นต่ำ</span><span class="i18n-en">Minimum Quantity</span>
                                    <span class="text-danger">*</span>
                                </label>
                                <div class="of-ctl">
                                    <div class="input-group">
                                        <input type="text" name="Qremark" id="q_Qremark" class="form-control" maxlength="50" required>
                                        <span class="input-group-text"><span class="i18n-th">กก.</span><span class="i18n-en">kg</span></span>
                                    </div>
                                    <div class="form-text text-muted fw-normal i18n-th">(เช่น 100)</div>
                                </div>
                            </div>

                            {{-- สถานที่ส่งสินค้า --}}
                            <div class="col-md-6 of-row">
                                <label class="form-label">
                                    <span class="i18n-th">สถานที่ส่งสินค้า</span><span class="i18n-en">Delivery Location</span>
                                </label>
                                <div class="of-ctl">
                                    <input type="text" name="delivery_place" id="q_delivery_place" class="form-control"
                                        maxlength="100">
                                    <div class="form-text text-muted fw-normal i18n-th">(เช่น กรุงเทพฯและปริมณฑล)</div>
                                </div>
                            </div>

                            {{-- เทอมการส่งมอบสินค้า --}}
                            <div class="col-md-6 of-row">
                                <label class="form-label">
                                    <span class="i18n-th">เทอมการส่งมอบสินค้า</span><span class="i18n-en">Price Term</span>
                                </label>
                                <div class="of-ctl">
                                    <input type="text" name="delivery_term" id="q_delivery_term" class="form-control"
                                        maxlength="50">
                                    <div class="form-text text-muted fw-normal i18n-th">(เช่น DDP)</div>
                                </div>
                            </div>

                            {{-- เทอมการชำระเงิน --}}
                            <div class="col-md-6 of-row">
                                <label class="form-label">
                                    <span class="i18n-th">เทอมการชำระเงิน</span><span class="i18n-en">Term of Payment</span>
                                </label>
                                <div class="of-ctl">
                                    <input type="text" name="Term" id="q_Term" class="form-control">
                                    <div class="form-text text-muted fw-normal i18n-th">(เช่น 30วัน นับจากส่งสินค้า)</div>
                                </div>
                            </div>
                        </div>

                        {{-- หมายเหตุอื่น (เพิ่มได้ไม่จำกัด) --}}
                        <div class="mt-3">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <label class="form-label mb-0"><span class="i18n-th">หมายเหตุอื่น</span><span class="i18n-en">Other remarks</span></label>
                                <button type="button" class="btn btn-sm btn-label-warning" onclick="addNoteRow()">
                                    <i class="ti ti-plus me-1"></i><span class="i18n-th">เพิ่มหมายเหตุ</span><span class="i18n-en">Add remark</span>
                                </button>
                            </div>
                            <div id="otherNotesList"></div>
                        </div>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                    <button type="button" class="btn btn-label-info" onclick="quotationPrintPreview()"
                        title="พิมพ์ตัวอย่างจากข้อมูลในฟอร์ม (ยังไม่บันทึก)">
                        <i class="ti ti-printer me-1"></i>พิมพ์ตัวอย่าง
                    </button>
                    <button type="button" class="btn btn-primary" onclick="saveQuotation()">
                        <i class="ti ti-device-floppy me-1"></i>บันทึกใบเสนอราคา
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════════════ -->
<!-- Modal: ดูรายละเอียด (โหลด HTML จาก quotation/show)               -->
<!-- ═══════════════════════════════════════════════════════════════ -->
<div class="modal fade" id="quotationViewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content" style="overflow:hidden;">
            {{-- ปุ่มปิดลอย — แบนเนอร์ในเนื้อหาทำหน้าที่เป็น header แทน --}}
            <button type="button" class="btn-close btn-close-white position-absolute"
                style="top:1.15rem; right:1.25rem; z-index:1056;" data-bs-dismiss="modal" aria-label="ปิด"></button>
            <div class="modal-body p-0" id="quotationViewBody">
                <div class="text-center py-5">
                    <div class="spinner-border spinner-border-sm me-2"></div>กำลังโหลด...
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════════════ -->
<!-- Modal: ประวัติใบเสนอราคาของลูกค้า (โหลด HTML จาก quotation/history) -->
<!-- ═══════════════════════════════════════════════════════════════ -->
<div class="modal fade" id="quotationHistoryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content" style="overflow:hidden;">
            <button type="button" class="btn-close btn-close-white position-absolute"
                style="top:1.1rem; right:1.25rem; z-index:1056;" data-bs-dismiss="modal" aria-label="ปิด"></button>
            <div class="modal-body p-0" id="quotationHistoryBody">
                <div class="text-center py-5">
                    <div class="spinner-border spinner-border-sm me-2"></div>กำลังโหลด...
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════════════ -->
<!-- Modal: รายชื่อลูกค้า (ขั้นแรก) — โหลด HTML จาก quotation/customers  -->
<!-- ═══════════════════════════════════════════════════════════════ -->
<div class="modal fade" id="quotationCustomersModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content" style="overflow:hidden;">
            <button type="button" class="btn-close btn-close-white position-absolute"
                style="top:1.1rem; right:1.25rem; z-index:1056;" data-bs-dismiss="modal" aria-label="ปิด"></button>
            <div class="modal-body p-0" id="quotationCustomersBody">
                <div class="text-center py-5">
                    <div class="spinner-border spinner-border-sm me-2"></div>กำลังโหลด...
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- / Layout wrapper -->
    @include('layout/inc_js')
<script>
    var page = "{{$page_url}}/datatable";
        var searchData = {};
        // ต้องประกาศก่อน loadData ครั้งแรก — เลี่ยง hoisting ทำให้ dtSeq เป็น NaN (spinner ค้าง)
        var dtXhr = null, dtSeq = 0;

        // ป้ายชื่อของแต่ละช่องกรอง — ใช้ประกอบแถบ "รายละเอียดการค้นหา" (#filterSummary)
        // ⚠ ต้องประกาศตรงนี้ (ก่อน loadData ครั้งแรก) เพราะ renderFilterSummary() ถูกเรียกใน loadData
        //   ถ้าไปประกาศท้ายไฟล์ ตัวแปรจะยังเป็น undefined ตอนโหลดหน้า → throw แล้ว spinner ค้าง
        var FILTER_LABELS = {
            search:       'ค้นหา',
            date_from:    'วันที่เสนอราคา ตั้งแต่',
            date_to:      'ถึง',
            product_type: 'ชนิดสินค้า'
        };

        loadData(page);

        // ── Flatpickr: ทุกช่องวันที่ใช้ flatpickr-date (รูปแบบ d/m/Y เหมือนทั้งระบบ) ──
        $(function () {
            // ยกระดับ select ทั้งหน้า — ตัวช่วยกลางใน layout/inc_js เลือกให้เองตามจำนวนตัวเลือก
            // (ตั้งแต่ 10 ตัวขึ้นไป → select2 พิมพ์ค้นหาได้ · ต่ำกว่านั้น → bootstrap-select)
            // ⚠ ต้องมาก่อน flatpickr เพื่อไม่ให้ไปจับ <select> เดือน/ปี ที่ flatpickr สร้าง
            enhanceSelects();
            flatpickr('.flatpickr-date', {
                dateFormat: 'd/m/Y',
                allowInput: true,
                static: true,
                disableMobile: true,
                onChange: function (_, __, instance) {
                    // ช่องกรอง (p_search) → โหลดตารางใหม่เมื่อเลือกวันที่
                    if (instance.input.classList.contains('p_search')) loadData(page);
                }
            });
            // sync dropdown "เรียงตาม" ให้ตรงกับ state เริ่มต้น (id desc = ล่าสุด)
            syncSortDropdown();
        });

        // ────────────────────────────────────────────────────────
        //  เรียงลำดับ — state เดียว (sort_col/sort_dir) ใช้ร่วม 2 ทาง:
        //   1) dropdown "เรียงตามลำดับการเพิ่ม" (ล่าสุด/เก่าสุด = เรียงตาม id)
        //   2) คลิกหัวตาราง (เรียงตามคอลัมน์ใดก็ได้)
        // ────────────────────────────────────────────────────────
        function setSort(col, dir) {
            $('input[name="sort_col"]').val(col);
            $('input[name="sort_dir"]').val(dir);
            syncSortDropdown();
            loadData(page);
        }
        // dropdown สะท้อนเฉพาะการเรียงตาม id → ล่าสุด/เก่าสุด; คอลัมน์อื่น = option ซ่อน
        function syncSortDropdown() {
            var col = $('input[name="sort_col"]').val();
            var dir = $('input[name="sort_dir"]').val();
            $('select[name="sort"]').val(col === 'id' ? dir : '');
        }
        // เลือกจาก dropdown → เรียงตาม id ทิศตามที่เลือก
        function onSortDropdown(val) {
            if (val === '') return;   // option บอกสถานะ (เรียงตามคอลัมน์) — ไม่ทำอะไร
            setSort('id', val);
        }
        // คลิกหัวตาราง: คอลัมน์เดิมซ้ำ = สลับ asc/desc; คอลัมน์ใหม่ = เริ่มที่ asc
        // (delegated เพราะ thead อยู่ใน #table-data ที่โหลดใหม่ทุกครั้ง)
        $(document).on('click', '#table-data th[data-sort]', function () {
            var col    = String($(this).data('sort'));
            var curCol = $('input[name="sort_col"]').val();
            var curDir = $('input[name="sort_dir"]').val();
            var dir    = (curCol === col) ? (curDir === 'asc' ? 'desc' : 'asc') : 'asc';
            setSort(col, dir);
        });

        // วาดหน้าปุ่ม/กล่องของ select ที่ยกระดับแล้วใหม่ ให้ตรงกับค่าที่เพิ่งเปลี่ยนด้วย JS
        // ตอนนี้ทั้งหน้าใช้ตัวช่วยกลาง (enhanceSelects) แล้ว — select ตัวเดียวกันอาจเป็น select2
        // หรือ bootstrap-select ก็ได้ ขึ้นกับจำนวนตัวเลือก จึงส่งต่อให้ refreshSelects ตัดสินแทน
        // (คงชื่อ refreshPickers ไว้เพราะถูกเรียกจากหลายจุดในหน้านี้)
        function refreshPickers(scope){
            refreshSelects(scope);
        }

        // ตั้งค่าวันที่ให้ flatpickr (รับ Y-m-d / datetime → แสดง d/m/Y); ว่าง = เคลียร์
        // ⚠ ต้องส่ง 'Y-m-d' เป็น argument ที่ 3 เสมอ — ไม่งั้น flatpickr จะ parse string ที่เราส่งไป
        // ด้วย dateFormat ของตัวเอง (d/m/Y) แล้วได้วันที่มั่ว (ทุกวันกลายเป็น 20/06/<ปีปัจจุบัน>)
        function setFp(id, val) {
            var el = document.getElementById(id);
            if (!el) return;
            if (el._flatpickr) {
                if (val) el._flatpickr.setDate(String(val).substring(0, 10), false, 'Y-m-d');
                else     el._flatpickr.clear();
            } else {
                $(el).val(val ? String(val).substring(0, 10) : '');
            }
        }

        // ────────────────────────────────────────────────────────
        //  รายการสินค้า — คอลัมน์กำหนดเองได้ (config-driven)
        // ────────────────────────────────────────────────────────
        var COL_REG = @json($colRegistry);   // คลังคอลัมน์ทั้งหมด {key:{label,num,suffix}}
        // โหมดอัตโนมัติ: แสดงทุกคอลัมน์ — คอลัมน์ที่ไม่มีใครกรอกจะถูกตัดออกตอนบันทึก (ฝั่ง server)
        var ALL_COLS = Object.keys(COL_REG).map(function(k){
            return {key: k, label: COL_REG[k].label, num: !!COL_REG[k].num};
        });
        // preset คอลัมน์ของแต่ละรูปแบบ {'1.1': [{key,label}, ...], ...} — ต้องตรงกับ presets() ฝั่ง server
        var PRESETS = @json($presets);

        // คอลัมน์ที่ตารางกรอกใช้อยู่ตอนนี้ — ตามรูปแบบที่เลือก, ไม่เลือก = ทุกคอลัมน์ (พฤติกรรมเดิม)
        // label เอาจาก preset (ชื่อหัวคอลัมน์ของรูปแบบนั้น) แต่ num/ชนิดช่องกรอกยังอิง registry
        function activeCols(){
            var fmt = $('#q_col_format').val() || '';
            var preset = PRESETS[fmt];
            if (!fmt || !preset) return ALL_COLS;
            return preset.map(function(c){
                return {key: c.key, label: c.label, num: !!(COL_REG[c.key] && COL_REG[c.key].num)};
            });
        }

        // เดารูปแบบของใบที่บันทึกไว้ — เทียบลำดับ key ของ col_config กับแต่ละ preset
        // ไม่เก็บรหัสรูปแบบลง DB (ไม่ต้องเพิ่มคอลัมน์) เพราะ col_config บอกได้อยู่แล้วว่าใช้คอลัมน์ชุดไหน
        // ตัด 'code' ออกจากทั้งสองฝั่งก่อนเทียบ — ใบที่ไม่ติ๊ก "แสดงรหัสสินค้าใน PDF" จะไม่มี code ใน col_config
        // ไม่ตรงกับ preset ไหนเลย → '' = อัตโนมัติ
        function detectColFormat(savedCols){
            var strip = function(list){
                return (list || []).map(function(c){ return c.key; })
                                   .filter(function(k){ return k !== 'code'; }).join(',');
            };
            var saved = strip(savedCols);
            if (!saved) return '';
            var found = '';
            Object.keys(PRESETS).forEach(function(fmt){
                if (fmt && !found && strip(PRESETS[fmt]) === saved) found = fmt;
            });
            return found;
        }

        // เปลี่ยนรูปแบบ → วาดตารางใหม่ (ข้อมูลที่กรอกไว้ยังอยู่ครบใน currentItems ไม่หาย)
        function onColFormatChange(){
            renderItems();
        }
        // กล่อง "ค่าผลิต/ค่าแม่สี ปรับราคา" (ปัจจุบัน|ใหม่) — เน้นพื้นหลัง (ราคาไม่รวมในกล่องนี้)
        var REVISION_COLS = {cur_process_fee:1, cur_pigment_price:1, new_process_fee:1, new_pigment_price:1};
        // คอลัมน์แรกของกลุ่ม "ใหม่" — ใส่เส้นคั่นซ้าย แยกจากกลุ่ม "ปัจจุบัน"
        var GROUP_SEP_COLS = {new_process_fee:1};
        // กล่อง "ราคา" (แยกต่างหาก คนละสี)
        var PRICE_COLS   = {price_kg:1, new_price:1, price_vat:1};

        // หาคอลัมน์แรก/สุดท้ายของแต่ละกล่อง "จากคอลัมน์ที่แสดงจริง"
        // (แต่ละรูปแบบมีคอลัมน์ไม่เท่ากัน เช่น 2.2 ไม่มี new_pigment_price / 2.3 ไม่มี price_vat
        //  ถ้า fix ชื่อคอลัมน์หัวท้ายไว้ตายตัว กล่องจะขาดเส้นปิดด้านขวา)
        function groupEdges(cols){
            var e = {rev: {}, price: {}};
            cols.forEach(function(c){
                var g = REVISION_COLS[c.key] ? 'rev' : (PRICE_COLS[c.key] ? 'price' : null);
                if (!g) return;
                if (e[g].start === undefined) e[g].start = c.key;
                e[g].end = c.key;
            });
            return e;
        }
        // รวม class เน้น/กรอบของแต่ละกล่อง
        function revClasses(key, edges){
            var cl = [];
            if (REVISION_COLS[key])       cl.push('qcol-rev');
            if (GROUP_SEP_COLS[key])      cl.push('qcol-sep');
            if (key === edges.rev.start)  cl.push('qcol-rev-start');
            if (key === edges.rev.end)    cl.push('qcol-rev-end');
            if (PRICE_COLS[key])          cl.push('qcol-price');
            if (key === edges.price.start) cl.push('qcol-price-start');
            if (key === edges.price.end)   cl.push('qcol-price-end');
            return cl.join(' ');
        }
        var currentItems = [];               // ข้อมูลรายการ (array ของ object)

        function esc(v){ return String(v == null ? '' : v).replace(/"/g,'&quot;'); }

        // ── ตารางกรอกรายการ — คอลัมน์ตามรูปแบบที่เลือก (ไม่เลือก = ทุกคอลัมน์) ──
        function renderItems(){
            var cols = activeCols();
            var edges = groupEdges(cols);
            var head = '';
            cols.forEach(function(c){
                var rc = revClasses(c.key, edges);
                head += '<th class="text-center'+(rc?' '+rc:'')+'">'+esc(c.label)+'</th>';
            });
            head += '<th width="46" class="text-center">ลบ</th>';
            $('#quotationItemsHead').html(head);

            var body = '';
            if (!currentItems.length){
                body = '<tr><td colspan="'+(cols.length+1)+'" class="text-center py-3">ยังไม่มีรายการ — กด “เพิ่มรายการ”</td></tr>';
            } else {
                currentItems.forEach(function(row, idx){
                    body += '<tr>';
                    cols.forEach(function(c){
                        // คอลัมน์ตัวเลข = input ธรรมดา + คอมมาอัตโนมัติ (js-comma) — ไม่ใช้ type=number
                        // ค่าที่เก็บใน currentItems เป็นค่าดิบไม่มีคอมมาเสมอ (updateItem ถอดให้)
                        var cls = 'form-control form-control-sm qitem-input qitem-' + c.key + (c.num ? ' text-end' : '');
                        var rc = revClasses(c.key, edges);
                        var tdcls = rc ? ' class="'+rc+'"' : '';
                        var val = c.num ? commaFmt(row[c.key], 2) : (row[c.key] == null ? '' : row[c.key]);
                        // ช่องรหัสสินค้า → ค้นชื่อ/ราคา/รายละเอียดมาเติมช่องที่ว่าง (oninput + debounce)
                        var oncode = (c.key === 'code') ? '; lookupItem('+idx+',this.value)' : '';
                        // ช่อง VAT = คำนวณอัตโนมัติอย่างเดียว → ห้ามแก้เอง (readonly, ไม่รับ oninput)
                        if (c.key === 'price_vat'){
                            body += '<td'+tdcls+'><input type="text" class="'+cls+' qitem-readonly"'
                                 +  ' value="'+esc(val)+'" readonly tabindex="-1"'
                                 +  ' title="คำนวณอัตโนมัติจากราคา (VAT '+(VAT_RATE*100)+'%)"></td>';
                            return;
                        }
                        var numAttr = c.num ? ' inputmode="decimal" autocomplete="off"' : '';
                        body += '<td'+tdcls+'><input type="text" class="'+cls+(c.num ? ' js-comma' : '')+'"'+numAttr
                             +  ' value="'+esc(val)+'" oninput="updateItem('+idx+',\''+c.key+'\',this.value)'+oncode+'"></td>';
                    });
                    body += '<td class="text-center"><button type="button" class="btn btn-sm btn-icon btn-label-danger" title="ลบ" onclick="removeItemRow('+idx+')"><i class="ti ti-trash"></i></button></td>';
                    body += '</tr>';
                });
            }
            $('#quotationItems').html(body);
            // เปลี่ยนรูปแบบตาราง (คอลัมน์ VAT อาจเพิ่งโผล่มา) → เติม VAT ให้แถวที่ยังว่าง
            recalcAllVat();
            qAutoGrowAll();   // ค่าที่โหลดมาจากใบเดิมต้องขยายช่องให้พอดีด้วย
        }

        // ────────────────────────────────────────────────────────
        //  ช่องในตารางรายการโตตามข้อความที่พิมพ์ (16/10/2569) — แพทเทิร์นเดียวกับ oiAutoGrow() ของฟอร์มใบสั่งซื้อ
        //  วัดความกว้างข้อความด้วย canvas แล้วตั้ง min-width แบบ inline (ไม่ใช่ width — input ยังเต็มช่อง
        //  ส่วน <td> ถูกบังคับให้กว้างตาม ตารางขยายได้เพราะอยู่ใน .table-responsive)
        //  พื้นขั้นต่ำต่อชนิดช่อง = Q_BASE_W (ต้องตรงกับ CSS .qitem-input ด้านบน)
        // ────────────────────────────────────────────────────────
        var Q_BASE_W = {code: 150, name: 200, num: 72, text: 110},
            Q_MAX_W  = 480,     // กันช่องเดียวบานจนตารางอ่านไม่ไหว
            _qCanvas = null;

        function qBaseWidth(el){
            if (el.classList.contains('qitem-code')) return Q_BASE_W.code;
            if (el.classList.contains('qitem-name')) return Q_BASE_W.name;
            return el.classList.contains('text-end') ? Q_BASE_W.num : Q_BASE_W.text;
        }
        function qAutoGrow(el){
            if (!el || !el.classList || !el.classList.contains('qitem-input')) return;
            var cs = getComputedStyle(el);
            if (!cs.fontSize || parseFloat(cs.fontSize) === 0) return;   // modal ยังซ่อนอยู่ วัดไม่ได้
            if (!_qCanvas) _qCanvas = document.createElement('canvas').getContext('2d');
            _qCanvas.font = cs.fontWeight + ' ' + cs.fontSize + ' ' + cs.fontFamily;
            var pad = parseFloat(cs.paddingLeft)     + parseFloat(cs.paddingRight)
                    + parseFloat(cs.borderLeftWidth) + parseFloat(cs.borderRightWidth);
            var w = _qCanvas.measureText(el.value || '').width + pad + 14;   // 14 = เผื่อ caret
            el.style.minWidth = Math.min(Math.max(Math.ceil(w), qBaseWidth(el)), Q_MAX_W) + 'px';
        }
        function qAutoGrowAll(scope){
            $(scope || '#quotationItems').find('.qitem-input').each(function(){ qAutoGrow(this); });
        }
        // input = พิมพ์เอง · change/blur = js-comma จัดรูปแบบตัวเลขใหม่
        $(document).on('input change blur', '#quotationItems .qitem-input', function(){ qAutoGrow(this); });
        $(function(){ $('#quotationModal').on('shown.bs.modal', function(){ qAutoGrowAll(); }); });

        // คอลัมน์นี้เป็นตัวเลขไหม (ใช้ตัดสินว่าต้องถอดคอมมา/ใส่คอมมา)
        function isNumCol(key){ return !!(COL_REG[key] && COL_REG[key].num); }

        function updateItem(idx, key, val){
            var row = currentItems[idx];
            if (!row) return;
            // เก็บค่าดิบ (ไม่มีคอมมา) ลง data model เสมอ — ส่วนที่แสดงบนช่องค่อยใส่คอมมาให้
            row[key] = isNumCol(key) ? stripCommas(val) : val;
            // ผู้ใช้แก้ช่องนี้เอง → ไม่ถือเป็น auto-fill อีก (กันโดนล้างตอนรหัสไม่เจอ)
            if (row.__auto && row.__auto[key]) delete row.__auto[key];

            // ── ราคา (บาท/กก) อัตโนมัติ — แก้ช่องราคาส่วนประกอบข้างหน้า → รวมลงช่องราคา (16/10/2569) ──
            if (priceParts().indexOf(key) >= 0){
                recalcPriceKg(idx);
            }

            // ── VAT อัตโนมัติ — แก้ราคาแล้ว VAT ต้องตามทันที ──
            if (key === 'price_kg' || key === 'new_price'){
                recalcVat(idx);
            }
        }

        // ────────────────────────────────────────────────────────
        //  ราคา (บาท/กก) = ผลรวมช่องราคาส่วนประกอบที่อยู่ข้างหน้า (16/10/2569)
        //  - ทั่วไป (1.2 / 1.3 / 1.4 / อัตโนมัติ): ราคาเม็ดพลาสติก + ค่าผลิต(และค่าแม่สี) + ค่าแม่สี + % สูญเสีย
        //  - 2.3: "รวมราคา ใหม่" = ค่าผลิต ใหม่ + ค่าแม่สี ใหม่
        //  นับเฉพาะคอลัมน์ที่แสดงอยู่ในรูปแบบที่เลือก · คำนวณเฉพาะตอนผู้ใช้แก้ช่องส่วนประกอบ
        //  (ไม่คำนวณทับตอนเปิดใบเดิม) · ช่องราคายังพิมพ์ทับเองได้
        // ────────────────────────────────────────────────────────
        function priceParts(){
            var parts = ($('#q_col_format').val() === '2.3')
                ? ['new_process_fee', 'new_pigment_price']
                : ['resin_price', 'process_fee', 'pigment_price', 'loss_pct'];   // % สูญเสีย บวกตรง ๆ ตามที่ผู้ใช้สั่ง
            var shown = activeCols().map(function(c){ return c.key; });
            if (shown.indexOf('price_kg') < 0) return [];
            return parts.filter(function(k){ return shown.indexOf(k) >= 0; });
        }
        function recalcPriceKg(idx){
            var row = currentItems[idx];
            if (!row) return;
            var sum = 0, any = false;
            priceParts().forEach(function(k){
                var n = toNum(row[k]);
                if (n !== null){ sum += n; any = true; }
            });
            if (!any) return;   // ไม่ได้กรอกส่วนประกอบเลย → ไม่แตะราคาที่พิมพ์ไว้
            var val = (Math.round(sum * 100) / 100).toFixed(2);
            row.price_kg = val;
            if (row.__auto) delete row.__auto.price_kg;
            setCellInput(idx, 'price_kg', val);
            recalcVat(idx);
        }

        // ────────────────────────────────────────────────────────
        //  คำนวณ VAT อัตโนมัติ  (รวม VAT = ราคา × (1 + อัตรา))
        //  ฐานคิด = "ราคาใหม่" ถ้ากรอกไว้ ไม่งั้นใช้ "ราคา (บาท/กก)"
        //  — ใบขอปรับราคา (2.1) คอลัมน์ VAT คือ "รวม Vat ใหม่" จึงต้องคิดจากราคาใหม่
        //  ช่อง VAT เป็น readonly — แก้เองไม่ได้ ค่าที่แสดง/บันทึกมาจากสูตรนี้เสมอ
        // ────────────────────────────────────────────────────────
        var VAT_RATE = 0.07;   // ภาษีมูลค่าเพิ่ม 7%

        function toNum(v){
            var s = String(v == null ? '' : v).replace(/,/g, '').trim();
            if (s === '') return null;
            var n = parseFloat(s);
            return isNaN(n) ? null : n;
        }
        // ราคาที่ใช้เป็นฐานคิด VAT ของแถวนี้ (ไม่มีเลย = null)
        //  ใช้ "ราคาใหม่" เฉพาะตอนคอลัมน์นั้นแสดงอยู่ในรูปแบบที่เลือก (16/10/2569) — เดิมใช้เสมอถ้ามีค่า
        //  ⇒ กรอกราคาใหม่ไว้ในโหมดอื่นแล้วสลับมา 1.1 (ไม่มีคอลัมน์ราคาใหม่) VAT คิดจากค่าที่มองไม่เห็น
        function vatBase(row){
            var newShown = activeCols().some(function(c){ return c.key === 'new_price'; });
            var n = newShown ? toNum(row.new_price) : null;
            return (n !== null) ? n : toNum(row.price_kg);
        }
        function vatOf(base){ return Math.round(base * (1 + VAT_RATE) * 100) / 100; }

        // คอลัมน์ VAT แสดงอยู่ในรูปแบบตารางที่เลือกไหม (เช่น 2.2 / 2.3 ไม่มีคอลัมน์นี้)
        // ไม่แสดง = ไม่ต้องคำนวณ กันค่าที่ผู้ใช้ไม่เห็นหลุดลงฐานข้อมูล
        function vatColShown(){
            return activeCols().some(function(c){ return c.key === 'price_vat'; });
        }

        // เขียนค่าลงช่องในตารางโดยไม่ re-render (คง focus/เคอร์เซอร์ช่องที่กำลังพิมพ์)
        function setCellInput(idx, key, val){
            var pos = -1;
            activeCols().forEach(function(c, i){ if (c.key === key) pos = i; });
            if (pos < 0) return;
            var $in = $('#quotationItems tr').eq(idx).find('input').eq(pos)
                .val(isNumCol(key) ? commaFmt(val, 2) : val);
            qAutoGrow($in[0]);   // ตั้งค่าด้วย .val() ไม่ยิง event ต้องสั่งขยายเอง
        }

        function recalcVat(idx){
            var row = currentItems[idx];
            if (!row || !vatColShown()) return;
            var base = vatBase(row);
            var val  = (base === null) ? '' : vatOf(base).toFixed(2);
            if (String(row.price_vat == null ? '' : row.price_vat) === val) return;
            row.price_vat = val;
            setCellInput(idx, 'price_vat', val);
        }
        function recalcAllVat(){
            currentItems.forEach(function(row, idx){ recalcVat(idx); });
        }

        // ── ค้นข้อมูลสินค้าจากรหัส (oninput + debounce) เติมช่องที่ว่าง / ไม่เจอ = เอาที่เติมไว้ออก ──
        var itemLookupTimer = null, itemLookupXhr = null;
        function lookupItem(idx, code){
            code = (code || '').trim();
            clearTimeout(itemLookupTimer);
            itemLookupTimer = setTimeout(function(){ applyItemLookup(idx, code); }, 350);
        }
        function clearAutoFilled(row){
            if (row.__auto){
                Object.keys(row.__auto).forEach(function(k){ row[k] = ''; });
                row.__auto = {};
            }
        }
        // อัปเดตค่าในช่องของแถวนั้นจาก data model โดยไม่ re-render (คง focus/เคอร์เซอร์ช่องรหัส)
        function refreshRowInputs(idx){
            var $inputs = $('#quotationItems tr').eq(idx).find('input');
            // ต้องไล่ตามคอลัมน์ที่ "แสดงอยู่จริง" (activeCols) ไม่ใช่ ALL_COLS
            // ไม่งั้นเวลาเลือกรูปแบบ (เช่น 2.2/2.3) ลำดับช่องจะเลื่อน แล้วค่าที่ค้นมาไปลงผิดช่อง
            activeCols().forEach(function(c, i){
                if (c.key === 'code') return;   // อย่าแตะช่องที่กำลังพิมพ์
                var v = currentItems[idx][c.key];
                $inputs.eq(i).val(c.num ? commaFmt(v, 2) : (v == null ? '' : v));
                qAutoGrow($inputs[i]);   // ค่าที่ค้นมาเติมด้วย .val() ไม่ยิง event
            });
        }
        function applyItemLookup(idx, code){
            var row = currentItems[idx];
            if (!row) return;
            clearAutoFilled(row);              // ล้างที่เคยเติมไว้ก่อน (เผื่อรหัสเปลี่ยน/ไม่เจอ)
            if (!code){ recalcVat(idx); refreshRowInputs(idx); return; }
            if (itemLookupXhr) itemLookupXhr.abort();
            itemLookupXhr = $.getJSON("{{ $page_url }}/item-lookup", {code: code}, function(res){
                if (currentItems[idx] !== row) return;   // แถวเปลี่ยนระหว่างรอผล
                if (res.found && res.cells){
                    row.__auto = {};
                    Object.keys(res.cells).forEach(function(k){
                        var cur = row[k];
                        if (cur === undefined || cur === null || String(cur).trim() === ''){
                            row[k] = res.cells[k];
                            row.__auto[k] = true;   // จำว่าเติมอัตโนมัติ
                        }
                    });
                    // ราคาที่ค้นมาเปลี่ยน → VAT ต้องตามไปด้วย (เว้นแถวที่ผู้ใช้พิมพ์ VAT เอง)
                    recalcVat(idx);
                }
                refreshRowInputs(idx);
            }).fail(function(){ refreshRowInputs(idx); });
        }

        function addQuotationItem(){ currentItems.push({}); renderItems(); }
        function removeItemRow(idx){
            currentItems.splice(idx, 1);
            if (!currentItems.length) currentItems.push({});
            renderItems();
        }
        function setItems(items){
            currentItems = (items && items.length) ? items : [{}, {}];
            renderItems();   // renderItems → recalcAllVat: VAT ของใบเก่าคำนวณใหม่ตามราคาปัจจุบันเสมอ
        }

        // ────────────────────────────────────────────────────────
        //  ค้นชื่อลูกค้าจากรหัส (เติมชื่อไทย/อังกฤษ/เทอมอัตโนมัติ)
        // ────────────────────────────────────────────────────────
        // เรียกจาก oninput → debounce กันยิง AJAX ทุกตัวอักษร, ไม่เด้ง popup ระหว่างพิมพ์
        var custLookupTimer = null, custLookupXhr = null;
        function lookupCustomer(code){
            code = (code || '').trim();
            clearTimeout(custLookupTimer);
            if (!code){ $('#q_CustName').val(''); return; }
            custLookupTimer = setTimeout(function(){
                if (custLookupXhr) custLookupXhr.abort();
                custLookupXhr = $.getJSON("{{ $page_url }}/customer/" + encodeURIComponent(code), function(res){
                    // กันผลเก่ามาทับ: เช็คว่ารหัสในช่องยังตรงกับที่ค้นอยู่
                    if ($('#q_Custid').val().trim() !== code) return;
                    if (res.found){
                        $('#q_CustName').val(res.name || '');
                        // ลูกค้าไม่มีชื่ออังกฤษ = ล้างช่อง (16/10/2569) — เดิมเติมเฉพาะตอนมีค่า ชื่อของลูกค้าก่อนหน้าจึงค้าง
                        $('#q_Engname').val(res.nameEN || '');
                        // เทอมการชำระเงิน — ดึงจาก customer.term มาเติมให้ (ถ้าช่องยังว่าง)
                        // ยกเว้นค่า "CASH" (เงินสด) ที่ไม่ต้องการให้ขึ้นบนใบเสนอราคา → ปล่อยช่องว่างไว้
                        if (res.term && !$('#q_Term').val() && String(res.term).trim().toUpperCase() !== 'CASH') {
                            $('#q_Term').val(res.term);
                        }
                    } else {
                        // ไม่เจอ → เคลียร์ชื่อไทย + อังกฤษ เงียบๆ (ไม่เด้ง popup)
                        $('#q_CustName').val('');
                        $('#q_Engname').val('');
                    }
                });
            }, 350);
        }

        // ────────────────────────────────────────────────────────
        //  หมายเหตุอื่น (เพิ่มได้ไม่จำกัด) — เก็บเป็น input name="other_notes[]"
        // ────────────────────────────────────────────────────────
        function noteRowHtml(val){
            return '<div class="input-group mb-2 note-row">'
                + '<input type="text" name="other_notes[]" class="form-control" maxlength="255" value="'+esc(val || '')+'">'
                + '<button type="button" class="btn btn-outline-danger" onclick="removeNoteRow(this)" title="ลบ"><i class="ti ti-trash"></i></button>'
                + '</div>';
        }
        function addNoteRow(val){
            $('#otherNotesList').append(noteRowHtml(typeof val === 'string' ? val : ''));
        }
        function removeNoteRow(btn){ $(btn).closest('.note-row').remove(); }
        function renderNotes(arr){
            $('#otherNotesList').empty();
            (arr && arr.length ? arr : []).forEach(function(n){ addNoteRow(n); });
        }

        // สลับภาษา section หมายเหตุ — เปลี่ยนแค่คำ (label) ข้อมูลกรอกชุดเดียว
        function setRemarkLang(lang){
            lang = (lang === 'en') ? 'en' : 'th';
            var sec = document.getElementById('remarkSection');
            sec.classList.toggle('lang-en', lang === 'en');
            sec.classList.toggle('lang-th', lang !== 'en');
            $('#q_remark_lang').val(lang);
            $('#btnLangEn').toggleClass('active', lang === 'en');
            $('#btnLangTh').toggleClass('active', lang !== 'en');
        }

        // ────────────────────────────────────────────────────────
        //  เปิดฟอร์มสร้างใหม่
        // ────────────────────────────────────────────────────────
        function openCreate(){
            document.getElementById('quotationForm').reset();
            $('#q_mode').val('insert');
            $('#q_qno_key').val('');
            $('#quotationModalTitle').text('สร้างใบเสนอราคา');
            $('#q_Qno').prop('readonly', false);
            // วันที่เสนอราคา = วันนี้ (ผ่าน flatpickr); เคลียร์ช่องวันที่อื่น (reset() ไม่ล้าง state flatpickr)
            setFp('q_Qdate', new Date().toISOString().slice(0,10));
            setFp('q_Revisedate', '');
            setFp('q_ValidFrom', '');
            setFp('q_Validto', '');
            $('#q_col_format').val('');   // เริ่มที่โหมดอัตโนมัติ (พฤติกรรมเดิม)
            onColFormatChange();
            setItems();
            renderNotes([]);   // เคลียร์หมายเหตุอื่น (reset() ไม่ล้าง input ที่ append เข้ามา)
            setRemarkLang('th');   // เริ่มที่ภาษาไทย
            $('#q_letterhead').val('WH');   // หัวกระดาษเริ่มต้น = WH (ตรงกับ prefix เลขที่ default)
            refreshPickers('#quotationForm');   // ให้ selectpicker วาดปุ่มตามค่าที่เพิ่ง set
            // ขอเลขที่ถัดไปตาม prefix ของหัวกระดาษ (แก้ไขได้)
            $.getJSON("{{ $page_url }}/next-qno", {prefix: $('#q_letterhead').val()}, function(res){
                if (res.qno) $('#q_Qno').val(res.qno);
            });
            new bootstrap.Modal('#quotationModal').show();
        }

        // เปลี่ยนหัวกระดาษ (เฉพาะตอนสร้างใหม่) → ออกเลขที่ใหม่ตาม prefix ของหัวกระดาษที่เลือก
        function onLetterheadChange(){
            if ($('#q_mode').val() !== 'insert') return;   // โหมดแก้ไข: ไม่เปลี่ยนเลขที่ (เป็น key)
            $.getJSON("{{ $page_url }}/next-qno", {prefix: $('#q_letterhead').val()}, function(res){
                if (res.qno) $('#q_Qno').val(res.qno);
            });
        }

        // ผู้สร้างของใบที่เปิดแก้ไขอยู่ {name} — null = ใบใหม่ / ใบเก่าที่ไม่มีผู้สร้าง (ไม่ต้องป้อนรหัสผ่าน)
        var qCreator = null;

        // ────────────────────────────────────────────────────────
        //  แก้ไข — ดึงข้อมูลเดิมมาเติมฟอร์ม
        // ────────────────────────────────────────────────────────
        //  asCopy = true → "คัดลอกเป็นใบใหม่" (16/10/2569): เติมข้อมูลใบเก่าแล้วสลับเป็นโหมดสร้างใหม่ (ดูท้ายฟังก์ชัน)
        function quotationEdit(qno, asCopy){
            $.getJSON("{{ $page_url }}/edit", {qno: qno}, function(res){
                if (res.error){ Swal.fire('ไม่พบข้อมูล', qno, 'error'); return; }
                var h = res.header || {};
                qCreator = res.creator || null;   // ผู้สร้างใบ — มี = ตอนบันทึกต้องป้อนรหัสผ่านของคนนี้
                document.getElementById('quotationForm').reset();
                $('#q_mode').val('update');
                $('#q_qno_key').val(h.Qno);
                $('#quotationModalTitle').text('แก้ไขใบเสนอราคา ' + (h.Qno || ''));
                $('#q_Qno').val((h.Qno || '').trim()).prop('readonly', true);   // ห้ามเปลี่ยนเลขที่
                setFp('q_Qdate', h.Qdate);
                setFp('q_Revisedate', h.Revisedate);
                setFp('q_ValidFrom', h.ValidFrom);
                setFp('q_Validto', h.Validto);
                $('#q_PDtype').val(h.PDtype);
                $('#q_letterhead').val(h.letterhead || 'WH');
                $('#q_exam').prop('checked', h.exam == 1);
                // แสดงรหัสสินค้าใน PDF: ติ๊กไว้ถ้า col_config ที่บันทึกไว้ของใบนี้มีคอลัมน์ "code"
                var savedCols = res.col_config || [];
                $('#q_show_code').prop('checked', savedCols.some(function (c) { return c.key === 'code'; }));
                // รูปแบบตาราง: เทียบ col_config ที่บันทึกไว้กับ preset — ตรงกับอันไหน = ใบนี้ใช้รูปแบบนั้น
                $('#q_col_format').val(detectColFormat(savedCols));
                refreshPickers('#quotationForm');   // ให้ selectpicker วาดปุ่มตามค่าที่โหลดมา
                onColFormatChange();
                $('#q_EmpID').val(h.EmpID);
                $('#q_Custid').val(h.Custid);
                // ชื่อไทยใช้จาก customer (join) ถ้ามี ไม่งั้น fallback CustName เดิม
                $('#q_CustName').val((res.cust && res.cust.name) ? res.cust.name : (h.CustName || ''));
                $('#q_Engname').val(h.Engname || (res.cust ? res.cust.nameEN : '') || '');
                $('#q_Qremark').val(h.Qremark);
                $('#q_Term').val(h.Term);
                // ── section หมายเหตุ (ช่องใหม่) ──
                $('#q_resin_price_note').val(h.resin_price_note || '');
                $('#q_delivery_place').val(h.delivery_place || '');
                $('#q_delivery_term').val(h.delivery_term || '');
                var otherNotes = [];
                try { otherNotes = h.other_notes ? JSON.parse(h.other_notes) : []; } catch (e) { otherNotes = []; }
                renderNotes(otherNotes);
                setRemarkLang(h.remark_lang === 'en' ? 'en' : 'th');   // ภาษาที่เคยเลือกไว้
                // รายการ: ใช้ค่าแบน (cells) จาก server ตรงๆ (ฟอร์มโชว์ทุกคอลัมน์)
                var items = (res.items || []).map(function(d){ return Object.assign({}, d.cells || {}); });
                setItems(items);
                if (asCopy) toCopyMode((h.Qno || '').trim());
                new bootstrap.Modal('#quotationModal').show();
            }).fail(function(){ Swal.fire('เกิดข้อผิดพลาด', 'โหลดข้อมูลไม่สำเร็จ', 'error'); });
        }

        // ────────────────────────────────────────────────────────
        //  คัดลอกเป็นใบใหม่ (16/10/2569) — ใช้ข้อมูลใบเก่าเป็นตั้งต้น บันทึกผ่าน insert ตามปกติ
        // ────────────────────────────────────────────────────────
        function quotationCopy(qno){
            quotationEdit(qno, true);
        }

        // สลับฟอร์มที่เติมข้อมูลใบเก่าแล้ว → โหมดสร้างใหม่: เลขที่ใหม่ · วันที่เสนอราคา = วันนี้ · ล้างวันที่แก้ไข/ช่วงยืนราคา
        function toCopyMode(fromQno){
            qCreator = null;   // ใบใหม่ — ผู้สร้างคือคนที่กดบันทึก ไม่ต้องป้อนรหัสผ่าน
            $('#q_mode').val('insert');
            $('#q_qno_key').val('');
            $('#quotationModalTitle').text('สร้างใบเสนอราคา (คัดลอกจาก ' + fromQno + ')');
            $('#q_Qno').val('').prop('readonly', false);
            setFp('q_Qdate', new Date().toISOString().slice(0,10));
            setFp('q_Revisedate', '');
            setFp('q_ValidFrom', '');
            setFp('q_Validto', '');
            // เลขที่ถัดไปตาม prefix ของหัวกระดาษของใบเก่า (แก้ไขได้)
            $.getJSON("{{ $page_url }}/next-qno", {prefix: $('#q_letterhead').val()}, function(res){
                if (res.qno) $('#q_Qno').val(res.qno);
            });
        }

        // ตัดเวลาออกจาก datetime → 'YYYY-MM-DD' สำหรับ input[type=date]
        function dateOnly(v){
            if (!v) return '';
            return String(v).substring(0,10);
        }

        // ────────────────────────────────────────────────────────
        //  บันทึก (create/update)
        // ────────────────────────────────────────────────────────
        function saveQuotation(){
            var form = document.getElementById('quotationForm');

            // ── ตรวจช่องที่ required ด้วย native validation ──
            if (!form.checkValidity()) { form.reportValidity(); return; }

            var mode = $('#q_mode').val();
            // แก้ไขใบที่มีผู้สร้าง → ต้องป้อนรหัสผ่านของผู้สร้างใบ (server ตรวจซ้ำอีกชั้นใน update())
            var needPassword = mode === 'update' && !!qCreator;

            // ── ยืนยันก่อนบันทึก ──
            var opt = {
                title: mode === 'update' ? 'ยืนยันการแก้ไข?' : 'ยืนยันการบันทึก?',
                text: 'เลขที่ใบเสนอราคา ' + $('#q_Qno').val().trim(),
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'ยืนยัน',
                cancelButtonText: 'ยกเลิก',
                confirmButtonColor: '#54BAB9',
            };
            if (needPassword) {
                opt.input = 'password';
                opt.inputLabel = 'รหัสผ่านของผู้สร้างใบ: ' + qCreator.name;
                opt.inputAttributes = { autocomplete: 'new-password' };
                opt.inputValidator = function(v){ return v ? null : 'กรุณาป้อนรหัสผ่านของผู้สร้างใบ'; };
                // Swal ที่มีช่องกรอกต้องอยู่ใน modal ไม่งั้น focus trap ของ Bootstrap ดึงโฟกัสกลับ พิมพ์ไม่ได้
                opt.target = document.getElementById('quotationModal');
                opt.heightAuto = false;
            }
            Swal.fire(opt).then(function(result){
                if (result.isConfirmed) submitQuotation(mode, needPassword ? result.value : null);
            });
        }

        // ส่งข้อมูลจริงหลังผู้ใช้กดยืนยัน (แยกจาก saveQuotation เพื่อคั่นด้วย confirm)
        function submitQuotation(mode, creatorPassword){
            var form = document.getElementById('quotationForm');
            var url  = mode === 'update' ? "{{ $page_url }}/update" : "{{ $page_url }}/insert";
            var fd = new FormData(form);
            fd.append('_token', '{{ csrf_token() }}');
            if (creatorPassword) fd.append('creator_password', creatorPassword);
            // ตัด field ภายใน (__auto) ออกก่อนส่ง
            var cleanItems = currentItems.map(function(r){
                var o = {}; Object.keys(r).forEach(function(k){ if (k !== '__auto') o[k] = r[k]; }); return o;
            });
            fd.append('items_json', JSON.stringify(cleanItems));   // ข้อมูลรายการ (server จะ derive คอลัมน์ที่แสดงเอง)

            $.ajax({
                url: url, type: 'POST', data: fd, contentType: false, processData: false,
                success: function(res){
                    if (res.ok){
                        bootstrap.Modal.getInstance(document.getElementById('quotationModal')).hide();
                        Swal.fire('บันทึกเรียบร้อย', 'เลขที่ ' + res.qno, 'success');
                        loadData(page);
                    } else {
                        Swal.fire('ไม่สำเร็จ', res.error || 'ไม่ทราบสาเหตุ', 'error');
                    }
                },
                error: function(xhr){
                    var msg = (xhr.responseJSON && xhr.responseJSON.error) ? xhr.responseJSON.error : 'เกิดข้อผิดพลาด';
                    Swal.fire('ไม่สำเร็จ', msg, 'error');
                }
            });
        }

        // ────────────────────────────────────────────────────────
        //  ดูรายละเอียด / พิมพ์
        // ────────────────────────────────────────────────────────
        function quotationView(qno){
            var el = document.getElementById('quotationViewModal');
            $('#quotationViewBody').html('<div class="text-center py-5 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>กำลังโหลด...</div>');
            new bootstrap.Modal(el).show();
            $.get("{{ $page_url }}/show", {qno: qno}, function(html){
                $('#quotationViewBody').html(html);
            }).fail(function(){
                $('#quotationViewBody').html('<div class="text-center py-5 text-danger">ไม่พบข้อมูล</div>');
            });
        }

        // ขั้นแรก: เปิดรายชื่อลูกค้าทั้งหมดที่มีใบเสนอราคา
        function quotationCustomers(){
            var el = document.getElementById('quotationCustomersModal');
            $('#quotationCustomersBody').html('<div class="text-center py-5 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>กำลังโหลด...</div>');
            new bootstrap.Modal(el).show();
            $.get("{{ $page_url }}/customers", function(html){
                $('#quotationCustomersBody').html(html);
            }).fail(function(){
                $('#quotationCustomersBody').html('<div class="text-center py-5 text-danger">โหลดรายชื่อลูกค้าไม่สำเร็จ</div>');
            });
        }

        // ขั้นสอง: เปิดประวัติใบเสนอราคาทั้งหมดของลูกค้า (จับคู่ด้วย Custid)
        function quotationHistory(custid){
            var el = document.getElementById('quotationHistoryModal');
            $('#quotationHistoryBody').html('<div class="text-center py-5 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>กำลังโหลด...</div>');
            new bootstrap.Modal(el).show();
            $.get("{{ $page_url }}/history", {custid: custid}, function(html){
                $('#quotationHistoryBody').html(html);
            }).fail(function(){
                $('#quotationHistoryBody').html('<div class="text-center py-5 text-danger">โหลดประวัติไม่สำเร็จ</div>');
            });
        }

        // รองรับ modal ซ้อน (ประวัติ → ดูรายละเอียด) — ยก z-index ตัวบนสุด + คง scroll-lock
        $(document).on('show.bs.modal', '.modal', function () {
            var zIndex = 1056 + (10 * $('.modal.show').length);
            var self = this;
            $(self).css('z-index', zIndex);
            setTimeout(function () {
                $('.modal-backdrop').not('.modal-stack').last()
                    .css('z-index', zIndex - 1).addClass('modal-stack');
            }, 0);
        });
        $(document).on('hidden.bs.modal', '.modal', function () {
            if ($('.modal.show').length) { $('body').addClass('modal-open'); }
        });

        // ถามก่อนพิมพ์ว่าจะพิมพ์หัวกระดาษไหม (16/10/2569) → cb(true = พิมพ์หัวกระดาษ / false = ไม่พิมพ์)
        // ปุ่มพิมพ์เปิดหน้าพิมพ์ใน iframe ซ่อนแล้วสั่งพิมพ์ทันที ผู้ใช้จึงไม่เห็นแถบปุ่มของหน้าพิมพ์ ต้องถามตรงนี้
        function askLetterhead(cb){
            Swal.fire({
                title: 'พิมพ์หัวกระดาษด้วยไหม?',
                icon: 'question',
                showDenyButton: true,
                showCancelButton: true,
                confirmButtonText: 'พิมพ์พร้อมหัวกระดาษ',
                denyButtonText: 'ไม่พิมพ์หัวกระดาษ',
                cancelButtonText: 'ยกเลิก',
                heightAuto: false
            }).then(function(r){
                if (r.isConfirmed) cb(true);
                else if (r.isDenied) cb(false);
            });
        }

        function quotationPrint(qno){
            askLetterhead(function(withLh){ doQuotationPrint(qno, withLh); });
        }
        function doQuotationPrint(qno, withLh){
            // พิมพ์ในหน้าเดิมผ่าน iframe ซ่อน (ไม่เปิดแท็บ/หน้าต่างใหม่)
            var frame = document.getElementById('printFrame');
            if (!frame){
                frame = document.createElement('iframe');
                frame.id = 'printFrame';
                frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
                document.body.appendChild(frame);
            }
            frame.onload = function(){
                try { frame.contentWindow.focus(); frame.contentWindow.print(); }
                catch (e) { console.error(e); }
            };
            frame.src = "{{ $page_url }}/print?qno=" + encodeURIComponent(qno) + (withLh ? '' : '&lh=0');
        }

        // ── พิมพ์ตัวอย่างจากฟอร์มที่ยังไม่บันทึก ──
        // fetch POST ข้อมูลฟอร์ม (+ items_json) → รับ HTML → ยัดเข้า iframe ซ่อนด้วย srcdoc แล้วสั่งพิมพ์
        // ไม่เปิดหน้า/แท็บใหม่, ไม่บันทึก DB, ไม่บังคับกรอกครบ — ดูตัวอย่างได้ทันที
        function quotationPrintPreview(){
            askLetterhead(doQuotationPrintPreview);
        }
        function doQuotationPrintPreview(withLh){
            var fd = new FormData(document.getElementById('quotationForm'));   // รวม other_notes[] ครบ
            fd.append('_token', '{{ csrf_token() }}');
            if (!withLh) fd.append('lh', '0');   // ไม่พิมพ์หัวกระดาษ
            // รายการสินค้า — ส่งเป็น items_json เหมือนตอนบันทึก (ตัด __auto ออก)
            var cleanItems = currentItems.map(function(r){
                var o = {}; Object.keys(r).forEach(function(k){ if (k !== '__auto') o[k] = r[k]; }); return o;
            });
            fd.append('items_json', JSON.stringify(cleanItems));

            fetch("{{ $page_url }}/print-preview", {
                method: 'POST', body: fd, headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(function(res){ return res.text(); })
            .then(function(html){
                // iframe แยกสำหรับพิมพ์ตัวอย่าง (ไม่ชนกับ printFrame ของปุ่มพิมพ์ในตาราง)
                var frame = document.getElementById('printPreviewFrame');
                if (!frame){
                    frame = document.createElement('iframe');
                    frame.id = 'printPreviewFrame';
                    frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
                    document.body.appendChild(frame);
                }
                frame.onload = function(){
                    try { frame.contentWindow.focus(); frame.contentWindow.print(); }
                    catch (e) { console.error(e); }
                };
                frame.srcdoc = html;   // โหลดในหน้าเดิม → ไม่เปิดแท็บใหม่
            })
            .catch(function(e){
                console.error(e);
                Swal.fire('พิมพ์ตัวอย่างไม่สำเร็จ', 'โหลดตัวอย่างไม่สำเร็จ', 'error');
            });
        }

        // ────────────────────────────────────────────────────────
        //  DataTable filter machinery (คงเดิม)
        // ────────────────────────────────────────────────────────
        // เก็บ filter สด (เฉพาะที่มีค่า) ทุกครั้ง — ไม่สะสมค่าเก่า
        function collectSearchData(){
            var data = {};
            $('.p_search').each(function(){
                var v = $(this).val();
                if (v !== '' && v !== null) data[$(this).attr('name')] = v;
            });
            return data;
        }

        // อัปเดตปุ่มล้างตัวกรองตามจำนวน filter ที่ใช้อยู่ (ไม่นับ limit)
        function updateFilterButtonState(){
            var count = 0;
            $('.p_search:not([name="limit"]):not([name="sort_col"]):not([name="sort_dir"])').each(function(){
                var v = $(this).val();
                if (v !== '' && v !== null) count++;
            });
            var $btn = $('#btnResetFilters');
            if (count > 0) { $btn.removeClass('btn-label-secondary').addClass('btn-danger'); $btn.find('.filter-count').text('('+count+')'); }
            else           { $btn.removeClass('btn-danger').addClass('btn-label-secondary'); $btn.find('.filter-count').text(''); }

            renderFilterSummary();
        }

        // ── รายละเอียดการค้นหา (โชว์ตอนพับตัวกรอง) — ป้ายชื่อ FILTER_LABELS ประกาศไว้ต้นสคริปต์ ──
        // escape ค่าที่ผู้ใช้พิมพ์ก่อนยัดลง HTML (กัน XSS จากคำค้น)
        function escHtml(s){ return $('<div>').text(s == null ? '' : s).html(); }

        function renderFilterSummary(){
            var chips = [];
            $('.p_search:not([name="limit"]):not([name="sort_col"]):not([name="sort_dir"])').each(function(){
                var label = FILTER_LABELS[$(this).attr('name')];
                if (!label) return;
                // ตัดสินว่า "ไม่ได้กรอง" จาก value เสมอ — ตัวเลือก "ทั้งหมด" มี value ว่างแต่มีข้อความ
                var raw = $(this).val();
                if (raw === '' || raw === null) return;
                // select: แสดงข้อความของตัวเลือก ไม่ใช่ value
                var val = $(this).is('select') ? $(this).find('option:selected').text().trim() : raw;
                chips.push('<span class="badge bg-label-primary fw-normal">'
                    + '<span class="text-dark fw-medium">' + escHtml(label) + ':</span> '
                    + escHtml(val) + '</span>');
            });
            $('#filterSummary').html(chips.join(''));   // ไม่มีตัวกรอง = ปล่อยว่าง
        }

        // หมุนลูกศรตามสถานะพับ/กาง + ซ่อนแถบสรุปตอนกาง (ข้างในเห็นค่าจริงอยู่แล้ว)
        $(document).on('show.bs.collapse hide.bs.collapse', '#quotationFilterBox', function(e){
            $('#btnToggleFilters .toggle-caret')
                .toggleClass('ti-chevron-down', e.type === 'hide')
                .toggleClass('ti-chevron-up',   e.type === 'show');
            $('#filterSummary').toggleClass('d-none', e.type === 'show');
        });
        $(document).on('shown.bs.collapse', '#quotationFilterBox', function(){
            refreshPickers('#quotationFilterBox');
        });

        // กัน AJAX race: รับเฉพาะผลของ request ล่าสุด (dtXhr/dtSeq ประกาศด้านบนแล้ว)
        function loadData(pages){
            updateFilterButtonState();
            searchData = collectSearchData();
            page = pages;
            var seq = ++dtSeq;
            if (dtXhr) dtXhr.abort();
            showTableLoading();   // server ช้า — บอกผู้ใช้ว่ากำลังดึงข้อมูล (16/09/2569)
            dtXhr = $.ajax({
                type: "GET", url: pages, data: searchData,
                success: function(data){ if (seq === dtSeq) $("#table-data").html(data); },
                error: function(xhr, status){
                    if (seq !== dtSeq || status === 'abort') return;   // request เก่าถูกตัดทิ้ง = ปกติ
                    showTableError();
                },
                complete: function(){ if (seq === dtSeq) dtXhr = null; }
            });
        }

        function resetFilters(){
            // ไม่ล้าง limit + sort_col/sort_dir (เป็นการตั้งค่าแสดงผล ไม่ใช่ตัวกรอง)
            $('.p_search:not([name="limit"]):not([name="sort_col"]):not([name="sort_dir"])').each(function(){
                // flatpickr: เคลียร์ผ่าน instance ให้ปฏิทิน + ช่องว่างจริง
                if (this._flatpickr) this._flatpickr.clear();
                else $(this).val('');
            });
            refreshPickers('.card-header');   // selectpicker ของตัวกรอง — วาดปุ่มใหม่หลังล้างค่า
            loadData("{{$page_url}}/datatable");
        }
</script>
</body>

</html>
