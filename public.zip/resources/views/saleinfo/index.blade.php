<!doctype html>

<html lang="en" class="light-style layout-navbar-fixed layout-menu-fixed layout-compact" dir="ltr"
    data-theme="theme-default" data-assets-path="assets/" data-template="vertical-menu-template">

<head>
    @include('layout/inc_header')
    <title>กำหนดราคา | World Pigment</title>
</head>

<style>
/* ─── หัว modal ทรงเฉียง (ใช้ธีมเดียวกับหน้าอื่น แต่เป็นโทนส้ม/ทอง = กำหนดราคา) ─── */
.modalHeadDecor .modal-header {
    padding: 0;
}
.modalHeadDecor .modal-title {
    padding: 1.25rem 1.5rem 1.25rem;
    color: white;
    background-color: #E08A1E;
    position: relative;
}
.modalHeadDecor .modal-title::after {
    position: absolute;
    top: 0;
    right: -65px;
    content: '';
    width: 0;
    height: 0;
    border-top: 65px solid #E08A1E;
    border-right: 65px solid transparent;
}

/* ─── ปุ่มธีมกำหนดราคา ─── */
.btn-theme-saleinfo {
    background-color: #E08A1E;
    border-color: #E08A1E;
    color: #fff;
}
.btn-theme-saleinfo:hover,
.btn-theme-saleinfo:focus,
.btn-theme-saleinfo:active {
    background-color: #c4760f;
    border-color: #c4760f;
    color: #fff;
}

/* ─── หัวตารางสีเข้ม (ให้เหมือนหน้าเทียบสี) ─── */
#table-data thead.pr-thead-dark th {
    background-color: #6e6e78;
    color: #fff;
    border-color: #6e6e78;
    font-weight: 600;
    letter-spacing: .4px;
    vertical-align: middle;
}
#table-data thead.pr-thead-dark th small {
    color: rgba(255, 255, 255, .65) !important;
    letter-spacing: 0;
}

/* ─── ตารางประวัติการปรับราคา (ใน modal) — โทนส้ม/ทองให้เข้าธีมกำหนดราคา ─── */
.saleinfo-history {
    border: 1px solid #f0dfc0;
}
/* คอลัมน์กว้างเท่ากันทั้ง 6 ช่อง */
.saleinfo-history table {
    table-layout: fixed;
}
.saleinfo-history th,
.saleinfo-history td {
    width: 16.66%;
    word-break: break-word;
}
.saleinfo-history .card-header {
    background-color: #fdf3e3;
    border-bottom: 2px solid #E08A1E;
    border-radius: 0.375rem 0.375rem 0 0;
}
.saleinfo-history thead th {
    background-color: #f6ead3;
    color: #7a4d05;
    font-size: 0.8rem;
    font-weight: 600;
    line-height: 1.2;
    border-bottom: 1px solid #ecd9b4;
    white-space: nowrap;
    vertical-align: middle;
}
.saleinfo-history tbody td {
    font-size: 0.85rem;
    border-color: #f1e6d2;
}
.saleinfo-history tbody tr:nth-child(even) {
    background-color: #fffaf1;
}
/* แถวล่าสุด (บนสุด) = ราคาปัจจุบัน — เน้นให้เห็นชัด */
.saleinfo-history tbody tr:first-child {
    background-color: #fdf3e3;
}
.saleinfo-history tbody tr:first-child td {
    font-weight: 600;
    color: #7a4d05;
}
.saleinfo-history .badge-current {
    background-color: #E08A1E;
    color: #fff;
    font-size: 0.65rem;
    font-weight: 600;
    padding: 0.15rem 0.45rem;
    border-radius: 0.7rem;
    margin-left: 0.35rem;
}

/* ─── ราคาตามขนาดบรรจุ (DB) + ค่าสี — โทนส้ม/ทองให้เข้าธีม ─── */
.saleinfo-dbprice {
    border: 1px solid #f0dfc0;
}
.saleinfo-dbprice .card-header {
    background-color: #fdf3e3;
    border-bottom: 2px solid #E08A1E;
    border-radius: 0.375rem 0.375rem 0 0;
}
/* layout ทั้ง section: 4 คอลัมน์ = ราคา 3 ช่อง/แถว + กล่องค่าสี span 2 แถวขวาสุด
   ใช้ minmax(0,1fr) ให้คอลัมน์หดได้ (กัน input/ข้อความดันคอลัมน์จนล้นออกนอกกรอบ) */
.saleinfo-dbprice .dbprice-layout {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr)) minmax(170px, 1fr);
    gap: 0.75rem;
    align-items: stretch;
}
.saleinfo-dbprice .dbprice-layout > * {
    min-width: 0;
}
.saleinfo-dbprice .dbprice-layout .dbprice-colorbox {
    grid-column: 4;
    grid-row: 1 / span 2;
}
/* จอแคบ (< lg): เหลือ 2 คอลัมน์ กล่องค่าสีลงเต็มแถวล่าง */
@media (max-width: 991.98px) {
    .saleinfo-dbprice .dbprice-layout {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    .saleinfo-dbprice .dbprice-layout .dbprice-colorbox {
        grid-column: 1 / -1;
        grid-row: auto;
    }
}
/* ชั้นราคาแต่ละขนาดบรรจุ */
.saleinfo-dbprice .dbprice-tier {
    border: 1px solid #f0dfc0;
    border-radius: 0.5rem;
    padding: 0.75rem 0.85rem;
    background-color: #fffdf9;
    height: 100%;
}
.saleinfo-dbprice .dbprice-tier-label {
    font-size: 0.85rem;
    font-weight: 600;
    color: #7a4d05;
    margin-bottom: 0.5rem;
    white-space: nowrap;
}
.saleinfo-dbprice .dbprice-tier-size {
    display: inline-block;
    font-size: 0.68rem;
    font-weight: 500;
    color: #b26a09;
    background-color: #fbeacd;
    border-radius: 0.6rem;
    padding: 0.05rem 0.5rem;
    margin-left: 0.15rem;
}
.saleinfo-dbprice .dbprice-value {
    display: flex;
    align-items: center;
    gap: 0.4rem;
    border: 1px solid #e6d7bb;
    border-radius: 0.4rem;
    background-color: #fff;
    padding: 0 0.6rem;
}
.saleinfo-dbprice .dbprice-unit {
    color: #b26a09;
    font-weight: 600;
}
.saleinfo-dbprice .dbprice-input {
    flex: 1;
    min-width: 0;
    width: 100%;
    border: 0;
    outline: 0;
    background: transparent;
    text-align: right;
    font-weight: 600;
    font-size: 1.05rem;
    color: #55350a;
    padding: 0.4rem 0;
    font-variant-numeric: tabular-nums;
}
.saleinfo-dbprice .dbprice-input::placeholder {
    color: #cbb48c;
    font-weight: 400;
}
/* กล่องค่าสี — 2 ช่อง (ค่าสีทั้งสิ้น / % สี) */
.saleinfo-dbprice .dbprice-colorbox {
    border: 1px solid #f0dfc0;
    border-radius: 0.5rem;
    background-color: #fbf1e0;
    overflow: hidden;
    display: grid;
    grid-template-columns: 1fr 1fr;
    text-align: center;
}
.saleinfo-dbprice .dbprice-colorcell {
    padding: 0.6rem 0.5rem;
    display: flex;
    flex-direction: column;
    justify-content: center;
}
.saleinfo-dbprice .dbprice-colorcell + .dbprice-colorcell {
    border-left: 1px dashed #e6d3b0;
}
.saleinfo-dbprice .dbprice-colorlabel {
    font-size: 0.75rem;
    color: #b26a09;
    margin-bottom: 0.2rem;
}
.saleinfo-dbprice .dbprice-colorval {
    font-size: 1.25rem;
    font-weight: 700;
    line-height: 1.1;
    color: #55350a;
    font-variant-numeric: tabular-nums;
}
/* แถวราคากลุ่ม A/B/C (zcolorrate) ใต้ช่องราคา — 3 ช่องกว้างเท่าช่องราคาด้านบน (06/10/2569) */
.saleinfo-dbprice .dbprice-grouphead {
    font-size: 0.85rem;
    font-weight: 600;
    color: #7a4d05;
}
.saleinfo-dbprice .dbprice-groupnone {
    font-weight: 400;
    color: #8a6d3b;
    margin-left: 0.5rem;
}
.saleinfo-dbprice .dbprice-groups {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr)) minmax(170px, 1fr);
    gap: 0.75rem;
}
@media (max-width: 991.98px) {
    .saleinfo-dbprice .dbprice-groups {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }
}
/* บรรทัดบอกที่มาของราคา (ราคาทุน · เงื่อนไข · สูตร) ใต้กล่องคำนวณราคา */
.saleinfo-price-note {
    font-size: 0.8rem;
    color: #8a6d3b;
    min-height: 1.1rem;
}
/* ช่องที่ระบบเติมให้เอง (Test No. ที่หาได้จาก Customer + Lot Test) */
.tp-autofill {
    background-color: #fff8e1 !important;
    border-color: #ffd08a !important;
}
.saleinfo-price-note.saleinfo-price-note-warn {
    color: #b02a37;
    background-color: #fdecea;
    border: 1px solid #f5c2c7;
    border-radius: 0.4rem;
    padding: 0.4rem 0.6rem;
}
</style>

<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">

            @include('layout/inc_sidemenu')

            <div class="layout-page">

                @include('layout/inc_topmenu')

                <!-- Content wrapper -->
                <div class="content-wrapper">

<div class="container-xxl flex-grow-1 container-p-y">

    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body d-flex justify-content-between align-items-center flex-wrap gap-3">

                    <div>
                        <h3 class="mb-1">
                            <i class="ti ti-tag text-primary"></i>
                            กำหนดราคา
                        </h3>
                        <p class="text-muted mb-0">
                            กำหนดราคาสินค้าแยกตามลูกค้า (ราคา วันที่เริ่มซื้อ หมายเหตุ ฉลาก)
                        </p>
                    </div>

                    <div class="d-flex gap-2 flex-wrap">
                        <button class="btn btn-label-secondary"
                            data-bs-toggle="modal"
                            data-bs-target="#testPriceModal">
                            <i class="ti ti-flask me-1"></i>
                            Test Price
                        </button>
                        <button class="btn btn-label-secondary"
                            data-bs-toggle="modal"
                            data-bs-target="#newPriceModal">
                            <i class="ti ti-search me-1"></i>
                            ค้นหาราคาสินค้า
                        </button>
                        {{-- ดูกลุ่มราคา (zcolorrate) แบบอ่านอย่างเดียว — 19/09/2569
                             แก้ไขได้ที่เมนู "จัดการกลุ่มราคา" (/color-rate) --}}
                        <button class="btn btn-label-secondary" onclick="openColorRateLookup()">
                            <i class="ti ti-layers-difference me-1"></i>
                            ดูกลุ่มราคา
                        </button>
                        {{-- ปุ่ม "ตั้งค่าเงื่อนไขราคา" ปิดไปแล้ว — ใช้เมนู "ตั้งค่าเงื่อนไขราคา" (/price-rule) แทน 21/08/2569 --}}
                        <button class="btn btn-theme-saleinfo"
                            data-bs-toggle="modal"
                            data-bs-target="#saleinfoModal">
                            <i class="ti ti-plus me-1"></i>
                            กำหนดราคาใหม่
                        </button>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- Table -->
    <div class="card">

        <div class="card-header border-bottom">

            {{-- แถบหัว: ปุ่มพับ/กางตัวกรอง + ปุ่มล้างตัวกรอง (ชิดขวาทั้งคู่) — ค่าเริ่มต้นคือ "ซ่อนไว้" --}}
            <div class="d-flex justify-content-end align-items-center gap-2">
                {{-- รายละเอียดการค้นหา — สรุปเงื่อนไขที่กรองอยู่ โชว์เฉพาะตอนพับตัวกรอง --}}
                <div id="filterSummary" class="d-flex flex-wrap align-items-center gap-1 me-auto"></div>
                <button type="button" id="btnToggleFilters" class="btn btn-label-primary btn-sm"
                    data-bs-toggle="collapse" data-bs-target="#saleinfoFilterBox"
                    aria-expanded="false" aria-controls="saleinfoFilterBox">
                    <i class="ti ti-filter me-1"></i>ตัวกรอง
                    <i class="ti ti-chevron-down ms-1 toggle-caret"></i>
                </button>
                <button type="button" id="btnResetFilters" class="btn btn-label-secondary btn-sm" onclick="resetFilters()">
                    <i class="ti ti-x me-1"></i>ล้างตัวกรอง<span class="filter-count ms-1"></span>
                </button>
            </div>

            <div class="collapse" id="saleinfoFilterBox">
            <div class="pt-3">

            <div class="row g-3 align-items-end">
                <div class="col-md-6">
                    <label class="form-label small fw-medium mb-1">
                        ค้นหา <span class="text-muted fw-normal">(รหัสลูกค้า / ชื่อลูกค้า / ชื่อสินค้า / รหัสสินค้า)</span>
                    </label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="ti ti-search"></i></span>
                        <input type="text" name="search" class="form-control p_search" oninput="loadData(page)">
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-medium mb-1">วันที่เริ่มราคาใหม่</label>
                    <div class="d-flex align-items-center gap-2">
                        <span class="small fw-medium">ตั้งแต่</span>
                        <input type="text" name="date_from" class="form-control flatpickr-date p_search"
                            placeholder="วว/ดด/ปปปป">
                        <span class="small fw-medium">ถึง</span>
                        <input type="text" name="date_to" class="form-control flatpickr-date p_search"
                            placeholder="วว/ดด/ปปปป">
                    </div>
                </div>
                {{-- กรองด้วย Label DB (uprice.Label — ข้อความบนฉลาก) — 12/10/2569 --}}
                <div class="col-md-6">
                    <label class="form-label small fw-medium mb-1">
                        Label DB <span class="text-muted fw-normal">(ข้อความบนฉลาก)</span>
                    </label>
                    <input type="text" name="label" class="form-control p_search" oninput="loadData(page)">
                </div>
            </div>

            </div>
            </div>
            {{-- /#saleinfoFilterBox --}}

            <div class="d-flex justify-content-end align-items-center mt-3 pt-3 border-top">
                <div class="d-flex align-items-center">
                    <label class="form-label small fw-medium mb-0 me-2">แสดง</label>
                    <select name="limit" class="form-select form-select-sm p_search"
                        style="width: 90px;" onchange='loadData("{{ $page_url }}/datatable")'>
                        <option value="15">15</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                    <span class="ms-2 small fw-medium">รายการ/หน้า</span>
                </div>
            </div>
        </div>

        <div id="table-data">
            {{-- ตารางโหลดผ่าน AJAX จาก saleinfo/datatable --}}
            <div class="text-center py-5 text-muted">
                <div class="spinner-border spinner-border-sm me-2"></div>
                กำลังโหลดข้อมูล...
            </div>
        </div>

    </div>

    {{-- ═══════════════════════════════════════════════════════════════ --}}
    {{-- ข้อมูลจากไฟล์ Access เดิม (formula_2000.mdb) — อ่านอย่างเดียว    --}}
    {{-- ไว้ให้ตรวจว่าข้อมูลที่ย้ายขึ้น server มาครบ/ตรงกับไฟล์เดิมไหม     --}}
    {{-- ═══════════════════════════════════════════════════════════════ --}}
    <div class="card mt-4">

        <div class="card-header border-bottom">

            <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-3">
                <div>
                    <h5 class="mb-1">
                        <i class="ti ti-database text-warning"></i>
                        ข้อมูลจากไฟล์ Access เดิม
                    </h5>
                    <p class="text-muted small mb-0">
                        สำเนาของ <code>formula_2000.mdb</code> ที่ย้ายขึ้นฐานข้อมูลแล้ว — อ่านอย่างเดียว แก้ไขจากหน้านี้ไม่ได้
                    </p>
                </div>
                <span class="badge bg-label-warning align-self-center">
                    <i class="ti ti-lock me-1"></i>อ่านอย่างเดียว
                </span>
            </div>

            {{-- แท็บเลือกตาราง --}}
            <ul class="nav nav-tabs card-header-tabs mb-3" id="accessTabs">
                <li class="nav-item">
                    <a class="nav-link active" href="javascript:void(0)" data-tab="pdprice">
                        ราคาทุน <small class="text-muted">(PdPrice)</small>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="javascript:void(0)" data-tab="compo">
                        สูตรส่วนผสม <small class="text-muted">(Compo)</small>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="javascript:void(0)" data-tab="testmai">
                        หัวใบเทียบสี <small class="text-muted">(TestMai)</small>
                    </a>
                </li>
            </ul>

            <div class="row g-3 align-items-end">
                <div class="col-md-8">
                    <label class="form-label small fw-medium mb-1">
                        ค้นหา <span class="text-muted fw-normal" id="access_search_hint">(รหัสสินค้า)</span>
                    </label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="ti ti-search"></i></span>
                        <input type="text" id="access_search" class="form-control" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="d-flex align-items-center justify-content-md-end">
                        <label class="form-label small fw-medium mb-0 me-2">แสดง</label>
                        <select id="access_limit" class="form-select form-select-sm" style="width: 90px;">
                            <option value="15">15</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                        <span class="ms-2 small fw-medium">รายการ/หน้า</span>
                    </div>
                </div>
            </div>

            {{-- ภาษาไทยจากไฟล์ Access เสียมาตั้งแต่ต้นทาง — บอกไว้กันเข้าใจผิดว่าระบบแสดงผลพัง --}}
            <div class="small text-muted mt-3 mb-0">
                <i class="ti ti-info-circle me-1"></i>
                ข้อความภาษาไทยในไฟล์ Access ถูกบันทึกมาเป็น <code>?</code> ตั้งแต่ต้นทาง (ชื่อลูกค้า / ผู้เทียบสี / รายละเอียดสูตร) กู้คืนจากไฟล์ไม่ได้
            </div>
        </div>

        <div id="access-table-data">
            {{-- ตารางโหลดผ่าน AJAX จาก saleinfo/access-data --}}
            <div class="text-center py-5 text-muted">
                <div class="spinner-border spinner-border-sm me-2"></div>
                กำลังโหลดข้อมูล...
            </div>
        </div>

    </div>

</div>

                    @include('layout/inc_footer')

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- / Content wrapper -->
            </div>
        </div>

        <div class="layout-overlay layout-menu-toggle"></div>
        <div class="drag-target"></div>
    </div>
    <!-- / Layout wrapper -->

    @include('saleinfo.modal-price')
    @include('saleinfo.modal-view')   {{-- ดูราคา (อ่านอย่างเดียว) — 15/10/2569 --}}
    @include('saleinfo.modal-newprice')
    @include('saleinfo.modal-testprice')
    @include('color-rate.lookup-modal')   {{-- modal "ดูกลุ่มราคา" (อ่านอย่างเดียว) — 19/09/2569 --}}
    {{-- modal-pricerule ถูกย้ายไปเป็นหน้า /price-rule (resources/views/pricerule/index.blade.php) — 21/08/2569 --}}

    @include('layout/inc_js')

<script>
    var page = "{{ $page_url }}/datatable";
    var searchData = {};
    var dtXhr = null;
    var dtSeq = 0;

    // ป้ายชื่อของแต่ละช่องกรอง — ใช้ประกอบแถบ "รายละเอียดการค้นหา" (#filterSummary)
    // ⚠ ต้องประกาศตรงนี้ (ก่อน loadData ครั้งแรก) เพราะ renderFilterSummary() ถูกเรียกใน loadData
    //   ถ้าไปประกาศท้ายไฟล์ ตัวแปรจะยังเป็น undefined ตอนโหลดหน้า → throw แล้ว spinner ค้าง
    var FILTER_LABELS = {
        search:    'ค้นหา',
        label:     'Label DB',
        date_from: 'วันที่เริ่มราคาใหม่ ตั้งแต่',
        date_to:   'ถึง'
    };

    loadData(page);

    $(function () {
        // ยกระดับ select ทั้งหน้า — ตัวช่วยกลางใน layout/inc_js เลือกให้เองตามจำนวนตัวเลือก
        // หน้านี้มีแต่ช่อง "รายการ/หน้า" (3 ตัวเลือก) จึงเป็น bootstrap-select ทั้งคู่
        // ⚠ ต้องมาก่อน flatpickr เพื่อไม่ให้ไปจับ <select> เดือน/ปี ที่ flatpickr สร้าง
        enhanceSelects();
        flatpickr('.flatpickr-date', {
            dateFormat: 'd/m/Y',
            allowInput: true,
            static: true,
            disableMobile: true,
            onChange: function (_, _str, instance) {
                if (instance.input.classList.contains('p_search')) {
                    loadData(page);
                }
            }
        });
        $('.flatpickr-date').attr('autocomplete', 'off');
    });

    // เก็บค่า filter ทั้งหมดใน UI เป็น object
    function collectSearchData() {
        var data = {};
        $('.p_search').each(function () {
            var name  = $(this).attr('name');
            var value = $(this).val();
            if (value !== '' && value !== null) {
                data[name] = value;
            }
        });
        return data;
    }

    // อัปเดตปุ่มล้างตัวกรองตามจำนวน filter ที่ใช้อยู่ (ไม่นับ limit)
    function updateFilterButtonState() {
        var count = 0;
        $('.p_search:not([name="limit"])').each(function () {
            var v = $(this).val();
            if (v !== '' && v !== null) count++;
        });
        var $btn = $('#btnResetFilters');
        if (count > 0) { $btn.removeClass('btn-label-secondary').addClass('btn-danger'); $btn.find('.filter-count').text('(' + count + ')'); }
        else           { $btn.removeClass('btn-danger').addClass('btn-label-secondary'); $btn.find('.filter-count').text(''); }

        renderFilterSummary();
    }

    // ── รายละเอียดการค้นหา (โชว์ตอนพับตัวกรอง) — ป้ายชื่อ FILTER_LABELS ประกาศไว้ต้นสคริปต์ ──
    // escape ค่าที่ผู้ใช้พิมพ์ก่อนยัดลง HTML (กัน XSS จากคำค้น)
    function escHtml(s){ return $('<div>').text(s == null ? '' : s).html(); }

    function renderFilterSummary(){
        var chips = [];
        $('.p_search:not([name="limit"])').each(function () {
            var label = FILTER_LABELS[$(this).attr('name')];
            if (!label) return;
            // ตัดสินว่า "ไม่ได้กรอง" จาก value เสมอ — ตัวเลือก "ทั้งหมด" มี value ว่างแต่มีข้อความ
            var raw = $(this).val();
            if (raw === '' || raw === null) return;
            // select: แสดงข้อความของตัวเลือก ไม่ใช่ value
            var val = $(this).is('select') ? $(this).find('option:selected').text().trim() : raw;
            chips.push('<span class="badge bg-label-primary fw-normal">'
                + '<span class="text-dark fw-medium">' + escHtml(label) + ':</span> '
                + escHtml(val) + '</span>');
        });
        $('#filterSummary').html(chips.join(''));   // ไม่มีตัวกรอง = ปล่อยว่าง
    }

    // หมุนลูกศรตามสถานะพับ/กาง + ซ่อนแถบสรุปตอนกาง (ข้างในเห็นค่าจริงอยู่แล้ว)
    $(document).on('show.bs.collapse hide.bs.collapse', '#saleinfoFilterBox', function (e) {
        $('#btnToggleFilters .toggle-caret')
            .toggleClass('ti-chevron-down', e.type === 'hide')
            .toggleClass('ti-chevron-up',   e.type === 'show');
        $('#filterSummary').toggleClass('d-none', e.type === 'show');
    });

    // กัน AJAX race: ยกเลิก request เก่า + รับเฉพาะผลของ request ล่าสุด
    function loadData(pages) {
        updateFilterButtonState();
        searchData = collectSearchData();
        page = pages;

        var seq = ++dtSeq;
        if (dtXhr) dtXhr.abort();
        showTableLoading();   // server ช้า — บอกผู้ใช้ว่ากำลังดึงข้อมูล (16/09/2569)

        dtXhr = $.ajax({
            type: "GET",
            url: pages,
            data: searchData,
            success: function (data) {
                if (seq !== dtSeq) return;
                $("#table-data").html(data);
            },
            error: function (xhr, status) {
                if (seq !== dtSeq || status === 'abort') return;   // request เก่าถูกตัดทิ้ง = ปกติ
                showTableError();
            },
            complete: function () {
                if (seq === dtSeq) dtXhr = null;
            }
        });
    }

    function resetFilters() {
        $('.p_search:not([name="limit"])').each(function () {
            if ($(this).hasClass('flatpickr-date')) {
                const fp = this._flatpickr;
                if (fp) fp.clear();
                else    $(this).val('');
                return;
            }
            $(this).val('');
        });
        loadData("{{ $page_url }}/datatable");
    }

    // ────────────────────────────────────────────────────────
    //  ข้อมูลจากไฟล์ Access เดิม (3 ตาราง) — อ่านอย่างเดียว
    //  แยก loader ของตัวเองจากตารางหลัก เพราะมี filter/pagination คนละชุด
    // ────────────────────────────────────────────────────────
    var accessTab  = 'pdprice';
    var accessXhr  = null;
    var accessSeq  = 0;
    var accessTimer = null;

    // คำใบ้ว่าแท็บนี้ค้นจากคอลัมน์ไหนได้บ้าง (ต้องตรงกับ ACCESS_TABS ฝั่ง controller)
    var ACCESS_HINT = {
        pdprice: '(รหัสสินค้า)',
        compo:   '(รหัสสูตร / รหัสส่วนผสม / เลขที่เทียบสี / เลขที่แก้ไข)',
        testmai: '(เลขที่เทียบสี / Lot / รายละเอียด / รหัสลูกค้า / ชื่อลูกค้า / เม็ดพลาสติก / ผู้เทียบสี)'
    };

    // pages = URL เต็ม (ตอนกดเลขหน้า) หรือไม่ส่ง = เริ่มหน้า 1 ใหม่
    function loadAccessData(pages) {
        var url = pages || "{{ $page_url }}/access-data";

        var seq = ++accessSeq;
        if (accessXhr) accessXhr.abort();

        accessXhr = $.ajax({
            type: "GET",
            url: url,
            data: {
                tab:           accessTab,
                access_search: $('#access_search').val(),
                access_limit:  $('#access_limit').val()
            },
            success: function (data) {
                if (seq !== accessSeq) return;
                $("#access-table-data").html(data);
            },
            error: function (xhr) {
                if (seq !== accessSeq || xhr.statusText === 'abort') return;
                $("#access-table-data").html(
                    '<div class="text-center py-5 text-danger">' +
                    '<i class="ti ti-alert-triangle fs-2 d-block mb-2"></i>' +
                    'โหลดข้อมูลไม่สำเร็จ — ตรวจว่ารัน migration และนำเข้าข้อมูลตาราง access_* แล้วหรือยัง' +
                    '</div>'
                );
            },
            complete: function () {
                if (seq === accessSeq) accessXhr = null;
            }
        });
    }

    $('#accessTabs .nav-link').on('click', function () {
        var tab = $(this).data('tab');
        if (tab === accessTab) return;

        accessTab = tab;
        $('#accessTabs .nav-link').removeClass('active');
        $(this).addClass('active');

        $('#access_search').val('');                        // เปลี่ยนตาราง = คนละคอลัมน์ ค้นค้างไว้ไม่มีความหมาย
        $('#access_search_hint').text(ACCESS_HINT[tab]);
        loadAccessData();
    });

    // หน่วง 400ms กันยิงรัวตอนพิมพ์
    $('#access_search').on('input', function () {
        clearTimeout(accessTimer);
        accessTimer = setTimeout(function () { loadAccessData(); }, 400);
    });

    $('#access_limit').on('change', function () { loadAccessData(); });

    loadAccessData();

    // ────────────────────────────────────────────────────────
    //  ฟอร์มกำหนดราคา
    // ────────────────────────────────────────────────────────
    let saleinfoEditing = false;

    $('#saleinfoModal').on('show.bs.modal', function () {
        if (saleinfoEditing) return;   // โหมดแก้ไข → ห้าม reset ทับข้อมูลที่เติมไว้
        resetSaleinfoForm();
    });
    $('#saleinfoModal').on('hidden.bs.modal', function () { saleinfoEditing = false; });

    function resetSaleinfoForm() {
        $('#form_saleinfo')[0].reset();
        $('#form_saleinfo [name="_mode"]').val('create');
        $('#form_saleinfo [name="_pk"]').val('');
        $('#btn_delete_saleinfo').addClass('d-none').removeData('id');
        setCustomerPanel(null);
        clearSaleinfoHistory();
        clearSaleinfoLastOrder();
        clearSaleinfoCalc();
    }

    // ────────────────────────────────────────────────────────
    //  คำนวณราคา (ราคา 1/2/3 + DB 3-4 / 1-2 Kg.) — 25/08/2569
    //  ใช้ endpoint เดียวกับจอ "ค้นหาราคาสินค้า" (saleinfo/price-lookup)
    //  → ProductPriceService::lookup(รหัสสินค้า)
    //
    //  ราคา 1 = ราคาทุน (access_pdprice) × คูณ ÷ หาร + บวก ตามเงื่อนไขที่จับคู่ได้
    //  ราคา 2 = ราคา 1 × ตัวคูณขั้น  |  ราคา 3 = ราคา 2 × ตัวคูณขั้น
    //  DB 3-4 / 1-2 Kg. คูณต่อจากราคา 3 (ตัวคูณอยู่ที่ config/product_price.php → tier)
    //
    //  ⚠ ค่าสีทั้งสิ้น / % สี ยังไม่รู้สูตร — ยังคงเว้นไว้ (กล่องนั้นยังเป็น wip)
    // ────────────────────────────────────────────────────────
    const SALEINFO_CALC_FIELDS = ['db_price_1', 'db_price_2', 'db_price_3', 'db_price_3_4', 'db_price_1_2'];
    let saleinfoCalcTimer = null, saleinfoCalcXhr = null;

    // ช่องคำนวณเป็น input อ่านอย่างเดียว — ว่าง = ยังไม่มีค่า (placeholder "—" ขึ้นเอง)
    // ราคาที่คำนวณแล้วโชว์เป็น "จำนวนเต็ม" (ปัดเศษ) ให้ตรงกับจอ "ค้นหาราคาสินค้า" (npMoneyInt) — 07/09/2569
    // ปัดตอนแสดงผลอย่างเดียว ค่าที่ endpoint ส่งมายังเป็นทศนิยมตามจริง
    function setCalcField(name, value) {
        $('#form_saleinfo [name="' + name + '"]')
            .val(value === null || value === undefined || value === '' ? '' : commaFmt(value, 0));
    }

    // ราคากลุ่ม A/B/C จาก zcolorrate (06/10/2569) — rate = null คือรหัสนี้ไม่มีในกลุ่มราคา
    // showNone = ขึ้นข้อความ "ไม่มีในกลุ่มราคา" (เฉพาะตอนค้นแล้วไม่เจอ ไม่ใช่ตอนล้างฟอร์ม)
    function setSaleinfoGroupRates(rate, showNone) {
        ['A', 'B', 'C'].forEach(function (g) {
            const v = rate ? rate['rate_' + g] : null;
            $('#saleinfo_group_' + g).val(v === null || v === undefined || v === '' ? '' : commaFmt(v, 2));
        });
        $('#saleinfo_group_none').toggleClass('d-none', !!rate || !showNone);
    }

    function clearSaleinfoCalc() {
        if (saleinfoCalcXhr) { saleinfoCalcXhr.abort(); saleinfoCalcXhr = null; }
        clearTimeout(saleinfoCalcTimer);
        SALEINFO_CALC_FIELDS.forEach(function (name) { setCalcField(name, ''); });
        setSaleinfoGroupRates(null, false);
        $('#saleinfo_price_note').text('').removeClass('saleinfo-price-note-warn');
    }

    // แสดงผลจาก endpoint — คำนวณไม่ได้ก็บอกเหตุผล ไม่โชว์ 0 ให้เข้าใจผิด
    function showSaleinfoCalc(res) {
        res = res || {};
        const p = res.prices || null;
        const $note = $('#saleinfo_price_note').removeClass('saleinfo-price-note-warn');

        // ราคากลุ่มไม่ขึ้นกับราคาทุน — เติมก่อน ไม่ว่าจะคำนวณราคา 1/2/3 ได้หรือไม่
        setSaleinfoGroupRates(res.color_rate || null, true);

        if (p) {
            setCalcField('db_price_1', p.price_1);
            setCalcField('db_price_2', p.price_2);
            setCalcField('db_price_3', p.price_3);
            setCalcField('db_price_3_4', p.db_3_4);
            setCalcField('db_price_1_2', p.db_1_2);

            // ที่มาของราคา: ราคาทุน → เงื่อนไขที่จับคู่ได้ → สูตรคูณ/หาร/บวก
            const src = [];
            if (res.base_price !== null && res.base_price !== undefined) src.push('ราคาทุน ' + fmtNum(res.base_price));
            if (res.rule && res.rule.label) src.push(res.rule.label);
            if (res.rule) src.push('× ' + res.rule.mul + ' ÷ ' + res.rule.div + ' + ' + res.rule.add);
            $note.text(src.join('  ·  '));
            return;
        }

        SALEINFO_CALC_FIELDS.forEach(function (name) { setCalcField(name, ''); });
        const msg = res.reason || '';
        $note.text(msg);
        if (msg) $note.addClass('saleinfo-price-note-warn');
    }

    // รหัสสินค้า (ITEMNO) เป็นตัวหลัก — ยังไม่กรอกก็ใช้ชื่อสินค้า (st_code) แทน
    // เหมือนตอนบันทึก (SaleinfoController::extractForm) ที่ ITEMNO ว่าง = ใช้ st_code
    function saleinfoCalcCode() {
        const itemno = ($('#form_saleinfo [name="ITEMNO"]').val() || '').trim();
        return itemno || ($('#form_saleinfo [name="st_code"]').val() || '').trim();
    }

    function refreshSaleinfoCalc() {
        const code = saleinfoCalcCode();
        if (!code) {
            clearSaleinfoCalc();
            return;
        }

        if (saleinfoCalcXhr) saleinfoCalcXhr.abort();   // พิมพ์ต่อระหว่างรอผล → ทิ้งคำขอเก่า กันผลเก่ามาทับ
        saleinfoCalcXhr = $.getJSON("{{ $page_url }}/price-lookup", { code: code })
            .done(showSaleinfoCalc)
            .fail(function (xhr) {
                if (xhr.statusText === 'abort') return;
                showSaleinfoCalc(xhr.responseJSON || { prices: null, reason: 'เรียกข้อมูลราคาไม่สำเร็จ' });
            })
            .always(function () { saleinfoCalcXhr = null; });
    }

    // หน่วง 400ms กันยิงรัวตอนพิมพ์ (เหมือนจอค้นหาราคาสินค้า)
    $('#form_saleinfo [name="ITEMNO"], #form_saleinfo [name="st_code"]').on('input', function () {
        clearTimeout(saleinfoCalcTimer);
        saleinfoCalcTimer = setTimeout(refreshSaleinfoCalc, 400);
    });

    // ────────────────────────────────────────────────────────
    //  ประวัติการปรับราคา — โชว์เมื่อรหัสลูกค้า + รหัสสินค้า ตรงกับที่เคยบันทึกไว้
    // ────────────────────────────────────────────────────────
    let saleinfoHistXhr = null;

    function clearSaleinfoHistory() {
        if (saleinfoHistXhr) { saleinfoHistXhr.abort(); saleinfoHistXhr = null; }
        $('#saleinfo_history_card').addClass('d-none');
        $('#saleinfo_history_body').empty();
        $('#saleinfo_history_count').text('0 รายการ');
    }

    function fmtNum(v) {
        if (v === null || v === '' || v === undefined) return '—';
        const n = Number(v);
        return isNaN(n) ? v : n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    function esc(s) {
        return $('<div>').text(s ?? '').html();
    }

    // อ่านรหัสลูกค้า + รหัสสินค้าจากฟอร์ม → ดึงประวัติมาแสดง
    // (excludeId = id ของแถวที่กำลังแก้ไข จะไม่เอามาโชว์ซ้ำ)
    function loadSaleinfoHistory(excludeId) {
        const custno = ($('#form_saleinfo [name="CustNo"]').val() || '').trim();
        const itemno = ($('#form_saleinfo [name="ITEMNO"]').val() || '').trim();

        if (!custno || !itemno) {
            clearSaleinfoHistory();
            return;
        }

        if (saleinfoHistXhr) saleinfoHistXhr.abort();
        saleinfoHistXhr = $.ajax({
            type: "GET",
            url: "{{ $page_url }}/history",
            data: { custno: custno, itemno: itemno, exclude_id: excludeId || '' },
            success: function (res) {
                const rows = res.rows || [];
                if (!rows.length) {
                    clearSaleinfoHistory();
                    return;
                }

                const html = rows.map(function (r, i) {
                    // แถวบนสุด = ปรับล่าสุด = ราคาที่ใช้อยู่ปัจจุบัน
                    const badge = (i === 0) ? '<span class="badge-current">ปัจจุบัน</span>' : '';
                    // คอลัมน์ "วันที่แจ้งปรับ" (NotifyDate) / "MOQ" ถอดออกแล้ว (07/09/2569)
                    return '<tr>'
                        + '<td class="text-center">' + esc(r.DATE || '—') + '</td>'
                        + '<td>' + esc(r.ITEMNO || '—') + '</td>'
                        + '<td class="text-end">' + fmtNum(r.PRICE) + badge + '</td>'
                        + '<td class="text-muted">' + esc(r.REM1 || '—') + '</td>'
                        + '</tr>';
                }).join('');

                $('#saleinfo_history_body').html(html);
                $('#saleinfo_history_count').text(rows.length + ' รายการ');
                $('#saleinfo_history_card').removeClass('d-none');
            },
            complete: function () { saleinfoHistXhr = null; }
        });
    }

    // ────────────────────────────────────────────────────────
    //  สั่งซื้อล่าสุด (เฉพาะเบอร์นี้) — Lot / วันที่ส่งมอบล่าสุด จากใบสั่งซื้อ (12/10/2569)
    //  เงื่อนไข: ลูกค้าคนนี้ + สินค้าชิ้นนี้ (รหัสเดียวกับที่ใช้คำนวณราคา — ITEMNO ว่างใช้ st_code)
    // ────────────────────────────────────────────────────────
    let saleinfoLastXhr = null;

    function clearSaleinfoLastOrder() {
        if (saleinfoLastXhr) { saleinfoLastXhr.abort(); saleinfoLastXhr = null; }
        $('#saleinfo_last_lot, #saleinfo_last_dv').text('—');
        $('#saleinfo_last_note').text('');
    }

    function loadSaleinfoLastOrder() {
        const custno = ($('#form_saleinfo [name="CustNo"]').val() || '').trim();
        const itemno = saleinfoCalcCode();

        clearSaleinfoLastOrder();
        if (!custno || !itemno) return;

        saleinfoLastXhr = $.getJSON("{{ $page_url }}/last-order", { custno: custno, itemno: itemno })
            .done(function (res) {
                // ไม่พบประวัติการสั่ง = ถือว่าเกิน 3 ปี เหมือนกัน (15/10/2569 ตามที่ผู้ใช้สั่ง)
                if (!res.found) {
                    $('#saleinfo_last_note').text('เกิน 3 ปี');
                    return;
                }
                $('#saleinfo_last_lot').text(res.lot || '—');
                $('#saleinfo_last_dv').text(res.delivered || '—');
                $('#saleinfo_last_note').text(res.over_3_years ? 'เกิน 3 ปี' : '');
            })
            .always(function () { saleinfoLastXhr = null; });
    }

    // แถบข้อมูลลูกค้า (อ่านอย่างเดียว) ในฟอร์ม
    function setCustomerPanel(cust) {
        $('#saleinfo_cust_code').text(cust?.code ?? '—');
        $('#saleinfo_cust_name').text(cust?.name ?? '—');
        $('#saleinfo_cust_road').text(cust?.road ?? '—');
        $('#saleinfo_cust_term').text(cust?.term ?? '—');
    }

    // กรอกรหัสลูกค้าเสร็จ → ดึงชื่อ/ที่อยู่/เงื่อนไข มาเติมแถบขวา
    let custLookupXhr = null;
    function lookupCustomer(code) {
        code = (code || '').trim();
        if (!code) {
            setCustomerPanel(null);
            return;
        }

        if (custLookupXhr) custLookupXhr.abort();
        custLookupXhr = $.ajax({
            type: "GET",
            url: "{{ $page_url }}/customer/" + encodeURIComponent(code),
            success: function (res) {
                setCustomerPanel(res.found ? res : null);
            },
            complete: function () { custLookupXhr = null; }
        });
    }

    $('#form_saleinfo [name="CustNo"]').on('change', function () {
        lookupCustomer($(this).val());
        loadSaleinfoHistory($('#form_saleinfo [name="_pk"]').val());
        loadSaleinfoLastOrder();
    });

    // รหัสสินค้าเปลี่ยน → โหลดประวัติของคู่ลูกค้า/สินค้านี้ + คำนวณราคาใหม่
    $('#form_saleinfo [name="ITEMNO"]').on('change', function () {
        loadSaleinfoHistory($('#form_saleinfo [name="_pk"]').val());
        loadSaleinfoLastOrder();
        clearTimeout(saleinfoCalcTimer);
        refreshSaleinfoCalc();
    });

    // ชื่อสินค้าเปลี่ยน → คำนวณใหม่เฉพาะตอนที่ยังไม่ได้กรอกรหัสสินค้า (ใช้ st_code แทน)
    $('#form_saleinfo [name="st_code"]').on('change', function () {
        loadSaleinfoLastOrder();
        clearTimeout(saleinfoCalcTimer);
        refreshSaleinfoCalc();
    });

    // แก้ไขราคา — ดึงข้อมูลจริงมาเติมฟอร์มแล้วเปิด modal โหมดแก้ไข
    function viewSaleinfo(id) {
        $.ajax({
            type: "GET",
            url: "{{ $page_url }}/edit/" + id,
            success: function (res) {
                if (!res.found) return;

                resetSaleinfoForm();
                saleinfoEditing = true;

                const d = res.data;
                $('#form_saleinfo [name="_mode"]').val('edit');
                $('#form_saleinfo [name="_pk"]').val(id);

                // เติมทุกช่องที่ชื่อตรงกับคอลัมน์ (ยกเว้น checkbox จัดการแยก)
                ['CustNo', 'st_code', 'ITEMNO', 'DATE', 'PRICE', 'REM1', 'REM2', 'PackRem', 'Label', 'Author']
                    .forEach(function (name) {
                        const $f = $('#form_saleinfo [name="' + name + '"]');
                        // ช่องตัวเลขที่ใส่คอมมา (PRICE) → จัดรูปแบบก่อนเติม
                        $f.val($f.hasClass('js-comma') ? commaFmt(d[name], 2) : (d[name] ?? ''));
                    });
                // NoAcp ปิดไว้ก่อน — ช่องในฟอร์มถูกคอมเมนต์ไว้ รอลูกค้ายืนยันความหมาย
                // $('#saleinfo_noacp').prop('checked', Number(d.NoAcp) === 1);

                $('#btn_delete_saleinfo').removeClass('d-none').data('id', id);
                lookupCustomer(d.CustNo);
                // แก้ไขอยู่ → โชว์ประวัติของคู่นี้ แต่ไม่รวมแถวที่กำลังแก้เอง
                loadSaleinfoHistory(id);
                loadSaleinfoLastOrder();
                refreshSaleinfoCalc();
                $('#saleinfoModal').modal('show');
            },
            error: function () {
                Swal.fire({ title: 'ไม่พบข้อมูล', text: 'รายการนี้อาจถูกลบไปแล้ว', icon: 'error', heightAuto: false });
            }
        });
    }

    // ────────────────────────────────────────────────────────
    //  ดูราคา (อ่านอย่างเดียว) — ปุ่มตาในตาราง (15/10/2569)
    //  หน้าตาแบบแสดงข้อมูล (modal-view) ไม่ใช่ฟอร์ม · ใช้ endpoint ชุดเดียวกับฟอร์มแก้ไข
    // ────────────────────────────────────────────────────────
    function svText(sel, v) {
        $(sel).text(v === null || v === undefined || String(v).trim() === '' ? '—' : v);
    }

    function svMoney(sel, v, decimals) {
        $(sel).text(v === null || v === undefined || v === '' ? '—' : commaFmt(v, decimals));
    }


    function clearSaleinfoView() {
        $('#saleinfoViewModal .sv-val').text('—');
        $('#sv_last_note').text('');
        $('#sv_price_note').text('').removeClass('sv-note-warn');
        $('#sv_group_none').addClass('d-none');
        $('#sv_history_body').html('<tr><td colspan="4" class="text-center text-muted">ไม่มีประวัติการปรับราคา</td></tr>');
        $('#sv_history_count').text('0 รายการ');
    }

    function showSaleinfoView(id) {
        $.getJSON("{{ $page_url }}/edit/" + id)
            .done(function (res) {
                if (!res.found) return;
                const d = res.data;

                clearSaleinfoView();

                const custno = (d.CustNo || '').trim();
                const itemno = (d.ITEMNO || '').trim();
                const code   = itemno || (d.st_code || '').trim();   // รหัสที่ใช้คำนวณราคา (เหมือนฟอร์ม)

                svText('#sv_custno', custno);
                svText('#sv_stcode', d.st_code);
                svText('#sv_itemno', d.ITEMNO);
                svMoney('#sv_price', d.PRICE, 2);
                svText('#sv_date', d.DATE);
                svText('#sv_rem1', d.REM1);
                svText('#sv_rem2', d.REM2);
                svText('#sv_packrem', d.PackRem);
                svText('#sv_label', d.Label);
                svText('#sv_author', d.Author);

                // ข้อมูลลูกค้า (กล่องขวา)
                if (custno) {
                    $.getJSON("{{ $page_url }}/customer/" + encodeURIComponent(custno)).done(function (c) {
                        if (!c.found) return;
                        svText('#sv_cust_name', c.name);
                        svText('#sv_cust_road', c.road);
                        svText('#sv_cust_term', c.term);
                    });
                }

                // สั่งซื้อล่าสุด (กติกาเดียวกับฟอร์ม: ไม่พบ = เกิน 3 ปี)
                if (custno && code) {
                    $.getJSON("{{ $page_url }}/last-order", { custno: custno, itemno: code }).done(function (o) {
                        if (!o.found) {
                            $('#sv_last_note').text('เกิน 3 ปี');
                            return;
                        }
                        svText('#sv_last_lot', o.lot);
                        svText('#sv_last_dv', o.delivered);
                        $('#sv_last_note').text(o.over_3_years ? 'เกิน 3 ปี' : '');
                    });
                }

                // ประวัติการปรับราคา (ไม่รวมแถวที่กำลังดู) — เหมือนฟอร์ม
                if (custno && itemno) {
                    $.getJSON("{{ $page_url }}/history", { custno: custno, itemno: itemno, exclude_id: id }).done(function (h) {
                        const rows = h.rows || [];
                        if (!rows.length) return;
                        $('#sv_history_body').html(rows.map(function (r, i) {
                            const badge = (i === 0) ? '<span class="badge-current">ปัจจุบัน</span>' : '';
                            return '<tr>'
                                + '<td class="text-center">' + esc(r.DATE || '—') + '</td>'
                                + '<td>' + esc(r.ITEMNO || '—') + '</td>'
                                + '<td class="text-end">' + fmtNum(r.PRICE) + badge + '</td>'
                                + '<td class="text-muted">' + esc(r.REM1 || '—') + '</td>'
                                + '</tr>';
                        }).join(''));
                        $('#sv_history_count').text(rows.length + ' รายการ');
                    });
                }

                // คำนวนราคา + ราคากลุ่ม + ที่มาของราคา
                if (code) {
                    $.getJSON("{{ $page_url }}/price-lookup", { code: code }).done(function (p) {
                        const rate = p.color_rate || null;
                        ['A', 'B', 'C'].forEach(function (g) {
                            svMoney('#sv_group_' + g, rate ? rate['rate_' + g] : null, 2);
                        });
                        $('#sv_group_none').toggleClass('d-none', !!rate);

                        if (p.prices) {
                            svMoney('#sv_p1', p.prices.price_1, 0);
                            svMoney('#sv_p2', p.prices.price_2, 0);
                            svMoney('#sv_p3', p.prices.price_3, 0);
                            svMoney('#sv_db34', p.prices.db_3_4, 0);
                            svMoney('#sv_db12', p.prices.db_1_2, 0);

                            const src = [];
                            if (p.base_price !== null && p.base_price !== undefined) src.push('ราคาทุน ' + fmtNum(p.base_price));
                            if (p.rule && p.rule.label) src.push(p.rule.label);
                            if (p.rule) src.push('× ' + p.rule.mul + ' ÷ ' + p.rule.div + ' + ' + p.rule.add);
                            $('#sv_price_note').text(src.join('  ·  '));
                        } else if (p.reason) {
                            $('#sv_price_note').text(p.reason).addClass('sv-note-warn');
                        }
                    });
                }

                $('#saleinfoViewModal').modal('show');
            })
            .fail(function () {
                Swal.fire({ title: 'ไม่พบข้อมูล', text: 'รายการนี้อาจถูกลบไปแล้ว', icon: 'error', heightAuto: false });
            });
    }


    $('#btn_delete_saleinfo').on('click', function () {
        const id = $(this).data('id');

        Swal.fire({
            title: 'ยืนยันการลบ',
            text: 'ต้องการลบราคานี้ใช่หรือไม่? ลบแล้วกู้คืนไม่ได้',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'ลบ',
            cancelButtonText: 'ยกเลิก',
            customClass: { confirmButton: 'btn btn-danger', cancelButton: 'btn btn-label-secondary' },
            buttonsStyling: false,
            heightAuto: false
        }).then(function (result) {
            if (!result.isConfirmed) return;

            $.ajax({
                type: "POST",
                url: "{{ $page_url }}/delete",
                data: { _token: "{{ csrf_token() }}", id: id },
                success: function () {
                    $('#saleinfoModal').modal('hide');
                    loadData(page);
                    Swal.fire({ title: 'ลบแล้ว', icon: 'success', timer: 1200, showConfirmButton: false, heightAuto: false });
                },
                error: function (xhr) {
                    Swal.fire({
                        title: 'ลบไม่สำเร็จ',
                        text: xhr.responseJSON?.error ?? 'เกิดข้อผิดพลาด',
                        icon: 'error',
                        heightAuto: false
                    });
                }
            });
        });
    });

    // กด Enter ในช่องกรอก ต้องไม่ submit ฟอร์ม — บันทึกได้ทางปุ่ม "บันทึก" เท่านั้น
    // (textarea ยังขึ้นบรรทัดใหม่ได้ตามปกติ · ปุ่มที่โฟกัสอยู่ยังกด Enter ได้)
    $('#form_saleinfo').on('keydown', 'input', function (e) {
        if (e.key === 'Enter') e.preventDefault();
    });

    $('#form_saleinfo').on('submit', function (e) {
        e.preventDefault();

        const isEdit = $('#form_saleinfo [name="_mode"]').val() === 'edit';
        const url    = "{{ $page_url }}/" + (isEdit ? 'update' : 'insert');

        stripCommaFields(this);                 // '1,234.50' → '1234.50' ก่อนส่งขึ้น server
        const formData = $(this).serializeArray();
        if (isEdit) {
            formData.push({ name: 'id', value: $('#form_saleinfo [name="_pk"]').val() });
        }

        const $btn = $(this).find('button[type="submit"]');
        $btn.prop('disabled', true);

        $.ajax({
            type: "POST",
            url: url,
            data: $.param(formData),
            success: function () {
                $('#saleinfoModal').modal('hide');
                loadData(page);
                Swal.fire({
                    title: isEdit ? 'แก้ไขราคาแล้ว' : 'บันทึกราคาแล้ว',
                    icon: 'success',
                    timer: 1200,
                    showConfirmButton: false,
                    heightAuto: false
                });
            },
            error: function (xhr) {
                Swal.fire({
                    title: 'บันทึกไม่สำเร็จ',
                    text: xhr.responseJSON?.error ?? 'เกิดข้อผิดพลาด',
                    icon: 'error',
                    heightAuto: false
                });
            },
            complete: function () { $btn.prop('disabled', false); }
        });
    });

    // ────────────────────────────────────────────────────────
    //  ค้นหาราคาสินค้า (modal "New Price") — อ่านอย่างเดียว ไม่มีบันทึก
    //  วางรหัสสินค้า → ราคาขึ้นเอง (ไม่ต้องกดปุ่ม)
    //
    //  ราคาขาย 1 = PdPrice.Price (ไฟล์ Access) × คูณ ÷ หาร + บวก
    //             ตามตารางเงื่อนไขของลูกค้าใน config/product_price.php (จับคู่ด้วยตัวขึ้นต้น/ลงท้ายของรหัส)
    //  ราคาขาย 2 = ราคาขาย 1 × 1.14   |   ราคาขาย 3 = ราคาขาย 2 × 1.30
    //  DB 3-4 / 1-2 Kg = max(ราคาขาย 2 + 250 / 400, ราคาขาย 3) เฉพาะรหัสขึ้นต้น 2 / 36 (15/10/2569)
    // ────────────────────────────────────────────────────────
    const NP_FIELDS = ['#np_price_1', '#np_price_2', '#np_price_3', '#np_db_3_4', '#np_db_1_2'];
    let npTimer = null, npXhr = null;

    const npMoney = function (v) {
        return Number(v).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    };

    // ราคาขายที่คำนวณแล้ว โชว์เป็นจำนวนเต็ม (ปัดเศษ .5 ขึ้น) — 12/08/2569
    // ปัดตอนแสดงผลอย่างเดียว ค่าที่ endpoint ส่งมายังเป็นทศนิยมตามจริง
    const npMoneyInt = function (v) {
        return Number(v).toLocaleString('th-TH', { maximumFractionDigits: 0 });
    };

    function clearNewPrice() {
        NP_FIELDS.forEach(function (sel) { $(sel).val(''); });
        $('#np_base_price, #np_rule, #np_formula').text('—');
        $('#np_error').addClass('d-none').text('');
    }

    // แสดงผลที่ได้จาก endpoint — ไม่ได้ราคาก็บอกเหตุผล ไม่โชว์ 0 ให้เข้าใจผิด
    function showNewPrice(res) {
        clearNewPrice();

        $('#np_base_price').text(res.base_price !== null ? npMoney(res.base_price) + ' บาท' : '—');
        $('#np_rule').text(res.rule ? res.rule.label : '—');

        if (res.rule) {
            $('#np_formula').text('× ' + res.rule.mul + ' ÷ ' + res.rule.div + ' + ' + res.rule.add);
        }

        if (res.prices) {
            $('#np_price_1').val(npMoneyInt(res.prices.price_1));
            $('#np_price_2').val(npMoneyInt(res.prices.price_2));
            $('#np_price_3').val(npMoneyInt(res.prices.price_3));
            // DB 3-4 / 1-2 Kg. — มีเฉพาะรหัสขึ้นต้นด้วย 2 (รหัสอื่น = null → ช่องว่าง)
            if (res.prices.db_3_4 != null) $('#np_db_3_4').val(npMoneyInt(res.prices.db_3_4));
            if (res.prices.db_1_2 != null) $('#np_db_1_2').val(npMoneyInt(res.prices.db_1_2));
        } else if (res.reason) {
            $('#np_error').removeClass('d-none').text(res.reason);
        }
    }

    function lookupNewPrice(code) {
        code = (code || '').trim();
        if (!code) {
            clearNewPrice();
            return;
        }

        if (npXhr) npXhr.abort();   // พิมพ์ต่อระหว่างรอผล → ทิ้งคำขอเก่า กันผลเก่ามาทับ
        npXhr = $.getJSON("{{ $page_url }}/price-lookup", { code: code })
            .done(showNewPrice)
            .fail(function (xhr) {
                if (xhr.statusText === 'abort') return;
                showNewPrice(xhr.responseJSON || {
                    base_price: null, rule: null, price: null, reason: 'เรียกข้อมูลราคาไม่สำเร็จ'
                });
            });
    }

    // หน่วง 400ms กันยิงรัวตอนพิมพ์ (วาง/พิมพ์ทีละตัวก็ทำงานเหมือนกัน)
    $('#np_code').on('input', function () {
        const code = $(this).val();
        clearTimeout(npTimer);
        npTimer = setTimeout(function () { lookupNewPrice(code); }, 400);
    });

    // ฟอร์มนี้ไม่มี submit — กัน Enter รีโหลดหน้า
    $('#np_code').on('keydown', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            clearTimeout(npTimer);
            lookupNewPrice($(this).val());
        }
    });

    $('#np_clear').on('click', function () {
        $('#np_code').val('').focus();
        clearNewPrice();
    });

    // เปิด modal ทีไร = เริ่มใหม่ + โฟกัสช่องรหัสให้วางได้เลย
    $('#newPriceModal').on('show.bs.modal', function () {
        $('#np_code').val('');
        clearNewPrice();
    });
    $('#newPriceModal').on('shown.bs.modal', function () {
        $('#np_code').focus();
    });

    // ────────────────────────────────────────────────────────
    //  Test Price — อ่านอย่างเดียว ไม่มีบันทึก (ต่อข้อมูลแล้ว 25/08/2569)
    //  กรอกได้แค่ Customer / Test No. / Lot Test → ที่เหลือขึ้นเอง
    //
    //  GET saleinfo/test-price → SaleinfoController::testPrice
    //    ใบเทส         = access_testmai — คีย์ค้นคือ Test No. หรือ Lot Test (กรอกช่องไหนก็ได้)
    //                    ช่องที่ไม่ได้กรอก ระบบเติมให้จากใบที่ค้นเจอ · Customer เป็นตัวกรองเสริม
    //    ตั้งเบอร์เป็น = access_compo.PdCode ของ TestNo นั้น
    //    ราคา 1/2/3 + DB = คิดจากต้นทุนสูตร (TNet) ด้วย ProductPriceService ตัวเดียวกับทั้งระบบ
    //
    //  ⚠ ช่อง Price Quotation ยังไม่ทำ (การ์ดนั้นยังเป็น wip) — ไม่มีการเติมค่าให้
    // ────────────────────────────────────────────────────────
    const TP_KEYS  = ['#tp_customer', '#tp_testno', '#tp_lottest'];   // ช่องที่กรอกได้
    const TP_TEXT  = ['#tp_sample', '#tp_resin_cust', '#tp_resin_match'];
    const TP_PRICE = ['#tp_price_1', '#tp_price_2', '#tp_price_3', '#tp_db_3_4', '#tp_db_1_2'];
    let tpTimer = null, tpXhr = null;

    // ช่องที่ "ระบบเติมให้เอง" จากใบที่ค้นเจอ (Test No. / Lot Test — ค้นด้วยช่องไหนก็เติมอีกช่องให้)
    // — ต้องแยกจากที่ผู้ใช้พิมพ์เอง ไม่งั้นค่าที่เติมไว้จะกลายเป็นเงื่อนไขค้นรอบถัดไป
    //   แล้วพอผู้ใช้แก้อีกช่อง ผลจะค้างอยู่ใบเดิม
    const TP_AUTO_SEL = { testno: '#tp_testno', lottest: '#tp_lottest' };
    const tpAuto = { testno: false, lottest: false };

    function tpClearAuto(field) {
        if (!tpAuto[field]) return;
        $(TP_AUTO_SEL[field]).val('').removeClass('tp-autofill').removeAttr('title');
        tpAuto[field] = false;
    }

    function tpSetAuto(field, value) {
        if (!value) return;
        $(TP_AUTO_SEL[field]).val(value).addClass('tp-autofill')
            .attr('title', 'ระบบเติมให้จากใบเทสที่ค้นเจอ');
        tpAuto[field] = true;
    }

    // ผู้ใช้พิมพ์ช่องไหน = ช่องนั้นเป็นของผู้ใช้ ส่วนช่องที่ระบบเติมไว้ให้ทิ้งไป
    function tpUserTyped(field) {
        if (field) {
            tpAuto[field] = false;
            $(TP_AUTO_SEL[field]).removeClass('tp-autofill').removeAttr('title');
        }
        Object.keys(TP_AUTO_SEL).forEach(function (f) {
            if (f !== field) tpClearAuto(f);
        });
    }

    function clearTestPrice() {
        TP_TEXT.concat(TP_PRICE).forEach(function (sel) { $(sel).val(''); });
        $('#tp_cust_name').text('—');
        $('#tp_setcode').text('—');
        $('#tp_meta').text('');
        $('#tp_price_note').text('').removeClass('saleinfo-price-note-warn');
    }

    // แสดงผลจาก endpoint — ไม่เจอใบเทสก็บอกเหตุผล ไม่โชว์ 0 ให้เข้าใจผิด
    function showTestPrice(res) {
        res = res || {};
        clearTestPrice();

        // ชื่อลูกค้าโชว์ได้แม้ยังไม่ระบุใบเทส (กรอกรหัสลูกค้าอย่างเดียวก็ขึ้นชื่อ)
        if (res.customer) {
            $('#tp_cust_name').text(res.customer.name || res.customer.code || '—');
        }

        const $note = $('#tp_price_note');

        if (!res.found) {
            // ที่เติมไว้รอบก่อนใช้ไม่ได้แล้ว
            tpClearAuto('testno');
            tpClearAuto('lottest');
            if (res.reason) $note.text(res.reason).addClass('saleinfo-price-note-warn');
            return;
        }

        const t = res.test || {};

        // ค้นด้วยช่องไหน ก็เติมอีกช่องให้จากใบที่เจอ (ผู้ใช้ยังพิมพ์ทับได้)
        if ($('#tp_testno').val().trim() === '')  tpSetAuto('testno', t.testno);
        if ($('#tp_lottest').val().trim() === '') tpSetAuto('lottest', t.lotno);
        $('#tp_sample').val(t.sample || '');
        $('#tp_resin_cust').val(t.cust_resin || '');
        $('#tp_resin_match').val(t.resin_match || '');
        $('#tp_setcode').text(res.setcode || '—');

        // หัวการ์ด: ใบที่หยิบมาแสดง + เตือนเมื่อ Lot เดียวมีหลายใบ
        const meta = [];
        if (t.testno) meta.push('Test No. ' + t.testno);
        if (t.testdate) meta.push('วันที่ ' + t.testdate);
        if (res.loose) meta.push('ไม่พบ Lot ตรงตัว — ค้นแบบใกล้เคียง');
        if (res.matches > 1) {
            // บอกเลขใบอื่นไปด้วย จะได้พิมพ์ Test No. เจาะจงใบที่ต้องการได้
            const others = (res.testnos || []).slice(1, 5).join(', ');
            meta.push('พบ ' + res.matches + ' ใบ — แสดงใบล่าสุด'
                + (others ? ' (ใบอื่น: ' + others + (res.matches > 5 ? ', …' : '') + ')' : ''));
        }
        $('#tp_meta').text(meta.join('  ·  '));

        const calc = res.calc || {};
        const p = calc.prices || null;

        if (p) {
            // โชว์เป็นจำนวนเต็ม (ปัดเศษ) ชุดเดียวกับฟอร์ม "กำหนดราคา" และจอ "ค้นหาราคาสินค้า" — 07/09/2569
            // ปัดตอนแสดงผลอย่างเดียว ค่าที่ endpoint ส่งมายังเป็นทศนิยมตามจริง
            $('#tp_price_1').val(commaFmt(p.price_1, 0));
            $('#tp_price_2').val(commaFmt(p.price_2, 0));
            $('#tp_price_3').val(commaFmt(p.price_3, 0));
            $('#tp_db_3_4').val(commaFmt(p.db_3_4, 0));
            $('#tp_db_1_2').val(commaFmt(p.db_1_2, 0));

            // ที่มาของราคา: ต้นทุนสูตรของใบเทส → เบอร์ที่ตั้ง → เงื่อนไข → สูตรคูณ/หาร/บวก
            const src = [];
            if (calc.base_price !== null && calc.base_price !== undefined) src.push('ต้นทุนสูตร ' + fmtNum(calc.base_price));
            if (calc.code) src.push('เบอร์ ' + calc.code);
            if (calc.rule && calc.rule.label) src.push(calc.rule.label);
            if (calc.rule) src.push('× ' + calc.rule.mul + ' ÷ ' + calc.rule.div + ' + ' + calc.rule.add);
            $note.text(src.join('  ·  '));
            return;
        }

        if (calc.reason) $note.text(calc.reason).addClass('saleinfo-price-note-warn');
    }

    function lookupTestPrice() {
        const hasKey = TP_KEYS.some(function (sel) { return $(sel).val().trim() !== ''; });
        if (!hasKey) {
            if (tpXhr) { tpXhr.abort(); tpXhr = null; }
            clearTestPrice();
            return;
        }

        if (tpXhr) tpXhr.abort();   // พิมพ์ต่อระหว่างรอผล → ทิ้งคำขอเก่า กันผลเก่ามาทับ
        tpXhr = $.getJSON("{{ $page_url }}/test-price", {
            customer: $('#tp_customer').val().trim(),
            // ค่าที่ระบบเติมเอง ไม่นับเป็นเงื่อนไข — ไม่งั้นแก้อีกช่องแล้วจะค้างอยู่ใบเดิม
            testno:   tpAuto.testno  ? '' : $('#tp_testno').val().trim(),
            lottest:  tpAuto.lottest ? '' : $('#tp_lottest').val().trim()
        })
            .done(showTestPrice)
            .fail(function (xhr) {
                if (xhr.statusText === 'abort') return;
                showTestPrice(xhr.responseJSON || { found: false, reason: 'เรียกข้อมูลใบเทสไม่สำเร็จ' });
            })
            .always(function () { tpXhr = null; });
    }

    // หน่วง 400ms กันยิงรัวตอนพิมพ์
    // พิมพ์ช่องไหน = ช่องนั้นเป็นเงื่อนไขของผู้ใช้ ส่วนช่องที่ระบบเติมไว้ให้ทิ้งแล้วค้นใหม่
    $('#tp_testno').on('input',   function () { tpUserTyped('testno');  tpQueueLookup(); });
    $('#tp_lottest').on('input',  function () { tpUserTyped('lottest'); tpQueueLookup(); });
    $('#tp_customer').on('input', function () { tpUserTyped(null);      tpQueueLookup(); });

    function tpQueueLookup() {
        clearTimeout(tpTimer);
        tpTimer = setTimeout(lookupTestPrice, 400);
    }

    // ฟอร์มนี้ไม่มี submit — กด Enter = ค้นเลย ไม่ใช่รีโหลดหน้า
    $(TP_KEYS.join(', ')).on('keydown', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            clearTimeout(tpTimer);
            lookupTestPrice();
        }
    });

    $('#tp_search').on('click', function () {
        clearTimeout(tpTimer);
        lookupTestPrice();
    });

    // Refresh — ล้างทุกช่องแล้วเริ่มใหม่
    $('#tp_refresh').on('click', function () {
        clearTimeout(tpTimer);
        if (tpXhr) { tpXhr.abort(); tpXhr = null; }
        tpClearAuto('testno');
        tpClearAuto('lottest');
        TP_KEYS.forEach(function (sel) { $(sel).val(''); });
        clearTestPrice();
        $('#tp_customer').focus();
    });

    $('#testPriceModal').on('show.bs.modal', function () {
        clearTimeout(tpTimer);
        if (tpXhr) { tpXhr.abort(); tpXhr = null; }
        tpClearAuto('testno');
        tpClearAuto('lottest');
        TP_KEYS.forEach(function (sel) { $(sel).val(''); });
        clearTestPrice();
    });
    $('#testPriceModal').on('shown.bs.modal', function () {
        $('#tp_customer').focus();
    });

</script>

</body>
</html>
