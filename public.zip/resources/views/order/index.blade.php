<!doctype html>

<html lang="en" class="light-style layout-navbar-fixed layout-menu-fixed layout-compact" dir="ltr"
    data-theme="theme-default" data-assets-path="assets/" data-template="vertical-menu-template">

<head>
    @include('layout/inc_header')
    <title>ใบสั่งซื้อ - World Pigment</title>

</head>
<style>
.modalHeadDecor .modal-header {
    padding: 0;
}

.modalHeadDecor .modal-title {
    padding: 1.25rem 1.5rem 1.25rem;
    color: white;
    background-color: #54BAB9;
    position: relative;
}

.modalHeadDecor .modal-title::after {
    position: absolute;
    top: 0;
    right: -65px;
    content: '';
    width: 0;
    height: 0;
    border-top: 65px solid #54BAB9;
    border-right: 65px solid transparent;
}

/* badge สถานะบนหัว modal ใบสั่งซื้อ — ชิดขวา (21/09/2569 ตามที่ผู้ใช้สั่ง)
   margin-left:auto ดันไปขวาสุด (จึงพ้นสามเหลี่ยมเฉียง ::after ของ .modal-title ไปเอง)
   ⚠ margin-right เว้นที่ให้ปุ่มปิด ซึ่ง theme ตั้งเป็น position:absolute; right:1rem
      (absolute จึงไม่กินที่ในแนว flex — ถ้าไม่เว้น badge จะมุดไปอยู่ใต้ปุ่มปิด) */
#orderModal .modal-header #o_appv_status {
    margin-left: auto;
    margin-right: 4.5rem;
    white-space: nowrap;
}

/* ปุ่ม "สร้างราคาพิเศษใหม่" บนหัว modal ฟอร์ม MK — ชิดขวา (05/10/2569)
   margin-right เว้นที่ให้ปุ่มปิดซึ่งเป็น position:absolute (ไม่กินที่ในแนว flex) แบบเดียวกับ #o_appv_status */
/* แถบบอกโหมด/ขั้นตอน (#a_reqState) บนหัว modal ฟอร์ม MK — อยู่ระหว่างชื่อฟอร์มกับปุ่มสร้างใหม่ (05/10/2569)
   margin-left 77px = พ้นสามเหลี่ยมเฉียง ::after ของ .modal-title (ยื่นออกขวา 65px ไม่กินที่ในแนว flex)
   หดได้ (flex-shrink) + ข้อความตัดบรรทัดได้ เมื่อที่ไม่พอ */
#approvalModal .modal-header #a_reqState {
    margin: .25rem .75rem .25rem 77px;
    flex: 0 1 auto;
    min-width: 0;
    line-height: 1.35;
}
#approvalModal .modal-header #btnApprovalNew {
    margin-left: auto;
    margin-right: 4.5rem;
    white-space: nowrap;
}

/* หัว modal ใบสั่งซื้อ = ชื่อฟอร์ม · แถบประเภทใบสั่ง · badge สถานะ ในแถวเดียว (05/10/2569 ตามที่ผู้ใช้สั่ง)
   แถบประเภทย้ายมาจากตัวฟอร์ม จึงย่อขนาดลงให้สูงไม่เกินแถบ teal (65px) — กฎชุดนี้ทับค่าของ .of-typebar ด้านล่าง
   ⚠ margin-left ของแถบต้องพ้นสามเหลี่ยมเฉียง ::after ของ .modal-title (ยื่นออกขวา 65px และไม่กินที่ในแนว flex)
   flex-wrap เผื่อจอแคบ — ไม่พอแถวเดียวจะตกลงบรรทัดถัดไปแทนที่จะล้นออกนอก modal */
#orderModal .modal-header { flex-wrap: wrap; column-gap: .75rem; }
/* ลด padding ของแถบชื่อฟอร์ม (05/10/2569 ตามที่ผู้ใช้สั่ง) — เฉพาะ modal ใบสั่งซื้อ modal อื่นยังเท่าเดิม
   align-self:stretch ให้แถบ teal สูงเต็มหัว modal เสมอ (ความสูงหัวมาจากแถบประเภทใบสั่ง)
   ⚠ สามเหลี่ยมเฉียงของ modal นี้วาดด้วย clip-path สูง 100% ของแถบ แทน border 65px ตายตัวของ .modalHeadDecor
     ไม่งั้นพอแถบเตี้ยลง สามเหลี่ยมจะยื่นเลยขอบล่างของหัว modal */
#orderModal .modal-header .modal-title {
    align-self: stretch;
    display: flex;
    align-items: center;
    padding: .5rem 1.25rem;
}
#orderModal .modal-header .modal-title::after {
    right: -48px;
    width: 48px;
    height: 100%;
    border: 0;
    background-color: #54BAB9;
    clip-path: polygon(0 0, 100% 0, 0 100%);
}
#orderModal .modal-header .of-typebar { margin: .25rem 0 .25rem 54px; padding: .4rem .7rem; }
#orderModal .modal-header .of-typebar-inner { gap: .5rem 1.25rem; }
#orderModal .modal-header .of-typegrid { gap: .4rem 1.25rem; }
#orderModal .modal-header .of-tbtn { min-width: 46px; padding: .3rem .6rem; }

/* ── เรียงตาม — คลิกหัวตาราง + เน้นคอลัมน์ที่กำลังเรียง (เหมือนหน้าใบเสนอราคา) ── */
#table-data th.th-sort { cursor: pointer; user-select: none; }
#table-data th.th-sort:hover { background-color: #e9ecef; }
.th-sort-icon { font-size: .9rem; opacity: .35; vertical-align: middle; }
.th-sort-icon.active { opacity: 1; color: #ffd43b; font-size: 1.05rem; font-weight: 700; margin-left: .15rem; }
#table-data thead th.col-sorted { background-color: #696cff; color: #fff; box-shadow: inset 0 -3px 0 #ffd43b; }
#table-data thead th.col-sorted:hover { background-color: #5a5ef0; }
#table-data thead th.col-sorted small { color: rgba(255,255,255,.8) !important; }
#table-data tbody td.col-sorted { box-shadow: inset 2px 0 0 #696cff, inset -2px 0 0 #696cff; }

/* ══ ฟอร์มบันทึกใบสั่งซื้อ — คงผังและโทนสีของฟอร์ม Access เดิมไว้ ══ */

/* ══ แถบประเภทใบสั่ง — ปุ่มกลุ่ม (segmented) 21/09/2569 ══
   เดิมเป็น radio วงกลม 12 ตัวในกล่องพื้นม่วง — เปลี่ยนเป็นปุ่มติดกันกลุ่มละ 4 (C / H / W)
   ⚠ ตัว <input> ยังเป็น radio ตัวเดิม เพียงซ่อนด้วย .btn-check แล้วใช้ <label> เป็นปุ่ม
     ⇒ JS ที่อ่าน :checked / ตั้งค่าผ่าน #o_type_XX ทำงานเหมือนเดิมทุกอย่าง */
.of-typebar {
    /* พื้นหลังไล่สีม่วง — ค่าสีนี้ผู้ใช้เป็นคนกำหนดมาเอง (21/09/2569)
       เข้มทางซ้าย (#c8c1ff) จางไปทางขวา (#ecebfd) */
    background: linear-gradient(135deg, #c8c1ff 0%, #ecebfd 100%);
    border: 1px solid #ddd9f8;
    border-radius: .6rem;
    padding: .85rem 1.1rem;
    /* กว้างพอดีเนื้อหา ไม่ยืดเต็มแนว (21/09/2569 ตามที่ผู้ใช้สั่ง)
       max-width กันล้นเมื่อจอแคบ — เนื้อหาจะตัดขึ้นบรรทัดใหม่เองด้วย flex-wrap */
    width: fit-content;
    max-width: 100%;
}
.of-typebar-inner { display: flex; align-items: center; flex-wrap: wrap; gap: .85rem 1.75rem; }

/* ช่องไฟระหว่างชุด C / H / W — เว้นให้กว้าง จะได้เห็นชัดว่าเป็นคนละกลุ่ม (21/09/2569) */
.of-typegrid { display: flex; flex-wrap: wrap; gap: .6rem 4rem; }

/* 1 ชุด = ปุ่มของตัวอักษรเดียวกันติดกันเป็นก้อน (CM CI CE CR) */
.of-typeset {
    display: inline-flex;
    background: #fff;
    border: 1px solid #d8d5ee;
    border-radius: .5rem;
    overflow: hidden;
    box-shadow: 0 1px 2px rgba(58, 53, 65, .05);
}
/* ซ่อน radio เอง — ไม่ใช้ display:none เพราะจะกด Tab เข้าไม่ถึง (คุม focus ด้วย :focus-visible ข้างล่าง) */
.of-typebar .btn-check { position: absolute; clip: rect(0, 0, 0, 0); pointer-events: none; }
.of-tbtn {
    min-width: 54px;
    margin: 0;
    padding: .34rem .75rem;
    text-align: center;
    cursor: pointer;
    font-size: .82rem;
    font-weight: 600;
    letter-spacing: .3px;
    color: #5d5870;
    border-right: 1px solid #e7e6ec;
    transition: background-color .12s, color .12s;
}
.of-typeset .of-tbtn:last-of-type { border-right: 0; }
.of-tbtn:hover { background: #eeedff; color: #696cff; }
.btn-check:checked + .of-tbtn { background: #696cff; color: #fff; }
.btn-check:focus-visible + .of-tbtn { box-shadow: inset 0 0 0 2px rgba(105, 108, 255, .45); }
/* ⚠ radio ชุดนี้ไม่ถูก setOrderFormMode() สั่ง disable (มี .not ไว้) — กฎนี้เผื่อกรณีอื่นเท่านั้น */
.btn-check:disabled + .of-tbtn { opacity: .5; pointer-events: none; }

/* ปุ่ม "เพิ่มใบสั่งซื้อใหม่" — ดันไปชิดขวาสุดของแถบ */
.of-btn-new {
    margin-left: auto;
    background-color: #696cff;
    border-color: #696cff;
    color: #fff;
    font-weight: 600;
    font-size: .82rem;
    box-shadow: 0 2px 6px rgba(105, 108, 255, .3);
}
.of-btn-new:hover, .of-btn-new:focus {
    background-color: #5a5ef0;
    border-color: #5a5ef0;
    color: #fff;
}

/* กล่อง section ในฟอร์ม */
.of-sec {
    border: 1px solid #e2e7ea;
    border-radius: .6rem;
    padding: 1rem 1.15rem 1.15rem;
    /* พื้นไล่สีแบบเดียวกับแถบประเภทใบสั่ง (21/09/2569 ตามที่ผู้ใช้สั่ง "ใส่ bg ให้โปรเหมือนกัน")
       เข้มมุมซ้ายบน → จางไปมุมขวาล่าง · กล่องที่มีโทนสีของตัวเอง (stock/price/item)
       เขียนทับด้วย gradient โทนนั้น ๆ ด้านล่าง */
    background: linear-gradient(135deg, #eae7ff 0%, #fafaff 55%);
}
.of-sec-title {
    font-size: 1.05rem;
    font-weight: 700;
    /* หัวกล่องโทนม่วงให้เข้ากับพื้นไล่สีม่วงของ .of-sec (เดิมเป็นเขียวอมฟ้า #2f7a78)
       กล่อง stock / price / item มีสีหัวของตัวเอง override อยู่ด้านล่าง */
    color: #4b45c9;
    margin-bottom: .9rem;
    padding-bottom: .5rem;
    border-bottom: 2px solid #ddd9f8;
    display: flex;
    align-items: center;
    gap: .5rem;
}
/* หัวข้อของกล่อง "รายการในใบสั่งซื้อ" ห่อไอคอน+ข้อความไว้ใน <span> เดียวกัน (เพราะต้องดันปุ่มไปขวา)
   ⇒ gap ของ .of-sec-title ใช้กับคู่ span/ปุ่ม ไม่ได้ผลกับไอคอนข้างใน ต้องตั้ง gap ให้ span เองด้วย
   ไม่งั้นไอคอนจะชิดข้อความ ต่างจากหัวข้อกล่องอื่น (21/09/2569) */
.of-sec-title > span { display: inline-flex; align-items: center; gap: .5rem; }
.of-sec .form-label { margin-bottom: .25rem; font-size: .85rem; font-weight: 600; }

/* แถวช่องกรอกแบบ "label อยู่ซ้าย ต่อด้วย input" ตามฟอร์ม Access เดิม (05/10/2569 ตามที่ผู้ใช้สั่ง
   — เดิม label อยู่บน input) · โครง: <div class="of-row"><label class="form-label"> + <div class="of-ctl">
   ⚠ ช่องกรอกต้องอยู่ใน .of-ctl เสมอ — enhanceSelects() ห่อ <select> ด้วย element ใหม่ ถ้าวาง select
     เป็นลูกตรงของ .of-row ตัวห่อจะกลายเป็น flex item แทนแล้วความกว้างเพี้ยน
   ความกว้าง label ตั้งต่อกล่องด้วยตัวแปร --of-lw ให้ช่องกรอกในกล่องเดียวกันตรงแนวกัน
   .of-row-auto = label กว้างเท่าข้อความ (ช่องที่ 2 ของแถว เช่น วันที่ / P/O No. / รหัสผู้ขาย) */
.of-row { display: flex; align-items: flex-start; gap: .5rem; }
.of-sec .of-row > .form-label {
    flex: 0 0 var(--of-lw, 92px);
    margin-bottom: 0;
    padding-top: .5rem;      /* ให้ข้อความ label ตรงแนวกับข้อความในช่องกรอก */
    line-height: 1.25;
}
.of-sec .of-row.of-row-auto > .form-label { flex-basis: auto; white-space: nowrap; }
.of-row > .of-ctl { flex: 1 1 0; min-width: 0; }
.of-sec-stock { --of-lw: 122px; }
.of-sec-item  { --of-lw: 84px; }

/* ฟอร์ม MK ขออนุมัติราคาพิเศษ ใช้โครง .of-row ตัวเดียวกัน (05/10/2569 ตามที่ผู้ใช้สั่ง "ปรับให้กระชับเหมือนฟอร์ม Order")
   ⚠ selector ต้องมี .pa-body นำหน้า + ลึกกว่า `.pa-body .form-label` ด้านล่าง ไม่งั้น margin-bottom ของกฎนั้นชนะ */
.pa-body { --of-lw: 112px; }
.pa-body .of-row > .form-label {
    flex: 0 0 var(--of-lw);
    margin-bottom: 0;
    padding-top: .5rem;
    line-height: 1.25;
}
.pa-body .of-row.of-row-auto > .form-label { flex-basis: auto; white-space: nowrap; }
/* กล่อง "ราคาที่ตกลงไว้ล่าสุด" — ช่องเป็น form-control-sm จึงลด padding-top ของ label ให้ตรงแนว */
.pa-body .pa-sidebox { --of-lw: 84px; }
.pa-body .pa-sidebox .of-row > .form-label { padding-top: .3rem; }

/* กล่อง "รายการในใบสั่งซื้อ" — ไม่เอาพื้นไล่สี (21/09/2569 ตามที่ผู้ใช้สั่ง) ให้เป็นขาวล้วน
   ⚠ ชื่อ .of-sec-plain ตั้งไม่ให้ใกล้ .of-sec-item (กล่องสินค้า) เกินไป จะได้ไม่สับสนเวลาแก้ */
.of-sec-plain { background: #fff; border-color: #e2e7ea; }

/* กล่อง "กรณีสั่งทำสต๊อก" / "ราคา" / "สินค้า" — คงโทนสีประจำกล่องตามฟอร์มเดิม
   แต่เปลี่ยนเป็นพื้นไล่สีทิศทางเดียวกับแถบประเภทใบสั่ง (135deg เข้มซ้ายบน → จางขวาล่าง) */
.of-sec-stock { background: linear-gradient(135deg, #dfeefc 0%, #f9fcff 55%); border-color: #c4dcf2; }
.of-sec-stock .of-sec-title { color: #2c6ea4; border-bottom-color: #cfe2f3; }
.of-sec-price { background: linear-gradient(135deg, #fff3d5 0%, #fffdf6 55%); border-color: #ebdcbb; }
.of-sec-price .of-sec-title { color: #a3781f; border-bottom-color: #ecdfc4; }
.of-sec-item  { background: linear-gradient(135deg, #ddffe5 0%, #f9fdfa 55%); border-color: #cae3d1; }
.of-sec-item .of-sec-title { color: #4c7c3b; border-bottom-color: #d6e7cf; }

/* ช่องเน้นสีตามฟอร์ม Access */
.of-hl-yellow { background-color: #fffbcc !important; }
.of-hl-green  { background-color: #dff3d8 !important; }
.of-warn      { background-color: #fbdcc4 !important; font-weight: 600; }
.of-sell      { background-color: #e8e8e8 !important; }

/* ช่องอ่านอย่างเดียวในกล่องราคา — แสดงเป็นข้อความธรรมดา ไม่ใช่กล่อง input (08/10/2569)
   ยังเป็น <input readonly> อยู่ เพื่อให้ JS เดิม (.val()) ทำงานต่อได้ */
.of-sec-price .of-ro,
.of-sec-price .of-ro:focus {
    border-color: transparent !important;
    background-color: transparent !important;
    box-shadow: none !important;
    padding-right: 0;
    cursor: default;
}
.of-sec-price .of-ro.of-warn { color: #c2410c; font-weight: 700; }

/* แถว checkbox ท้ายกล่องซ้าย */
/* gap แนวตั้ง .2rem (เดิม 1.25rem เท่าแนวนอน) — itype ตัดขึ้นหลายบรรทัดหลัง label ย้ายมาอยู่ซ้าย (05/10/2569) */
.of-checkrow { display: flex; flex-wrap: wrap; gap: .2rem 1.25rem; padding-top: .35rem; }

/* กลุ่ม checkbox ของ itype — ขึ้นกรอบแดงเมื่อใบ W ยังไม่ได้ติ๊ก (syncItypeRequired) */
.of-itype-box { border: 1px solid transparent; border-radius: .375rem; padding: .1rem .5rem .35rem; }
.of-itype-box.is-invalid { border-color: var(--bs-danger); background-color: rgba(var(--bs-danger-rgb), .04); }
    /* ม่านโหลดข้อมูลของฟอร์มขออนุมัติราคา (12/09/2569)
       .modal-content เป็น position:relative อยู่แล้ว จึงคลุมได้ทั้งใบรวมหัว/ท้าย modal */
    .pa-loading { position: absolute; top: 0; right: 0; bottom: 0; left: 0; z-index: 10;
                  display: flex; align-items: center; justify-content: center;
                  background: rgba(255, 255, 255, .75); border-radius: inherit; }

/* ตารางรายการในใบสั่งซื้อ — ช่องกรอก (พื้นเหลืองอ่อนตามฟอร์ม Access เดิม) */
#orderItemsTable { background: #fffdf0; }
#orderItemsTable thead th {
    background: #f5e6c8;
    white-space: nowrap;
    font-size: .8rem;
    vertical-align: middle;
    text-align: center;
}
#orderItemsTable tfoot th { background: #f5e6c8; font-size: .85rem; }
#orderItemsTable td { font-size: .85rem; padding: .3rem .35rem; }
/* ตารางรายการมี 13 คอลัมน์ ความกว้างรวมเกิน modal-xl (1140px) อยู่มาก ต้องเลื่อนแนวนอนตลอด
   → ขยาย modal ใบสั่งซื้อให้เกือบเต็มจอ (เฉพาะ #orderModal — modal ฟอร์มลูกยังเป็น modal-xl เท่าเดิม) */
#orderModal .modal-dialog { max-width: 95vw; }

/* modal กว้าง 95vw เพื่อตารางรายการ แต่ส่วนหัวฟอร์มไม่ควรยืดตามจนอ่านยาก
   → จำกัดไว้ที่ 1200px แล้วจัดกึ่งกลาง (ตารางรายการไม่มี class นี้ จึงยังกว้างเต็ม modal)
   ⚠ ระวัง .row ที่มี margin ติดลบของ bootstrap — ใส่ max-width ตรง ๆ ได้ ไม่ต้องหักลบเพิ่ม */
#orderModal .of-narrow { max-width: 1200px; margin-left: auto; margin-right: auto; }

/* ปฏิทินของช่องวันที่ในตารางรายการถูกย้ายไปไว้ที่ <body> (static:false — ดู initRowPickers)
   flatpickr.css ของ theme ตั้ง z-index ไว้ 999 ซึ่งต่ำกว่า modal (--bs-modal-zindex: 1090)
   ปฏิทินจึงจมอยู่ใต้ modal — ยกขึ้นมาเหนือ modal แต่ยังต่ำกว่า toast (1095) / tooltip (1099) */
.flatpickr-calendar { z-index: 1092; }

/* min-width เป็นค่าเริ่มต้นตอนช่องว่าง — oiAutoGrow() จะตั้ง min-width แบบ inline ทับให้โตตามข้อความ */
#orderItemsTable .oi-input { min-width: 80px; }
#orderItemsTable .oi-input:focus { background: #fffbe0; }

/* ข้อความบอกที่มา/เหตุผลใต้กล่องราคา */
.of-price-note {
    font-size: .78rem;
    color: #7a6a45;
    line-height: 1.35;
    margin-top: .35rem;
    min-height: 1rem;
}
.of-price-note-warn {
    color: #8a4b0f;
    background: #fdf0e2;
    border: 1px solid #f0d5b4;
    border-radius: .375rem;
    padding: .35rem .5rem;
}

/* แถบเตือน "ต้อง Match ใหม่" — แถบแดงเหมือนฟอร์มเดิม */
.of-matchwarn {
    background: #d32f2f;
    color: #fff;
    font-weight: 700;
    text-align: center;
    padding: .45rem .75rem;
    border-radius: .375rem;
    margin-bottom: .75rem;
}

/* ══ ฟอร์มขออนุมัติราคาพิเศษ — โทนฟ้าตามฟอร์ม Access เดิม ══ */
.pa-body { background: #eef6fb; }
.pa-body .form-label { margin-bottom: .25rem; font-size: .85rem; font-weight: 600; }

/* ช่องราคา 3 ช่อง + ช่องพิเศษ — กล่องเล็กเรียงแนวนอน */
/* 108px (เดิม 130) — ให้ 5 กล่องพอในแถวเดียวหลัง label ย้ายมาอยู่ซ้าย (05/10/2569) */
.pa-pricebox { width: 108px; }
.pa-pricebox-cap {
    font-size: .72rem;
    font-weight: 600;
    color: #5a6a78;
    margin-bottom: .15rem;
    white-space: nowrap;
}
/* กลุ่มราคาที่ตรงกับจำนวนสั่งซื้อ — เน้นกรอบให้เห็นว่าใช้ช่องไหน */
.pa-pricebox.pa-active .form-control { border-color: #0d6efd; box-shadow: 0 0 0 .18rem rgba(13,110,253,.18); font-weight: 700; }
.pa-pricebox.pa-active .pa-pricebox-cap { color: #0d6efd; }

/* ป้ายเกณฑ์กลุ่มราคา A/B/C ใต้ช่อง "จำนวนสั่งซื้อ" (12/09/2569) — ตามฟอร์ม Access เดิม */
.pa-grouplegend { display: flex; flex-wrap: wrap; gap: .5rem; }
.pa-gitem {
    min-width: 180px;   /* เดิม width:150px ตายตัว — ข้อความ "กลุ่ม C = under 500 kg." ตกบรรทัด (05/10/2569) */
    padding: .35rem .6rem;
    text-align: center;
    font-size: .78rem;
    font-weight: 600;
    color: #5a6a78;
    background: #fff;
    border: 1px solid #b6d2e6;
    border-radius: .375rem;
}
/* กลุ่มที่ตรงกับจำนวนสั่งซื้อ — เน้นให้เข้าชุดกับกรอบราคาที่ถูกเน้น (.pa-pricebox.pa-active) */
.pa-gitem.pa-active {
    color: #0d6efd;
    border-color: #0d6efd;
    box-shadow: 0 0 0 .18rem rgba(13, 110, 253, .18);
}
/* ราคาของกลุ่มนั้น ๆ = บรรทัดล่างของป้าย (19/09/2569) */
/* nowrap = กล่องกว้างตามข้อความ ไม่ให้ตกบรรทัด (05/10/2569 ตามที่ผู้ใช้สั่ง — "กลุ่ม C = under 500 kg." เคยขึ้น 2 บรรทัด) */
.pa-gitem-cap   { display: block; white-space: nowrap; }
.pa-gitem-price {
    display: block;
    margin-top: .15rem;
    font-size: .95rem;
    font-weight: 700;
    color: #1f2d3a;
}
.pa-gitem.pa-active .pa-gitem-price { color: #0d6efd; }

.pa-hl-yellow { background-color: #fff59d !important; font-weight: 600; }
.pa-hl-pink   { background-color: #f8bbd0 !important; font-weight: 600; }
.pa-sell      { background-color: #fff !important; color: #d32f2f; }

/* กล่องข้อมูลราคาที่ตกลงไว้ (คอลัมน์ขวา) */
.pa-sidebox {
    background: #fff;
    border: 1px solid #cfe2f3;
    border-radius: .6rem;
    padding: 1rem;
}
.pa-sidebox-title {
    font-size: .95rem;
    font-weight: 700;
    color: #2c6ea4;
    margin-bottom: .75rem;
    padding-bottom: .45rem;
    border-bottom: 2px solid #cfe2f3;
    display: flex;
    align-items: center;
    gap: .5rem;
}

#approvalGridTable th { white-space: nowrap; font-size: .8rem; }
#approvalGridTable td { font-size: .85rem; }

/* ══ ฟอร์มอนุมัติใบสั่งซื้อ (morderAPPV) — โทนเทาอ่อนตามฟอร์มเดิม ══ */
.oa-body { background: #f4f4f0; }
.oa-body .form-label { margin-bottom: .25rem; font-size: .85rem; font-weight: 600; }
.oa-checkrow { display: flex; flex-wrap: wrap; gap: 1.25rem; padding: .45rem .75rem; background: #fff; border: 1px solid #d9d9d2; border-radius: .375rem; }
/* 06/10/2569: ฟอร์มอนุมัติใบสั่งซื้อใช้แถวแบบ "label อยู่ซ้าย" (โครง .of-row/.of-ctl — CSS กลางที่ layout/inc_header) */
#oaDetailView { --of-lw: 104px; }

/* ตารางรายการ — พื้นเหลืองเหมือนฟอร์มเดิม */
.oa-grid table { background: #ffffdd; }
#oaItemsTable thead th { background: #e8e8d0; white-space: nowrap; font-size: .8rem; }
#oaItemsTable tbody tr { cursor: pointer; }
#oaItemsTable tbody tr:hover { background: #fff9a8; }
#oaItemsTable tbody tr.oa-selected { background: #ffe082; font-weight: 600; }
#oaItemsTable td { font-size: .85rem; }

/* ตารางคิวรออนุมัติ (หน้าแรกของฟอร์ม) — คลิกทั้งแถวเพื่อเข้าใบนั้น */
#oaQueueTable thead th { background: #e8e8d0; white-space: nowrap; font-size: .8rem; }
#oaQueueTable tbody tr { cursor: pointer; }
#oaQueueTable tbody tr:hover { background: #fff9a8; }
#oaQueueTable td { font-size: .85rem; }
/* ปุ่มคอลัมน์ "จัดการ" — กันคำว่า "รออนุมัติ" ตกบรรทัดเมื่อคอลัมน์แคบ */
#oaQueueTable td .btn { white-space: nowrap; }

.oa-hl-blue  { background-color: #cfe9fb !important; }
.oa-hl-green { background-color: #ccffcc !important; }
.oa-sell     { background-color: #ffcdd2 !important; color: #c62828; font-size: 1.15rem; }

/* แถบเดินระเบียน "ใบที่รออนุมัติ" ใน modal-footer ของฟอร์มขออนุมัติราคาพิเศษ (12/09/2569)
   โทนฟ้าให้เข้าชุดกับพื้นฟอร์ม .pa-body (#eef6fb) แต่เข้มกว่าเล็กน้อยให้เห็นเป็นแถบ */
.pa-nav {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: .35rem;
    padding: .5rem .75rem;
    background: #d9e9f5;
    border: 1px solid #b6d2e6;
    border-radius: .375rem;
    font-size: .85rem;
}

/* แถบเดินระเบียนล่างฟอร์ม */
.oa-nav {
    display: flex;
    align-items: center;
    gap: .35rem;
    padding: .5rem .75rem;
    background: #e6e6de;
    border: 1px solid #cfcfc4;
    border-radius: .375rem;
    font-size: .85rem;
}
</style>

<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->
            @include('layout/inc_sidemenu')
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->

                @include('layout/inc_topmenu')

                <!-- / Navbar -->

                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->

                    <div class="container-xxl flex-grow-1 container-p-y">

    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body d-flex justify-content-between align-items-center flex-wrap gap-3">

                    <div>
                        <h3 class="mb-1">
                            <i class="ti ti-shopping-cart text-primary"></i>
                            ใบสั่งซื้อ
                        </h3>
                        <p class="text-muted mb-0">
                            บันทึกคำสั่งซื้อจากลูกค้า (morder / suborder)
                        </p>
                    </div>

                    <div class="d-flex gap-2 flex-wrap">
                        <button class="btn btn-label-warning border" onclick="orderApprovalOpen()">
                            <i class="ti ti-gavel me-1"></i>
                            อนุมัติใบสั่งซื้อ
                            <span class="badge bg-danger ms-1 d-none" id="oaQueueBadge">0</span>
                        </button>
                        {{-- พิมพ์ PDF ใบสั่งซื้อที่อนุมัติ เรียงตามเลขที่ใบสั่ง (06/10/2569) — 07/10/2569: เปิดหน้าต่างเลือก
                             แผนก / วันที่ / ช่วงเวลา / S-P ก่อน (#prodReportModal ตามฟอร์ม Access เดิม)
                             → OrderApprovalController::approvedTodayPdf() --}}
                        <button class="btn btn-label-secondary border" onclick="prodReportOpen()">
                            <i class="ti ti-printer me-1"></i>
                            พิมพ์รายงานที่ต้องผลิต
                        </button>
                        {{-- ประมาณการยอดขาย ตามรหัสพนักงานขาย (15/10/2569 — ฟอร์ม Access "SaleOrder") → #salesForecastModal --}}
                        <button class="btn btn-label-secondary border" onclick="salesForecastOpen()">
                            <i class="ti ti-report-money me-1"></i>
                            ประมาณการยอดขาย
                        </button>
                        <button class="btn btn-label-primary border" style="color: #1f158e;" onclick="approvalOpen()">
                            <i class="ti ti-discount-check me-1"></i>
                            ขออนุมัติราคาพิเศษ
                            {{-- จำนวนใบขอราคาที่ยังไม่อนุมัติ (12/09/2569) — อัปเดตใน paLoadQueue() --}}
                            <span class="badge bg-danger ms-1 d-none" id="paQueueBadge">0</span>
                        </button>
                        {{-- ดูกลุ่มราคา (zcolorrate) แบบอ่านอย่างเดียว — 19/09/2569
                             ค่าชุดเดียวกับช่อง "ขั้นต่ำ" ในกล่องราคาของฟอร์มใบสั่งซื้อ --}}
                        <button class="btn btn-label-secondary border" onclick="openColorRateLookup()">
                            <i class="ti ti-layers-difference me-1"></i>
                            ดูกลุ่มราคา
                        </button>
                        <button class="btn btn-primary" onclick="orderOpenNew()">
                            <i class="ti ti-plus me-1"></i>
                            เพิ่มใบสั่งซื้อใหม่
                        </button>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- Table -->
    <div class="card">

        <div class="card-header border-bottom">

            {{-- แถบหัว: ปุ่มพับ/กางตัวกรอง + ปุ่มล้างตัวกรอง (ชิดขวาทั้งคู่) — ค่าเริ่มต้นคือ "ซ่อนไว้" --}}
            <div class="d-flex justify-content-end align-items-center gap-2">
                {{-- รายละเอียดการค้นหา — สรุปเงื่อนไขที่กรองอยู่ โชว์เฉพาะตอนพับตัวกรอง --}}
                <div id="filterSummary" class="d-flex flex-wrap align-items-center gap-1 me-auto"></div>
                <button type="button" id="btnToggleFilters" class="btn btn-label-primary btn-sm"
                    data-bs-toggle="collapse" data-bs-target="#orderFilterBox"
                    aria-expanded="false" aria-controls="orderFilterBox">
                    <i class="ti ti-filter me-1"></i>ตัวกรอง
                    <i class="ti ti-chevron-down ms-1 toggle-caret"></i>
                </button>
                <button type="button" id="btnResetFilters" class="btn btn-label-secondary btn-sm" onclick="resetFilters()">
                    <i class="ti ti-x me-1"></i>ล้างตัวกรอง<span class="filter-count ms-1"></span>
                </button>
            </div>

            <div class="collapse" id="orderFilterBox">
            <div class="pt-3">

            {{-- แถวตัวกรอง 1: ค้นหา + ช่วงวันที่ --}}
            <div class="row g-3 align-items-end">
                <div class="col-md-6">
                    <label class="form-label small fw-medium mb-1">
                        ค้นหา
                        <span class="text-muted fw-normal">(เลขที่ใบสั่ง / P.O. / รหัสลูกค้า / ชื่อลูกค้า / รหัสสินค้า)</span>
                    </label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="ti ti-search"></i></span>
                        <input type="text" name="search" class="form-control p_search" oninput="loadData(page)">
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-medium mb-1">วันที่สั่ง</label>
                    <div class="d-flex align-items-center gap-2">
                        <span class="small fw-medium">ตั้งแต่</span>
                        <input type="text" name="date_from" class="form-control flatpickr-date p_search" autocomplete="off" placeholder="วว/ดด/ปปปป">
                        <span class="small fw-medium">ถึง</span>
                        <input type="text" name="date_to" class="form-control flatpickr-date p_search" autocomplete="off" placeholder="วว/ดด/ปปปป">
                    </div>
                </div>
            </div>

            {{-- แถวตัวกรอง 2: รหัสสินค้า + ประเภทใบสั่ง + ผลิตที่ --}}
            <div class="row g-3 align-items-end mt-1">
                {{-- ช่องค้นหารหัสสินค้าแยกจากช่องค้นหารวม (16/09/2569) — ค้น suborder.Itemno แบบ LIKE --}}
                <div class="col-md-4">
                    <label class="form-label small fw-medium mb-1">รหัสสินค้า</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="ti ti-package"></i></span>
                        <input type="text" name="itemno" class="form-control p_search" oninput="loadData(page)">
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-medium mb-1">ประเภทใบสั่ง</label>
                    <select name="order_type" class="form-select p_search" onchange="loadData(page)">
                        <option value="">ทั้งหมด</option>
                        @foreach ($type_rows as $types)
                            @foreach ($types as $t)
                                <option value="{{ $t }}">{{ $t }}</option>
                            @endforeach
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-medium mb-1">ผลิตที่</label>
                    <select name="company" class="form-select p_search" onchange="loadData(page)">
                        <option value="">ทั้งหมด</option>
                        @foreach ($companies as $c)
                            <option value="{{ $c }}">{{ $c }}</option>
                        @endforeach
                    </select>
                </div>
                {{-- ตัวกรองสถานะการอนุมัติ (19/09/2569) — class p_search ทำให้เข้าระบบตัวกรองกลางเอง
                     (ส่งเข้า query · นับจำนวนบนปุ่มล้างตัวกรอง · ปุ่มล้าง · แถบสรุป) --}}
                <div class="col-md-4">
                    <label class="form-label small fw-medium mb-1">สถานะ</label>
                    <select name="appv_status" class="form-select p_search" onchange="loadData(page)">
                        <option value="">ทั้งหมด</option>
                        @foreach ($appv_statuses as $key => $st)
                            <option value="{{ $key }}">{{ $st['label'] }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            </div>
            </div>
            {{-- /#orderFilterBox --}}

            {{-- state การเรียง — เก็บนอก #table-data เพื่อคงค่าเมื่อตารางโหลดใหม่ (default = วันที่สั่งล่าสุด) --}}
            <input type="hidden" name="sort_col" value="Mdate" class="p_search">
            <input type="hidden" name="sort_dir" value="desc" class="p_search">

            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                <div class="d-flex align-items-center">
                    <label class="form-label small fw-medium mb-0 me-2">เรียงตามวันที่สั่ง</label>
                    <select name="sort" class="form-select form-select-sm" style="width: 210px;"
                        onchange="onSortDropdown(this.value)">
                        <option value="desc">ล่าสุด</option>
                        <option value="asc">เก่าสุด</option>
                        <option value="" hidden>เรียงตามคอลัมน์ (คลิกหัวตาราง)</option>
                    </select>
                </div>
                <div class="d-flex align-items-center">
                    <label class="form-label small fw-medium mb-0 me-2">แสดง</label>
                    <select name="limit" class="form-select form-select-sm p_search" style="width: 90px;"
                        onchange='loadData("{{ $page_url }}/datatable")'>
                        <option value="15">15</option>
                        <option value="50">50</option>
                        <option value="75">75</option>
                        <option value="100">100</option>
                    </select>
                    <span class="ms-2 small fw-medium">รายการ/หน้า</span>
                </div>
            </div>
        </div>

        <div id="table-data">
            {{-- Table โหลดผ่าน AJAX จาก order/datatable --}}
            <div class="text-center py-5 text-muted">
                <div class="spinner-border spinner-border-sm me-2"></div>
                กำลังโหลดข้อมูล...
            </div>
        </div>

    </div>

</div>
                    <!-- / Content -->

                    <!-- Footer -->
                    @include('layout/inc_footer')
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>

        <!-- Drag Target Area To SlideIn Menu On Small Screens -->
        <div class="drag-target"></div>
    </div>

<!-- ═══════════════════════════════════════════════════════════════ -->
<!-- Modal: ฟอร์มบันทึกใบสั่งซื้อ (ผังตามฟอร์ม Access เดิม)             -->
<!-- ═══════════════════════════════════════════════════════════════ -->
<div class="modal modalHeadDecor fade" id="orderModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="orderModalTitle">บันทึกคำสั่งซื้อ</h5>

                {{-- ── แถบประเภทใบสั่งซื้อ (radio) — 2 ตัวอักษรหน้าเลขที่ใบสั่ง ──
                     05/10/2569: ย้ายจากบนสุดของตัวฟอร์ม (order/form.blade.php) ขึ้นมาอยู่บนหัว modal
                     ให้ ชื่อฟอร์ม · แถบประเภท · badge สถานะ อยู่แถวเดียวกัน ตามที่ผู้ใช้สั่ง
                     ⚠ <input> ยังเป็น radio name="order_type_form" id="o_type_XX" + onchange เดิมทุกประการ
                       แค่ซ่อนตัว input ด้วย .btn-check แล้วให้ <label> เป็นตัวปุ่มแทน ⇒ JS เดิมทำงานต่อได้เลย
                       (onOrderTypeChange / orderNew / fillOrderForm / setOrderFormMode ที่ยกเว้น name นี้ไม่ให้ disable)
                       และยังอยู่ใต้ #orderModal จึงโดน selector เดิมครบ --}}
                @php
                    /* จัดปุ่มเป็น 3 กลุ่มตามตัวอักษรแรก (C / H / W) โดยไล่ลำดับเดิมใน OrderController::TYPE_ROWS
                       (M → I → E → R) — คำนวณที่นี่ ไม่ได้แก้ controller */
                    $type_groups = [];
                    foreach ($type_rows as $__row) {
                        foreach ($__row as $__t) {
                            $type_groups[substr($__t, 0, 1)][] = $__t;
                        }
                    }
                @endphp
                <div class="of-typebar">
                    <div class="of-typebar-inner">
                        <div class="of-typegrid">
                            @foreach ($type_groups as $group)
                                <div class="of-typeset" role="group">
                                    @foreach ($group as $t)
                                        <input class="btn-check" type="radio" name="order_type_form" id="o_type_{{ $t }}"
                                            value="{{ $t }}" autocomplete="off" onchange="onOrderTypeChange('{{ $t }}')">
                                        <label class="of-tbtn" for="o_type_{{ $t }}">{{ $t }}</label>
                                    @endforeach
                                </div>
                            @endforeach
                        </div>

                        <button type="button" class="btn btn-sm of-btn-new" onclick="orderNew()">
                            <i class="ti ti-plus me-1"></i>เพิ่มใบสั่งซื้อใหม่
                        </button>
                    </div>
                </div>

                {{-- สถานะการอนุมัติของใบที่เปิดอยู่ (21/09/2569 ตามที่ผู้ใช้สั่ง)
                     วางไว้ "นอก" .modal-title โดยตั้งใจ — ให้อยู่บนพื้นขาวถัดจากแถบ teal
                     ⚠ ต้องเว้นระยะให้พ้นสามเหลี่ยม ::after ของ .modal-title (ดู CSS #o_appv_status)
                     ป้าย/สี มาจาก OrderController::APPV_STATUSES ชุดเดียวกับคอลัมน์ "สถานะ" ในตารางรายการ
                     (อย่า hard-code ซ้ำ) · เติมค่าโดย fillOrderStatus() --}}
                <span id="o_appv_status" class="badge bg-label-secondary">—</span>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            @include('order.form')

            <div class="modal-footer">
                <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">ปิด</button>
            </div>

        </div>
    </div>

    {{-- ฟอร์มตรวจราคาเม็ด CP ก่อนบันทึก (16/10/2569) — ต้องอยู่ "ใน" #orderModal ดูเหตุผลในไฟล์ --}}
    @include('order.cp-price-check')
</div>

<!-- ═══════════════════════════════════════════════════════════════ -->
<!-- Modal: อนุมัติใบสั่งซื้อ (morderAPPV) — ผังตามฟอร์ม Access เดิม -->
<!-- ═══════════════════════════════════════════════════════════════ -->
{{-- ═══ หน้าต่างเลือกเงื่อนไขก่อนพิมพ์ "รายงานผลิตภัณฑ์ที่ต้องผลิต" (07/10/2569 — ตามฟอร์ม Access เดิม) ═══
     กด "ออกรายงาน" → เปิด PDF แท็บใหม่ (OrderApprovalController::approvedTodayPdf) · ไม่รวมใบ HE --}}
<div class="modal fade" id="prodReportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-printer me-2"></i>รายงานผลิตภัณฑ์ที่ต้องผลิต</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body of-form" style="--of-lw: 100px;">
                <div class="of-row mb-2">
                    <label class="form-label" for="pr_dept">แผนกที่ผลิต</label>
                    <div class="of-ctl">
                        <select id="pr_dept" class="form-select no-enhance">
                            @foreach ($companies as $c)
                                <option value="{{ $c }}">{{ $c }}</option>
                            @endforeach
                            {{-- ทุกแผนก = ไม่กรองแผนก รายงานแยกหน้าตามแผนก — ใบที่ไม่ได้ระบุ "ผลิตที่" จะออกในหน้า "ไม่ระบุ"
                                 (07/10/2569: ใบที่ Company ว่างไม่ตรงกับแผนกไหนเลย เลือกแผนกแล้วจึงไม่ออก) --}}
                            <option value="">ทุกแผนก (รวมใบที่ไม่ระบุแผนก)</option>
                        </select>
                    </div>
                </div>
                <div class="of-row mb-2">
                    <label class="form-label" for="pr_date">วันที่</label>
                    <div class="of-ctl">
                        <input type="text" id="pr_date" class="form-control" autocomplete="off">
                    </div>
                </div>
                <div class="of-row mb-2">
                    <label class="form-label" for="pr_time_from">ระหว่างเวลา</label>
                    <div class="of-ctl">
                        <div class="d-flex align-items-center gap-2">
                            <input type="text" id="pr_time_from" class="form-control" autocomplete="off">
                            <span class="fw-semibold">ถึง</span>
                            <input type="text" id="pr_time_to" class="form-control" autocomplete="off">
                        </div>
                    </div>
                </div>
                <div class="of-row">
                    <label class="form-label">ชนิด</label>
                    <div class="of-ctl">
                        <div class="d-flex gap-4 pt-2">
                            <div class="form-check mb-0">
                                <input class="form-check-input" type="radio" name="pr_type" id="pr_type_p" value="P" checked>
                                <label class="form-check-label" for="pr_type_p">P (ผลิต)</label>
                            </div>
                            <div class="form-check mb-0">
                                <input class="form-check-input" type="radio" name="pr_type" id="pr_type_s" value="S">
                                <label class="form-check-label" for="pr_type_s">S (สต๊อก)</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer justify-content-between">
                <span class="badge bg-label-danger">ไม่รวม HE</span>
                <div>
                    <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">ปิด</button>
                    <button type="button" class="btn btn-primary" onclick="prodReportPrint()">
                        <i class="ti ti-printer me-1"></i>ออกรายงาน
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- ═══ หน้าต่าง "ประมาณการยอดขาย ตามรหัสพนักงานขาย" (15/10/2569 — ฟอร์ม Access "SaleOrder") ═══
     ใช้ได้แล้วเฉพาะปุ่ม "ยอดรับ Order" → SalesForecastController::orderPdf()
     อีก 3 ปุ่มยังไม่รู้เงื่อนไข (class wip) --}}
<div class="modal fade" id="salesForecastModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="ti ti-report-money me-2"></i>ประมาณการยอดขาย ตามรหัสพนักงานขาย</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body of-form" style="--of-lw: 130px;">
                <div class="row gx-3 gy-2">
                    <div class="col-md-6 of-row">
                        <label class="form-label" for="sf_sale">รหัสพนักงานขาย</label>
                        <div class="of-ctl">
                            <select id="sf_sale" class="form-select no-enhance">
                                <option value="">รวม</option>
                                @foreach ($sale_codes as $s)
                                    <option value="{{ $s }}">{{ $s }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row gx-3 gy-2 mt-0">
                    <div class="col-md-6 of-row">
                        <label class="form-label" for="sf_from">ช่วง วันที่-เวลา</label>
                        <div class="of-ctl"><input type="text" id="sf_from" class="form-control" autocomplete="off"></div>
                    </div>
                    <div class="col-md-6 of-row of-row-auto">
                        <label class="form-label" for="sf_to">ถึง วันที่-เวลา</label>
                        <div class="of-ctl"><input type="text" id="sf_to" class="form-control" autocomplete="off"></div>
                    </div>
                </div>
                <div class="row g-2 mt-3">
                    <div class="col-md-4">
                        <button type="button" class="btn btn-outline-primary w-100" onclick="salesForecastPrint('order')">ยอดรับ Order</button>
                    </div>
                    <div class="col-md-4">
                        <button type="button" class="btn btn-outline-danger w-100 wip" onclick="salesForecastPrint('due')">กำหนดส่ง (แรก)</button>
                    </div>
                    <div class="col-md-4">
                        <button type="button" class="btn btn-outline-primary w-100 wip" onclick="salesForecastPrint('latest')">เลื่อนล่าสุด</button>
                    </div>
                    <div class="col-12">
                        <button type="button" class="btn btn-outline-secondary w-100 wip" onclick="salesForecastPrint('delivered')">ยอดขาย ที่จัดส่งลูกค้า เฉพาะราคาผ่านช่อง 2</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">ปิด</button>
            </div>
        </div>
    </div>
</div>

<div class="modal modalHeadDecor fade" id="orderApprovalModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">
                    อนุมัติใบสั่งซื้อ
                    <span class="fw-normal" style="font-size:.8rem;">(ไม่รวมทำ STOCK + ไม่รวมใบจอง R)</span>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            @include('order.order-approval')

            <div class="modal-footer">
                <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">ปิด</button>
            </div>

        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════════════ -->
<!-- Modal: ขออนุมัติราคาพิเศษ (MD) — ผังตามฟอร์ม Access เดิม           -->
<!-- ═══════════════════════════════════════════════════════════════ -->
<div class="modal modalHeadDecor fade" id="approvalModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">

            {{-- ม่านโหลดข้อมูล — ขึ้นตอนกด Refresh (ดู apvOverlay ท้ายไฟล์) --}}
            <div id="approvalLoading" class="pa-loading d-none">
                <div class="text-center">
                    <div class="spinner-border text-primary"></div>
                    <div class="mt-2 small fw-semibold">กำลังโหลดข้อมูล...</div>
                </div>
            </div>

            <div class="modal-header">
                <h5 class="modal-title">MK ขออนุมัติราคาพิเศษ</h5>
                {{-- แถบบอกโหมด/ขั้นตอนของคู่ (ลูกค้า, เบอร์) — ยังไม่มีใบ / รออนุมัติ / อนุมัติแล้ว / กำลังสร้างใหม่
                     ย้ายจากบนสุดของตัวฟอร์มขึ้นมาอยู่บนหัว modal (05/10/2569 ตามที่ผู้ใช้สั่ง)
                     เติมโดย renderApprovalReqState() · ระยะซ้ายเว้นให้พ้นสามเหลี่ยม ::after ของ .modal-title (ดู CSS) --}}
                <div id="a_reqState" class="alert py-1 px-3 mb-0 small"></div>
                {{-- เข้าโหมด "สร้างใหม่" — ต้องกดปุ่มนี้ก่อนถึงจะเพิ่มใบขอราคาใบใหม่ได้ (05/10/2569)
                     ย้ายจากแถวปุ่มในตัวฟอร์มมาไว้มุมขวาบนของหัว modal ตามที่ผู้ใช้สั่ง
                     ดู setApprovalFormMode() / approvalNew() · ระยะขวาเว้นให้ปุ่มปิด (position:absolute) ดู CSS #btnApprovalNew --}}
                <button type="button" id="btnApprovalNew" class="btn btn-primary" onclick="approvalNew()">
                    <i class="ti ti-plus me-1"></i>สร้างราคาพิเศษใหม่
                </button>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            @include('order.price-approval')

            <div class="modal-footer justify-content-between">
                {{-- ตัวเดินระเบียน: ใบขอราคาที่ยังไม่อนุมัติทั้งหมด (12/09/2569)
                     เปิดฟอร์มมาจะเด้งเข้าใบแรกให้เอง แล้วกดลูกศรซ้าย/ขวาไล่ดูใบอื่นได้
                     (ดู paLoadQueue / paGo / paStep ท้ายไฟล์นี้) --}}
                <div class="pa-nav">
                    <span class="fw-semibold me-1">ใบที่รออนุมัติ:</span>
                    <button type="button" class="btn btn-sm btn-label-secondary" onclick="paGo(0)" title="แรกสุด">
                        <i class="ti ti-chevrons-left"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-label-secondary" onclick="paStep(-1)" title="ก่อนหน้า">
                        <i class="ti ti-chevron-left"></i>
                    </button>
                    <input type="number" id="pa_pos" class="form-control form-control-sm text-center" style="width:80px;"
                        min="1" onchange="paGo(this.value - 1)">
                    <button type="button" class="btn btn-sm btn-label-secondary" onclick="paStep(1)" title="ถัดไป">
                        <i class="ti ti-chevron-right"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-label-secondary" onclick="paGo(-1)" title="ท้ายสุด">
                        <i class="ti ti-chevrons-right"></i>
                    </button>
                    <span>จาก <span id="pa_total" class="fw-bold">0</span></span>
                    {{-- ลูกค้า / เบอร์ ของระเบียนที่กำลังดูอยู่ --}}
                    <span id="pa_info" class="text-muted small ms-2"></span>
                </div>

                <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">ปิด</button>
            </div>

        </div>
    </div>
</div>

    <!-- / Layout wrapper -->
    @include('color-rate.lookup-modal')   {{-- modal "ดูกลุ่มราคา" (อ่านอย่างเดียว) — 19/09/2569 --}}
    @include('layout/inc_js')
<script>
    var page = "{{ $page_url }}/datatable";
    var searchData = {};
    // ต้องประกาศก่อน loadData ครั้งแรก — เลี่ยง hoisting ทำให้ dtSeq เป็น NaN (spinner ค้าง)
    var dtXhr = null, dtSeq = 0;

    // ป้ายชื่อของแต่ละช่องกรอง — ใช้ประกอบแถบ "รายละเอียดการค้นหา" (#filterSummary)
    // ⚠ ต้องประกาศตรงนี้ (ก่อน loadData ครั้งแรก) เพราะ renderFilterSummary() ถูกเรียกใน loadData
    //   ถ้าไปประกาศท้ายไฟล์ ตัวแปรจะยังเป็น undefined ตอนโหลดหน้า → throw แล้ว spinner ค้าง
    var FILTER_LABELS = {
        search:     'ค้นหา',
        itemno:     'รหัสสินค้า',
        date_from:  'วันที่สั่ง ตั้งแต่',
        date_to:    'ถึง',
        order_type:  'ประเภทใบสั่ง',
        company:     'ผลิตที่',
        appv_status: 'สถานะ'
    };

    loadData(page);

    $(function () {
        // ยกระดับ select ทั้งหน้า (ตัวกรอง + modal ใบสั่งซื้อ/ขออนุมัติราคา/อนุมัติใบสั่งซื้อ)
        // ตัวช่วยกลางใน layout/inc_js เลือกให้เองตามจำนวนตัวเลือก:
        //   ตั้งแต่ 10 ตัวขึ้นไป → select2 (พิมพ์ค้นหาได้) · ต่ำกว่านั้น → bootstrap-select
        // ช่องที่เติมตัวเลือกทีหลังด้วย JS (สถานที่ส่ง / รหัสสินค้าในใบขออนุมัติราคา)
        // ไม่ต้องเรียกซ้ำเอง — ตัวช่วยกลางเฝ้าดู option แล้วสลับชนิดให้เมื่อรายการยาวขึ้น
        // ⚠ ต้องมาก่อน flatpickr เพื่อไม่ให้ไปจับ <select> เดือน/ปี ที่ flatpickr สร้าง
        enhanceSelects();
        flatpickr('.flatpickr-date', {
            dateFormat: 'd/m/Y',
            allowInput: true,
            static: true,
            disableMobile: true,
            onChange: function (_, __, instance) {
                if (instance.input.classList.contains('p_search')) loadData(page);
            }
        });
        // ช่องวันที่ที่มีเวลาด้วย (วันที่เปิดใบสั่ง)
        // 19/09/2569: อ่านอย่างเดียว — Mdate ถูกกำหนดที่ server ตอนสร้างใบ (OrderController::create)
        //   clickOpens:false = คลิกแล้วปฏิทินไม่เด้ง · allowInput:false = พิมพ์เองไม่ได้
        //   ยังต้อง init อยู่ เพราะ setFpDateTime() ใช้ instance นี้จัดรูปแบบค่าที่โหลดมาจากใบเดิม
        flatpickr('.flatpickr-datetime', {
            dateFormat: 'd/m/Y H:i',
            enableTime: true,
            time_24hr: true,
            allowInput: false,
            clickOpens: false,
            static: true,
            disableMobile: true
        });
        syncSortDropdown();
    });

    // ────────────────────────────────────────────────────────
    //  เรียงลำดับ — state เดียว (sort_col/sort_dir) ใช้ร่วม dropdown + คลิกหัวตาราง
    // ────────────────────────────────────────────────────────
    function setSort(col, dir) {
        $('input[name="sort_col"]').val(col);
        $('input[name="sort_dir"]').val(dir);
        syncSortDropdown();
        loadData(page);
    }
    function syncSortDropdown() {
        var col = $('input[name="sort_col"]').val();
        var dir = $('input[name="sort_dir"]').val();
        $('select[name="sort"]').val(col === 'Mdate' ? dir : '');
    }
    function onSortDropdown(val) {
        if (val === '') return;
        setSort('Mdate', val);
    }
    // delegated เพราะ thead อยู่ใน #table-data ที่โหลดใหม่ทุกครั้ง
    $(document).on('click', '#table-data th[data-sort]', function () {
        var col    = String($(this).data('sort'));
        var curCol = $('input[name="sort_col"]').val();
        var curDir = $('input[name="sort_dir"]').val();
        var dir    = (curCol === col) ? (curDir === 'asc' ? 'desc' : 'asc') : 'asc';
        setSort(col, dir);
    });

    // ────────────────────────────────────────────────────────
    //  ตัวช่วยจัดรูปแบบค่า
    // ────────────────────────────────────────────────────────
    function esc(v){ return String(v == null ? '' : v).replace(/"/g, '&quot;'); }

    // 'YYYY-MM-DD hh:mm:ss' → 'DD/MM/YY' (ว่าง = '')
    function fmtDate(v, withYear4){
        if (!v) return '';
        var s = String(v).substring(0, 10).split('-');
        if (s.length !== 3) return String(v);
        var yy = withYear4 ? s[0] : s[0].substring(2);
        return s[2] + '/' + s[1] + '/' + yy;
    }
    // + เวลา (ช่อง "วันที่" บนหัวฟอร์มเดิมโชว์เวลาด้วย)
    function fmtDateTime(v){
        if (!v) return '';
        var t = String(v).substring(11, 16);
        return fmtDate(v) + (t ? ' ' + t : '');
    }
    function fmtNum(v, digits){
        if (v === null || v === undefined || v === '') return '';
        var n = parseFloat(v);
        if (isNaN(n)) return '';
        return n.toLocaleString('en-US', {minimumFractionDigits: digits, maximumFractionDigits: digits});
    }
    // หมายเหตุ: ช่องกรอกตัวเลขแบบใส่คอมมาอัตโนมัติ (class="js-comma") + ตัวช่วย
    // numVal() / commaFmt() / stripCommaFields() อยู่ที่ layout/inc_js.blade.php (ใช้ร่วมทุกหน้า)

    // ตั้งค่าช่องวันที่+เวลา — ไม่ส่งค่ามา = ใช้วันเวลาปัจจุบัน (ค่าเริ่มต้นของใบใหม่)
    function setFpDateTime(id, val){
        var el = document.getElementById(id);
        if (!el) return;
        if (el._flatpickr){
            if (val) el._flatpickr.setDate(String(val).substring(0, 19), false, 'Y-m-d H:i:S');
            else     el._flatpickr.setDate(new Date());
        } else {
            $(el).val(val ? fmtDateTime(val) : '');
        }
    }

    // ค่าเริ่มต้นของช่อง "อนุมัติราคาถึง" = **วันทำการถัดไป** (ข้ามวันอาทิตย์ + วันหยุดใน tb_holiday)
    //
    // ⚠ JS ไม่รู้จักวันหยุด → ค่านี้ต้องมาจาก server เสมอ (PriceApprovalController::defaultValidTo())
    //   - ตอนโหลดหน้า: OrderController::index ส่งมาเป็น $default_valid_to
    //   - ทุกครั้งที่เลือกลูกค้า+เบอร์: data() แนบ default_valid_to มาให้ แล้ว fillApprovalData() อัปเดตค่านี้
    //     (กันค่าค้างเมื่อเปิดฟอร์มทิ้งไว้ข้ามวัน)
    // เดิม (29/08/2569) คำนวณ "พรุ่งนี้" เองใน JS — เลิกใช้แล้ว 01/09/2569
    var APPROVAL_DEFAULT_VALID_TO = @json($default_valid_to ?? null);

    // ป้าย/สี badge ของสถานะอนุมัติ — มาจาก OrderController::APPV_STATUSES (แหล่งเดียวกับตารางรายการ)
    var APPV_STATUSES = @json($appv_statuses ?? []);

    function defaultValidToYmd(){
        if (APPROVAL_DEFAULT_VALID_TO) return APPROVAL_DEFAULT_VALID_TO;

        // สำรองกรณี server ไม่ได้ส่งค่ามา — พรุ่งนี้ตรง ๆ (ไม่ข้ามวันหยุด)
        var d = new Date();
        d.setDate(d.getDate() + 1);
        var p = function(n){ return (n < 10 ? '0' : '') + n; };
        return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
    }

    // วันนี้ (เวลาเครื่องผู้ใช้) รูปแบบ Y-m-d — ใช้เทียบว่าวันยืนราคาเดิมเลยมาแล้วหรือยัง
    function todayYmd(){
        var d = new Date();
        var p = function(n){ return (n < 10 ? '0' : '') + n; };
        return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
    }

    // ตั้งค่าให้ flatpickr (รับ Y-m-d / datetime); ว่าง = เคลียร์

    function setFp(id, val){
        var el = document.getElementById(id);
        if (!el) return;
        if (el._flatpickr) {
            if (val) el._flatpickr.setDate(String(val).substring(0, 10), false, 'Y-m-d');
            else     el._flatpickr.clear();
        } else {
            $(el).val(val ? String(val).substring(0, 10) : '');
        }
    }

    // ────────────────────────────────────────────────────────
    //  ฟอร์มบันทึกใบสั่งซื้อ
    // ────────────────────────────────────────────────────────

    // เปิดใบที่มีอยู่แล้ว — โหลดหัวใบ + รายการ + ข้อมูลราคา แล้วเติมลงฟอร์ม
    function orderOpen(orderno){
        $.getJSON("{{ $page_url }}/form", {orderno: orderno}, function(res){
            if (!res.found){
                // ไม่เจอ → อยู่โหมด idle ต่อ ให้ผู้ใช้พิมพ์เลขใหม่ได้เลย
                Swal.fire('ไม่พบใบสั่งซื้อ', 'เลขที่ ' + orderno + ' ไม่มีอยู่ในระบบ', 'warning')
                    .then(function(){ $('#o_Orderno').trigger('focus').trigger('select'); });
                return;
            }
            fillOrderForm(res);              // fillOrderForm ตั้งโหมดเป็น edit ให้แล้ว
            $('#orderModal').modal('show');
        }).fail(function(){
            Swal.fire('โหลดข้อมูลไม่สำเร็จ', 'ลองใหม่อีกครั้ง', 'error');
        });
    }

    // ────────────────────────────────────────────────────────
    //  โหมดของฟอร์ม
    //   idle = เพิ่งเปิดฟอร์ม — กรอกได้แค่ 2 อย่าง: ประเภทใบสั่ง (radio) กับ เลขที่ใบสั่ง
    //          จากนั้นเลือกทางใดทางหนึ่ง: กด "เพิ่มใบสั่งซื้อใหม่" → โหมด new
    //          หรือพิมพ์เลขที่ใบเดิมแล้วกด Enter → โหมด edit
    //   new / edit = ปลดล็อกทุกช่อง (เลขที่ใบสั่งถูกกำหนดแล้ว จึงล็อกไว้)
    // ────────────────────────────────────────────────────────
    function setOrderFormMode(mode){
        var idle = (mode === 'idle');
        $('#orderModal').attr('data-mode', mode);

        // ล็อกทุกช่อง ยกเว้นตัวที่ต้องใช้ตอน idle (radio ประเภท / เลขที่ใบสั่ง / ปุ่มเพิ่มใบใหม่ / ปุ่มปิด)
        $('#orderModal').find('input, select, textarea, button')
            .not('[name="order_type_form"]')
            .not('#o_Orderno')
            .not('.of-btn-new')
            .not('[data-bs-dismiss="modal"], .btn-close')
            .prop('disabled', idle);

        // เลขที่ใบสั่ง — พิมพ์ได้เฉพาะตอน idle
        $('#o_Orderno').prop('readonly', !idle);
    }

    // เปิดฟอร์มเปล่า (ปุ่มบนหัวหน้ารายการ) — เข้าโหมด idle
    function orderOpenNew(){
        clearOrderForm();
        $('#orderModalTitle').text('บันทึกคำสั่งซื้อ');
        setOrderFormMode('idle');
        $('#orderModal').modal('show');
        setTimeout(function(){ $('#o_Orderno').trigger('focus'); }, 300);
    }

    // กด Enter ที่ช่องเลขที่ใบสั่ง (ตอน idle) → เปิดใบนั้นขึ้นมาแก้ไขทันที
    $(document).on('keydown', '#o_Orderno', function(e){
        if (e.key !== 'Enter' && e.keyCode !== 13) return;
        e.preventDefault();
        if ($(this).prop('readonly')) return;          // ไม่ได้อยู่โหมด idle
        var no = ($(this).val() || '').trim();
        if (!no) return;
        orderOpen(no);
    });

    // ปุ่ม "เพิ่มใบสั่งซื้อใหม่" ในฟอร์ม — จุดเดียวที่เจนเลขที่ใบสั่ง
    function orderNew(){
        var type = $('input[name="order_type_form"]:checked').val();
        if (!type){
            Swal.fire({
                icon: 'warning',
                title: 'ยังไม่ได้เลือกประเภทใบสั่ง',
                text: 'เลือกประเภท (CM / CI / HM / …) ก่อน แล้วกดปุ่มนี้อีกครั้ง'
            });
            return;
        }

        // สร้างใบสั่งซื้อที่ server ทันที (12/09/2569) กันเลขที่ชนกัน
        // แล้วเปิดใบนั้นขึ้นมาในโหมดแก้ไข — แบบเดียวกับตอนกดบันทึกสำเร็จ
        var $btn = $('.of-btn-new').prop('disabled', true);

        $.post("{{ $page_url }}/create", {_token: '{{ csrf_token() }}', type: type})
            .done(function(res){
                if (!res.status){
                    Swal.fire('สร้างใบสั่งซื้อไม่สำเร็จ', res.message || '', 'error');
                    return;
                }
                Swal.fire({icon: 'success', title: res.message, text: 'เลขที่ใบสั่ง ' + res.orderno});
                orderOpen(res.orderno);
                loadData(page);
            })
            .fail(function(xhr){
                var body = xhr.responseJSON || {};
                Swal.fire('สร้างใบสั่งซื้อไม่สำเร็จ', body.message || 'ลองใหม่อีกครั้ง', 'error');
            })
            .always(function(){ $btn.prop('disabled', false); });
    }

    // ── itype: ใบสั่งที่เลขที่ขึ้นต้นด้วย W ต้องมี itype ──
    // ตรงกับด่านฝั่ง server ใน OrderController::save() — ที่นี่แค่บอกผู้ใช้ก่อนกดบันทึก
    // itype เป็นช่องอ่านอย่างเดียว ค่ามาจาก customer.type ⇒ ว่าง = ต้องไปกำหนดประเภทให้ลูกค้าก่อน
    function orderPrefix(){
        var no = ($('#o_Orderno').val() || '').trim();
        if (no) return no.charAt(0).toUpperCase();
        return ($('input[name="order_type_form"]:checked').val() || '').charAt(0).toUpperCase();
    }

    function itypeRequired(){ return orderPrefix() === 'W'; }

    // ── itype = ประเภทสินค้าที่สั่ง (ตัวเลือกจาก config/order.php → itypes) ──
    // ติ๊กเลือกบนฟอร์มได้เลย (01/09/2569 — เดิมซ่อนอยู่ในกล่องที่ต้องกดกางก่อน)
    // เลือกได้ข้อเดียว: ติ๊กข้อใหม่ → ปลดข้อเก่าให้เอง
    // ⚠ ยังไม่มีที่เก็บใน DB → ค่าที่เลือกไม่ได้ถูกส่งไปบันทึก (ดู config/order.php)
    $(document).on('change', '.o-itype-opt', function(){
        if (this.checked) $('.o-itype-opt').not(this).prop('checked', false);
        syncItypeRequired();
    });

    // โชว์ * ข้างป้าย itype + ขึ้นกรอบแดงรอบกลุ่ม checkbox เมื่อจำเป็นแต่ยังไม่ได้ติ๊ก
    function syncItypeRequired(){
        var need  = itypeRequired();
        var empty = !$('.o-itype-opt:checked').length;
        $('#o_itype_req').toggleClass('d-none', !need);
        $('#o_itype_box').toggleClass('is-invalid', need && empty);
    }

    // เปลี่ยนประเภทใบสั่ง — ไม่เจนเลขที่ใหม่ (เจนเฉพาะตอนกดปุ่ม "เพิ่มใบสั่งซื้อใหม่")
    // แต่ล้างเลขที่ที่ค้างอยู่ถ้าไม่ตรงกับประเภทที่เพิ่งเลือก กันเลขที่/ประเภทไม่ตรงกัน
    function onOrderTypeChange(type){
        if ($('#o_Orderno').data('existing')) return;   // ใบเดิม — ไม่แตะเลขที่
        var cur = ($('#o_Orderno').val() || '').trim();
        if (cur && cur.substring(0, 2).toUpperCase() !== type) $('#o_Orderno').val('');
        syncItypeRequired();
    }

    /* Require Document (15/10/2569) — ช่องข้อความกรอกได้เฉพาะตอนติ๊ก
       ใช้ readonly ไม่ใช่ disabled จะได้ไม่ชนกับ setOrderFormMode() ที่คุม disabled ทั้งฟอร์ม
       fromUser = ผู้ใช้กดติ๊กเอง → ติ๊ก = โฟกัสช่องข้อความ · เอาติ๊กออก = ล้างข้อความ */
    function syncReqDoc(fromUser){
        var on = $('#o_ReqDoc').is(':checked');
        var $rem = $('#o_ReqDocRem').prop('readonly', !on).toggleClass('bg-light', !on);
        if (!on && fromUser) $rem.val('');
        if (on && fromUser) $rem.trigger('focus');
    }

    function clearOrderForm(){
        $('#orderModal input[type="text"], #orderModal input[type="number"]').val('');
        $('#orderModal input[type="checkbox"]').prop('checked', false);
        $('#orderModal input[name="order_type_form"]').prop('checked', false);
        syncReqDoc(false);
        $('#o_Company').val('');
        $('#o_DVpoint').html('<option value="">— ไม่ระบุ —</option>');
        $('#o_Orderno').removeData('existing');
        setFp('o_sendend', '');
        setFpDateTime('o_Mdate', null);   // ใบใหม่ = วันเวลาปัจจุบัน (ผู้ใช้แก้ได้)
        $('#o_match_warn').addClass('d-none');
        // ผู้บันทึก = พนักงานที่ล็อกอินอยู่
        $('#o_Emp').val('{{ $current_emp }}');
        setOrderPriceLocked(false);       // ฟอร์มเปล่า = ยังไม่มีใบให้อนุมัติ
        fillOrderStatus(null);            // ล้างสถานะ กันค้างจากใบก่อนหน้า
        renderOrderItems([]);
        syncItypeRequired();
    }

    /**
     * ใบที่อนุมัติแล้ว = ห้ามแก้ "ราคาขาย" (21/09/2569 ตามที่ผู้ใช้สั่ง)
     *
     * ใช้ readonly ไม่ใช่ disabled — ค่ายังถูกส่งไปกับ saveOrder() ตามปกติ และไม่ชนกับ
     * setOrderFormMode() ที่คุม disabled ของทุกช่องในฟอร์ม
     * (ด่านจริงอยู่ฝั่ง server ที่ OrderController::headerPayload — ตรงนี้กันแค่บนจอ)
     */
    function setOrderPriceLocked(locked){
        $('#o_price').prop('readonly', !!locked).toggleClass('bg-light', !!locked);
        $('#o_price_locked').toggleClass('d-none', !locked);
    }

    /**
     * ช่อง "สถานะ" บนฟอร์ม (21/09/2569 ตามที่ผู้ใช้สั่ง)
     *
     * status = key ของ APPV_STATUSES ที่ server คิดมาให้ (นิพจน์เดียวกับคอลัมน์สถานะในตารางรายการ)
     * ฟอร์มเปล่า/ยังไม่เปิดใบ = ขีด — เพื่อไม่ให้ค้างสถานะของใบก่อนหน้า
     */
    function fillOrderStatus(status, appvDT){
        var st = APPV_STATUSES[status];

        // วันเวลาอนุมัติ — โชว์เฉพาะใบที่อนุมัติแล้วและมีค่าจริง (อยู่ใน badge เดียวกัน)
        var dt = (status === 'approved' && appvDT) ? ' เมื่อ ' + fmtDateTime(appvDT) + ' น.' : '';

        // สีเข้มกว่าตารางรายการ (21/09/2569 ตามที่ผู้ใช้สั่ง) — แปลงโทนอ่อน `bg-label-*` ของ
        // APPV_STATUSES เป็นสีทึบ `bg-*` เฉพาะ badge ตัวนี้ (ยังยึด APPV_STATUSES เป็นแหล่งเดียว
        // ไม่ได้ hard-code สี และไม่กระทบคอลัมน์สถานะในตารางที่ยังใช้โทนอ่อนเหมือนเดิม)
        var cls = (st ? st.badge : 'bg-label-secondary').replace('bg-label-', 'bg-');
        if (cls === 'bg-warning') cls += ' text-dark';   // เหลืองทึบ + ตัวอักษรขาว อ่านยาก

        // ไอคอนมาจาก APPV_STATUSES เช่นกัน — เครื่องหมายถูกใช้เฉพาะ "อนุมัติแล้ว"
        // (เดิมใส่ ti-circle-check ให้ทุกสถานะ ทำให้ "รออนุมัติ" ขึ้นเครื่องหมายถูกไปด้วย)
        var icon = (st && st.icon) ? '<i class="ti ' + st.icon + ' me-1"></i>' : '';

        // ⚠ ตั้งคลาสด้วย attr ไม่ใช่ addClass — ไม่งั้นคลาสสีจะสะสมทับกันเมื่อเปิดใบที่สถานะต่างกันติด ๆ กัน
        $('#o_appv_status')
            .attr('class', 'badge ' + cls)
            .html(icon + escHtml((st ? st.label : '—') + dt));
    }

    function fillOrderForm(res){
        clearOrderForm();

        var o = res.order || {};
        $('#orderModalTitle').text('บันทึกคำสั่งซื้อ — ' + (o.Orderno || ''));

        // ประเภท (radio) + เลขที่ใบสั่ง
        if (o.type) $('#o_type_' + o.type).prop('checked', true);
        $('#o_Orderno').val(o.Orderno || '').data('existing', true);
        setFpDateTime('o_Mdate', o.Mdate);

        $('#o_Company').val(o.Company || '');
        $('#o_PO').val(o.PO || '');
        $('#o_Custno').val(o.Custno || '');
        $('#o_Custname').val((res.customer && res.customer.name) || o.Custname || '');
        $('#o_Emp').val(o.Emp || '');
        $('#o_supno').val(o.supno || '');
        $('#o_RsvNo').val(o.RsvNo || '');
        $('#o_netqty').val(commaFmt(o.netqty, 2));

        // itype = ประเภทสินค้าที่สั่ง เก็บที่ morder.itype (12/09/2569)
        if (o.itype) $('#o_itype_' + o.itype).prop('checked', true);

        // สถานที่ส่ง — รายการของลูกค้ารายนี้
        fillDvpoints(res.dvpoints, o.DVpoint);

        // กรณีสั่งทำสต๊อก
        setFp('o_sendend', o.sendend);
        $('#o_SendCust').val(o.SendCust != null ? o.SendCust : '');
        $('#o_HMStore').val(commaFmt(o.HMStore, 2));
        $('#o_sendmth').val(commaFmt(o.sendmth, 2));

        // checkbox (แปลงจาก -1 ของ Access มาแล้วฝั่ง server)
        $('#o_Send').prop('checked', !!o.Send);
        $('#o_RP').prop('checked', !!o.RP);
        $('#o_Spec').prop('checked', !!o.Spec);
        $('#o_Cer').prop('checked', !!o.Cer);
        $('#o_MSDS').prop('checked', !!o.MSDS);
        $('#o_ReqDoc').prop('checked', !!o.ReqDoc);
        $('#o_ReqDocRem').val(o.ReqDocRem || '');
        syncReqDoc(false);

        // สินค้า + ราคา (ราคาขายเป็นค่าที่ผู้ใช้พิมพ์ไว้เอง ไม่ได้มาจากกล่องราคา)
        $('#o_itemno').val(res.itemno || '');
        $('#o_price').val(commaFmt(o.price, 2)).removeData('autofill');
        setOrderPriceLocked(!!o.appv);   // อนุมัติแล้ว = ล็อกช่องราคาขาย
        fillOrderStatus(o.appv_status, o.appvDT);
        fillPriceBox(res.price);

        renderOrderItems(res.items || []);
        syncItypeRequired();        // ใบ W ที่ลูกค้ายังไม่มี itype → ขึ้นกรอบแดงให้เห็นตั้งแต่เปิดใบ
        setOrderFormMode('edit');   // เปิดใบเดิม → ปลดล็อกทุกช่อง (ยกเว้นเลขที่ใบสั่ง)
    }

    function fillDvpoints(list, selected){
        var html = '<option value="">— ไม่ระบุ —</option>';
        (list || []).forEach(function(p){
            html += '<option value="' + esc(p) + '">' + esc(p) + '</option>';
        });
        // ค่าที่บันทึกไว้ไม่อยู่ในรายการของลูกค้า (ข้อมูลเก่า) → เพิ่มเข้าไปเพื่อไม่ให้ค่าหาย
        if (selected && (list || []).indexOf(selected) === -1){
            html += '<option value="' + esc(selected) + '">' + esc(selected) + ' (ไม่อยู่ในรายการ)</option>';
        }
        $('#o_DVpoint').html(html).val(selected || '');
    }

    // ── ปุ่ม "+ เพิ่ม" ข้างช่องสถานที่ส่ง (19/09/2569) ──
    // เขียนลง naddress ของลูกค้ารายนั้น แล้วเติมรายการใหม่ + เลือกอันที่เพิ่งเพิ่มให้เลย
    // ⚠ Swal ที่มีช่องกรอกต้องตั้ง target = #orderModal + heightAuto:false
    //   ไม่งั้น focus trap ของ Bootstrap modal ดึงโฟกัสกลับ พิมพ์ไม่ได้
    function addDvpointPrompt(){
        var target = document.getElementById('orderModal') || 'body';
        var custno = ($('#o_Custno').val() || '').trim();

        if (!custno){
            Swal.fire({
                icon: 'warning', title: 'ยังไม่ได้ระบุลูกค้า',
                text: 'กรอกรหัสลูกค้าก่อน แล้วค่อยเพิ่มสถานที่ส่ง',
                target: target, heightAuto: false
            });
            return;
        }

        Swal.fire({
            title: 'เพิ่มสถานที่ส่ง',
            input: 'text',
            inputLabel: 'สถานที่ส่งใหม่ของลูกค้า ' + custno + ' (สูงสุด 20 ตัวอักษร)',
            inputAttributes: { maxlength: 20, autocomplete: 'off' },
            showCancelButton: true,
            confirmButtonText: 'เพิ่ม',
            cancelButtonText: 'ยกเลิก',
            target: target,
            heightAuto: false,
            inputValidator: function(v){
                if (!(v || '').trim()) return 'กรุณากรอกสถานที่ส่ง';
            }
        }).then(function(r){
            if (!r.isConfirmed) return;

            $.post("{{ $page_url }}/dvpoint", {
                _token:  '{{ csrf_token() }}',
                custno:  custno,
                dvpoint: (r.value || '').trim()
            })
            .done(function(res){
                // fillDvpoints() วาด option ใหม่ด้วย .html() — ตัวช่วยกลาง enhanceSelects เฝ้าดูอยู่แล้ว
                // จึง init ดรอปดาวน์ใหม่ให้เอง (ดูหัวข้อ optionsSig ใน CLAUDE.md)
                fillDvpoints(res.dvpoints, res.dvpoint);
                // เขียนข้อมูลลง naddress แล้ว → โหลดตารางรายการใหม่ตามกติกา (19/09/2569)
                // (คอลัมน์ในตารางยังไม่มีสถานที่ส่ง แต่ทำให้ครบทุกจุดที่เขียนข้อมูล)
                if (!res.existed) loadData(page);
                Swal.fire({
                    icon: res.existed ? 'info' : 'success', title: res.message,
                    toast: true, position: 'top-end', timer: 2000, showConfirmButton: false
                });
            })
            .fail(function(xhr){
                Swal.fire({
                    icon: 'error', title: 'เพิ่มไม่สำเร็จ',
                    text: (xhr.responseJSON && xhr.responseJSON.message) || 'เกิดข้อผิดพลาด กรุณาลองใหม่',
                    target: target, heightAuto: false
                });
            });
        });
    }

    // กล่องราคา — ทุกช่องอ่านอย่างเดียว ยกเว้น "ราคาขาย" ที่ผู้ใช้พิมพ์เอง (ไม่แตะที่นี่)
    function fillPriceBox(p){
        p = p || {};
        // ราคาที่กำหนดไว้ = ราคาจากเมนู "กำหนดราคา" (uprice.PRICE ของลูกค้า + เบอร์นี้) — 08/10/2569
        $('#o_fixed_price').val(fmtNum(p.fixed_price, 2)).attr('title', '');
        // ราคา 1/2/3 โชว์เป็นจำนวนเต็ม (ปัดเศษ) เหมือนฟอร์ม "กำหนดราคา" — 08/10/2569
        $('#o_price2').val(fmtNum(p.price2, 0));
        // "ราคาต้องไม่ต่ำกว่า" = ราคาอนุมัติ (ถ้ายังยืนราคาอยู่) ไม่งั้นราคาช่อง 2
        // ตัวเลขนี้ต้องเป็นตัวเดียวกับที่ checkPriceFloor() ใช้ตอนบันทึก ผู้ใช้จะได้ไม่โดนบล็อกด้วยเลขที่ไม่เห็น
        $('#o_min_price').val(fmtNum(p.min_price, 2))
            .attr('title', p.min_from === 'approved'
                ? 'เทียบกับราคาอนุมัติของลูกค้ารายนี้ (ยังไม่เลยวันยืนราคา)'
                : (p.min_from === 'color_rate'
                    ? 'เทียบกับราคาขั้นต่ำของกลุ่มราคา ' + (p.group || '') + ' (zcolorrate)'
                    : (p.min_from === 'fixed'
                        ? 'เทียบกับราคาที่กำหนดไว้ (เมนู "กำหนดราคา")'
                        : 'เทียบกับราคาช่อง 2')));
        $('#o_price_group').val(p.group || '');   // แสดงแค่ A / B / C
        // ขั้นต่ำ = ค่าของกลุ่มราคานั้นจาก zcolorrate
        $('#o_min_qty').val(fmtNum(p.min_rate, 2));
        $('#o_appv_price').val(fmtNum(p.appv_price, 2));
        $('#o_valid_to').val(fmtDate(p.valid_to));

        /* ราคาขาย: มีราคาอนุมัติ (ขอราคาพิเศษ) ที่ยังไม่เลยวันยืนราคา → เติมให้เลย — 08/10/2569
           เติมเฉพาะตอนช่องยังว่าง/0 หรือค่าปัจจุบันเป็นค่าที่ระบบเติมไว้เอง (data-autofill)
           ⇒ ไม่ทับราคาที่ผู้ใช้พิมพ์ / ราคาที่บันทึกไว้ในใบเดิม · ใบที่อนุมัติแล้ว (readonly) ไม่แตะ
           เปลี่ยนไปเบอร์ที่ไม่มีราคาอนุมัติ → ล้างค่าที่ระบบเติมไว้ กันราคาของเบอร์ก่อนหน้าค้าง */
        var $sell = $('#o_price');
        if (!$sell.prop('readonly')){
            var cur = $sell.val(), auto = $sell.data('autofill');
            var canFill = !numOf(cur) ||(auto !== undefined && cur === auto);
            if (canFill){
                var fill = (p.min_from === 'approved' && p.min_price != null) ? commaFmt(p.min_price, 2) : '';
                if (fill || (auto !== undefined && cur === auto)){
                    $sell.val(fill);
                    fill ? $sell.data('autofill', fill) : $sell.removeData('autofill');
                }
            }
        }

        // ── ข้อความใต้กล่องราคา: บอกที่มาของราคา หรือบอกว่าทำไมคำนวณไม่ได้ ──
        var $note = $('#o_price_note').removeClass('of-price-note-warn');

        if (p.found){
            // เหมือนหน้า "ค้นหาราคาสินค้า": ราคาทุน → เงื่อนไขที่เข้า → สูตร
            var src = [];
            if (p.cost_price != null) src.push('ราคาทุน ' + fmtNum(p.cost_price, 2));
            if (p.rule_label)         src.push(p.rule_label);
            if (p.formula)            src.push(p.formula);
            // เกณฑ์ขั้นต่ำเปลี่ยนไปใช้ราคาอนุมัติ → บอกให้เห็นชัด ไม่งั้นผู้ใช้จะงงว่าทำไมไม่ใช่ราคาช่อง 2
            if (p.min_from === 'approved'){
                src.push('ราคาต้องไม่ต่ำกว่า = ราคาอนุมัติ ' + fmtNum(p.min_price, 2)
                    + (p.valid_to ? ' (ยืนราคาถึง ' + fmtDate(p.valid_to) + ')' : ''));
            }
            $note.text(src.join('  ·  '));
            return;
        }

        $note.addClass('of-price-note-warn').text(p.message || '');
    }

    // ════════════════════════════════════════════════════════
    //  ตารางรายการ (suborder) — ช่องกรอก เพิ่ม/ลบแถวได้
    //  อ่านค่าจาก DOM ตอนบันทึก (ไม่เก็บ model คู่ขนาน กันข้อมูลสองฝั่งไม่ตรงกัน)
    // ════════════════════════════════════════════════════════

    // 1 แถว = 1 suborder — Runno เก็บใน hidden เพื่อให้ฝั่ง server รู้ว่าแถวไหนของเดิม
    /* ── ช่องในตารางรายการโตตามข้อความที่พิมพ์ (auto-grow) ─────────────────────
       input ของ bootstrap เป็น width:100% ของช่องตาราง จึงไม่ยืดตามเนื้อหาเอง
       วิธีแก้: วัดความกว้างข้อความจริงด้วย canvas แล้วตั้ง **min-width** แบบ inline
       (ตั้ง min-width ไม่ใช่ width เพื่อให้ input ยังเต็มความกว้างช่องเหมือนเดิม
        ส่วน <td> จะถูกบังคับให้กว้างอย่างน้อยเท่านั้น ตารางจึงขยายตาม
        — table-layout เป็น auto อยู่แล้ว และตารางอยู่ใน .table-responsive ที่เลื่อนแนวนอนได้) */
    var OI_MIN_W = 80,          // ความกว้างขั้นต่ำตอนช่องว่าง (เท่าค่าเดิมใน CSS)
        OI_MAX_W = 420,         // กันช่องเดียวบานจนตารางอ่านไม่ไหว
        _oiCanvas = null;

    function oiTextWidth(el, text){
        if (!_oiCanvas) _oiCanvas = document.createElement('canvas').getContext('2d');
        var cs = getComputedStyle(el);
        _oiCanvas.font = cs.fontWeight + ' ' + cs.fontSize + ' ' + cs.fontFamily;
        return _oiCanvas.measureText(text).width;
    }

    function oiAutoGrow(el){
        if (!el || !el.classList || !el.classList.contains('oi-input')) return;

        var cs = getComputedStyle(el);
        if (!cs.fontSize || parseFloat(cs.fontSize) === 0) return;   // modal ยังซ่อนอยู่ วัดไม่ได้

        var pad = parseFloat(cs.paddingLeft)     + parseFloat(cs.paddingRight)
                + parseFloat(cs.borderLeftWidth) + parseFloat(cs.borderRightWidth);

        // ใช้ placeholder ตอนช่องว่าง เพื่อไม่ให้ช่องหดจนอ่าน placeholder ไม่ออก
        var text = el.value || el.placeholder || '';
        var w    = oiTextWidth(el, text) + pad + 14;                 // 14 = เผื่อ caret ไม่ให้ตัวอักษรชนขอบ

        el.style.minWidth = Math.min(Math.max(Math.ceil(w), OI_MIN_W), OI_MAX_W) + 'px';
    }

    function oiAutoGrowAll(scope){
        $(scope || '#orderItems').find('.oi-input').each(function(){ oiAutoGrow(this); });
    }

    // input = พิมพ์เอง · change = flatpickr เลือกวันที่ · blur = js-comma จัดรูปแบบตัวเลขใหม่
    $(document).on('input change blur', '#orderItems .oi-input', function(){ oiAutoGrow(this); });

    // ผู้ใช้แก้ชื่อสินค้าเอง → เลิกถือว่าเป็นค่าที่ระบบเติม จะได้ไม่ถูกทับตอนเปลี่ยนรหัสสินค้ารอบหน้า
    $(document).on('input', '#orderItems [data-f="prodname"]', function(){
        $(this).removeAttr('data-autofill');
    });

    // ── ห้ามวางข้อมูลในช่อง "เลขที่ใบส่ง" และ "หมายเหตุ" (19/09/2569 ตามที่ผู้ใช้สั่ง) ──
    // event `paste` ครอบทั้ง Ctrl+V / Cmd+V และคลิกขวา → วาง
    // ⚠ บล็อก `drop` ด้วย ไม่งั้นลากข้อความมาปล่อยใส่ช่องก็ยังเข้าได้ (เลี่ยง paste ได้)
    // ⚠ กันได้แค่ฝั่งจอ — ค่าที่ส่งมาตอนบันทึกยังเป็นอะไรก็ได้ (ยิง POST ตรงไม่ผ่านด่านนี้)
    var OI_NO_PASTE = '#orderItems [data-f="outno"], #orderItems [data-f="Remark"]';

    // ── ห้ามวางข้อมูลในช่องวันที่ทั้ง 4 ช่องของตารางรายการ (12/10/2569 ตามที่ผู้ใช้สั่ง) ──
    // กำหนดที่ลูกค้าต้องการ / กำหนดส่งทบทวน / วันที่ผลิตเสร็จ / วันที่ลูกค้าได้รับ = ทุกช่อง .oi-date
    // บล็อก `drop` คู่กัน (ลากข้อความมาปล่อย = เลี่ยง paste ได้) · พิมพ์เอง / เลือกจากปฏิทิน / ตัด / คัดลอก ยังทำได้
    $(document).on('paste drop', '#orderItems .oi-date', function(e){
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'ช่องนี้ไม่อนุญาตให้วางข้อมูล',
            text:  'กรุณาพิมพ์เอง หรือเลือกจากปฏิทิน',
            toast: true, position: 'top-end', timer: 2000, showConfirmButton: false
        });
    });

    // 08/10/2569: ห้าม "ตัด" (Ctrl+X / คลิกขวา → ตัด) ด้วย ตามที่ผู้ใช้สั่ง
    // ⚠ บล็อก `dragstart` คู่กัน ไม่งั้นลากข้อความออกจากช่อง = ย้ายออกได้เหมือนตัด · "คัดลอก" ยังทำได้
    $(document).on('paste drop cut dragstart', OI_NO_PASTE, function(e){
        e.preventDefault();
        var isCut = (e.type === 'cut' || e.type === 'dragstart');
        Swal.fire({
            icon: 'warning',
            title: isCut ? 'ช่องนี้ไม่อนุญาตให้ตัดข้อมูล' : 'ช่องนี้ไม่อนุญาตให้วางข้อมูล',
            text:  isCut ? 'ลบได้ด้วยการพิมพ์แก้เอง' : 'กรุณาพิมพ์เอง',
            toast: true, position: 'top-end', timer: 2000, showConfirmButton: false
        });
    });

    // ตอน modal ยังซ่อนอยู่วัดความกว้างไม่ได้ — วัดใหม่ตอนเปิด (ทั้งใบเดิมและใบใหม่)
    $(function(){ $('#orderModal').on('shown.bs.modal', function(){ oiAutoGrowAll(); }); });

    function orderItemRow(r){
        r = r || {};
        var td = function(html, cls){ return '<td' + (cls ? ' class="' + cls + '"' : '') + '>' + html + '</td>'; };
        var txt = function(field, val, extra){
            return '<input type="text" class="form-control form-control-sm oi-input" data-f="' + field + '"'
                 + ' value="' + esc(val == null ? '' : val) + '"' + (extra || '') + '>';
        };
        var num = function(field, val){
            return '<input type="text" class="form-control form-control-sm text-end js-comma oi-input" data-f="' + field + '"'
                 + ' inputmode="decimal" autocomplete="off" placeholder="0.00"'
                 + ' value="' + esc(commaFmt(val, 2)) + '" oninput="recalcOrderTotals()">';
        };
        var dat = function(field, val){
            return '<input type="text" class="form-control form-control-sm oi-date oi-input" data-f="' + field + '"'
                 + ' autocomplete="off" placeholder="วว/ดด/ปปปป" value="' + esc(fmtDate(val, true)) + '">';
        };

        return '<tr>'
            + '<input type="hidden" data-f="Runno" value="' + esc(r.Runno || '') + '">'
            + td('<span class="oi-no"></span>', 'text-center text-muted')
            + td(txt('Itemno', r.Itemno, ' maxlength="20" oninput="onItemnoInput(this)"'))
            + td(txt('nold', r.nold, ' list="noldList" maxlength="1"'))
            // suborder.prodname = varchar(20)
            // ชื่อที่โหลดมาจากใบเดิมติด data-autofill ไว้ด้วย → แก้รหัสสินค้าแล้วชื่อเปลี่ยนตาม (15/10/2569)
            // (ผู้ใช้พิมพ์แก้ชื่อเองเมื่อไหร่ data-autofill ถูกลบ ชื่อนั้นจะไม่ถูกทับอีก)
            + td(txt('prodname', r.prodname, ' maxlength="20"'
                + (r.prodname ? ' data-autofill="' + esc(r.prodname) + '"' : '')))
            + td(txt('Lotno', r.Lotno, ' maxlength="20"'))
            + td(num('Stock', r.Stock))
            + td(num('Production', r.Production))
            + td(dat('custwant', r.custwant))
            + td(dat('senddate', r.senddate))
            + td(dat('EndP', r.EndP))
            + td(dat('DVDate', r.DVDate))
            + td(txt('outno', r.outno, ' maxlength="20"'))
            + td(txt('Remark', r.Remark, ' list="ordremList"'))
            + td('<button type="button" class="btn btn-sm btn-icon btn-label-danger" title="ลบแถว"'
                + ' onclick="removeOrderItem(this)"><i class="ti ti-trash"></i></button>', 'text-center')
            + '</tr>';
    }

    function renderOrderItems(items){
        items = (items && items.length) ? items : [{}];   // ใบใหม่เริ่มที่ 1 แถวเปล่า
        $('#orderItems').html(items.map(orderItemRow).join(''));
        initRowPickers('#orderItems');
        renumberOrderItems();
        recalcOrderTotals(false);        // โหลดใบเดิม → คงค่า netqty ที่บันทึกไว้ ไม่คำนวณทับ
        oiAutoGrowAll();                 // ค่าที่โหลดมาจากใบเดิมต้องขยายช่องให้พอดีด้วย
    }

    function addOrderItem(){
        var $tr = $(orderItemRow({}));
        $('#orderItems').append($tr);
        initRowPickers($tr);
        renumberOrderItems();
        oiAutoGrowAll($tr);
    }

    function removeOrderItem(btn){
        $(btn).closest('tr').remove();
        if (!$('#orderItems tr').length) addOrderItem();   // เหลืออย่างน้อย 1 แถวเสมอ
        renumberOrderItems();
        recalcOrderTotals();
        refreshItemContext();   // รหัสที่แถบเตือน/กล่องราคาอ้างอิงอยู่อาจเพิ่งถูกลบไป
    }

    /* เช็คแถบเตือน "ต้อง Match ใหม่" + กล่องราคา ใหม่จากรหัสสินค้าที่ยังเหลืออยู่ในตาราง
       ใช้ตอนที่รหัสอ้างอิงอาจหายไป — กดลบแถว หรือลบข้อความในช่องรหัสจนว่าง
       ไม่งั้นแถบแดงกับกล่องราคาจะค้างเป็นของเบอร์ที่ไม่มีอยู่ในใบแล้ว */
    function refreshItemContext(){
        var el = null;
        $('#orderItems [data-f="Itemno"]').each(function(){
            if (!el && ($(this).val() || '').trim()) el = this;
        });

        // ยังมีรหัสเหลืออยู่ → ดึงข้อมูลของรหัสนั้นมาแสดงแทน (จัดการแถบเตือน + ราคาให้ในตัว)
        if (el){ applyItemLookup(el); return; }

        // ไม่เหลือรหัสสินค้าเลยทั้งใบ → ซ่อนแถบเตือน + ล้างกล่องราคา
        showMatchWarning(null);
        syncItemnoToPrice();
    }

    // flatpickr ของช่องวันที่ในแถว — ต้องผูกทุกครั้งที่สร้างแถวใหม่
    /* ⚠ ช่องวันที่ในตารางรายการใช้ static:false ต่างจากที่อื่นในระบบ (ที่อื่นใช้ static:true)
       เพราะตารางนี้อยู่ใน .table-responsive ซึ่งมี overflow-x:auto — ตามสเปก CSS พอแกนหนึ่ง
       ไม่ใช่ visible อีกแกนที่เป็น visible จะถูกบังคับเป็น auto ด้วย ⇒ ปฏิทินที่ฝังไว้ใน <td>
       (static:true) จะถูก clip เหลือแค่แถบบน. static:false ให้ flatpickr ย้ายปฏิทินไป <body>
       แล้วคำนวณตำแหน่งเอง จึงไม่โดนตัด
       ⚠ ต้องคู่กับ CSS `.flatpickr-calendar { z-index: 1092 }` ด้านบนของไฟล์นี้เสมอ —
         flatpickr.css ของ theme ตั้งไว้แค่ 999 ปฏิทินจะจมใต้ modal (1090) ถ้าไม่ยกขึ้น

       ผลข้างเคียงของการย้ายไป <body>: ปฏิทินไม่เลื่อนตามเวลาผู้ใช้เลื่อนตาราง/modal
       → ปิดปฏิทินให้เองเมื่อมีการเลื่อน จะได้ไม่มีปฏิทินค้างลอยผิดที่ */
    // ที่ที่เลื่อนแล้วทำให้ปฏิทินลอยผิดตำแหน่ง: กล่องเลื่อนแนวนอนของตาราง + ตัว modal เอง
    function rowPickerScrollTargets(){
        return $('#orderItemsTable').closest('.table-responsive').add('#orderModal');
    }

    function initRowPickers(scope){
        $(scope).find('.oi-date').each(function(){
            if (this._flatpickr) return;
            flatpickr(this, {
                dateFormat: 'd/m/Y',
                allowInput: true,
                disableMobile: true,
                onOpen: function (_, __, fp) {
                    fp._closeOnScroll = function(){ fp.close(); };
                    rowPickerScrollTargets().on('scroll.wpfp', fp._closeOnScroll);
                },
                onClose: function (_, __, fp) {
                    if (!fp._closeOnScroll) return;
                    rowPickerScrollTargets().off('scroll.wpfp', fp._closeOnScroll);
                    fp._closeOnScroll = null;
                }
            });
        });
    }

    function renumberOrderItems(){
        $('#orderItems tr').each(function(i){ $(this).find('.oi-no').text(i + 1); });
    }

    /* ยอดรวม S / P ท้ายตาราง + เติม 'น้ำหนักรวม' (morder.netqty) ให้อัตโนมัติ (14/09/2569)
       netqty = ผลรวม S + P ของทุกแถว — ตรงกับข้อมูลจริง 3,218 จาก 3,481 ใบ (92.4%)
       ส่ง syncNet = false ตอนโหลดใบเดิม เพื่อไม่ทับค่า netqty ที่บันทึกไว้ */
    function recalcOrderTotals(syncNet){
        var s = 0, p = 0;
        $('#orderItems tr').each(function(){
            s += numOf($(this).find('[data-f="Stock"]').val());
            p += numOf($(this).find('[data-f="Production"]').val());
        });
        $('#o_total_stock').text(commaFmt(s, 2));
        $('#o_total_prod').text(commaFmt(p, 2));

        if (syncNet === false) return;
        $('#o_netqty').val(commaFmt(s + p, 2));
        refreshOrderPrice();   // กลุ่มราคา / ขั้นต่ำ / ราคาต้องไม่ต่ำกว่า อิงน้ำหนักรวม
    }

    // ── กรอกรหัสสินค้า → เติมชื่อสินค้า + ผูกกล่องราคา + เตือน Match ใหม่ ──
    // ผู้ใช้กรอกรหัสเดียวทั้งใบ → ใช้รหัสของแถวแรกที่กรอกไว้เป็นตัวอ้างอิงของกล่องราคา
    // เก็บตัวจับเวลา debounce ไว้ที่ช่องแต่ละช่อง — เดิมใช้ตัวแปรกลางตัวเดียวร่วมกันทุกแถว
    // ทำให้พิมพ์แถวถัดไปเร็ว ๆ แล้วไป clearTimeout ของแถวก่อนหน้าทิ้ง แถวนั้นเลยไม่ถูกดึงข้อมูล
    function onItemnoInput(el){
        clearTimeout(el._lookupTimer);
        el._lookupTimer = setTimeout(function(){ applyItemLookup(el); }, 350);
    }

    function applyItemLookup(el){
        var $row   = $(el).closest('tr');
        var itemno = ($(el).val() || '').trim();

        // ลบรหัสในช่องนี้จนว่าง → ไปใช้รหัสของแถวอื่นที่ยังเหลือ (ถ้าไม่เหลือเลยแถบเตือนจะถูกซ่อน)
        // ไม่วนซ้ำ เพราะ refreshItemContext() เลือกเฉพาะช่องที่ "มีค่า" เท่านั้น
        if (!itemno){ refreshItemContext(); return; }

        $.getJSON("{{ $page_url }}/item-lookup", {
            itemno: itemno,
            custno: ($('#o_Custno').val() || '').trim(),  // Label ของเบอร์เดียวกันต่างกันได้ตามลูกค้า
            // เช็ค "เกิน 3 ปี" จากใบก่อนหน้า โดยยึดวันที่ของใบนี้ (15/10/2569)
            orderno: ($('#o_Orderno').val() || '').trim(),
            mdate:   $('#o_Mdate').val() || ''
        }, function(res){
            if (($(el).val() || '').trim() !== itemno) return;   // ผู้ใช้พิมพ์ต่อแล้ว

            /* เติมชื่อสินค้าให้ทุกครั้งที่เปลี่ยนรหัสสินค้า — แต่ยังต้องไม่ทับชื่อที่ "ผู้ใช้พิมพ์เอง"
               แยกสองอย่างนี้ด้วย data-autofill: จำชื่อที่ระบบเติมไว้ล่าสุด
                 - ช่องว่าง หรือ ค่าปัจจุบัน = ค่าที่ระบบเติมไว้เอง  → เติมทับได้
                 - ค่าอื่น (ผู้ใช้พิมพ์เอง / ชื่อที่บันทึกไว้ในใบเดิม) → ไม่แตะ
               (เดิมเช็คแค่ `!$name.val()` จึงเติมได้ครั้งเดียว เปลี่ยนรหัสรอบต่อไปชื่อค้างของเก่า) */
            var $name = $row.find('[data-f="prodname"]');
            var cur   = $name.val() || '';
            var auto  = $name.attr('data-autofill');
            // ชื่อที่ได้จาก uprice.Label ยาวเกิน 20 ตัวได้ แต่คอลัมน์รับได้แค่ 20 — ตัดให้พอดี
            if (res.prodname && (cur === '' || (auto !== undefined && cur === auto))){
                var name = String(res.prodname).substring(0, 20);
                $name.val(name).attr('data-autofill', name);
                oiAutoGrow($name[0]);                    // เติมค่าด้วย .val() ไม่ยิง event ต้องสั่งขยายเอง
            }

            // หมายเหตุ — เติมจาก uprice.Label ด้วยกติกา data-autofill ชุดเดียวกับชื่อสินค้า
            // (suborder.Remark เป็น text จึงไม่ต้องตัดความยาว)
            var $rem   = $row.find('[data-f="Remark"]');
            var curRem = $rem.val() || '';
            var autoRem = $rem.attr('data-autofill');
            if (res.remark && (curRem === '' || (autoRem !== undefined && curRem === autoRem))){
                $rem.val(res.remark).attr('data-autofill', res.remark);
                oiAutoGrow($rem[0]);
            }

            showMatchWarning(res);
            syncItemnoToPrice();
        }).fail(syncItemnoToPrice);
    }

    // แถบแดง "สีที่สั่งซื้อล่าสุดเกิน 3 ปี จะต้อง Match ใหม่"
    function showMatchWarning(res){
        if (res && res.need_match){
            $('#o_match_detail').text(res.last_order_date
                ? 'เบอร์ ' + res.itemno + ' — สั่งครั้งล่าสุด ' + fmtDate(res.last_order_date, true)
                : 'เบอร์ ' + res.itemno + ' — ลูกค้ารายนี้ไม่เคยสั่งซื้อ');
            $('#o_match_warn').removeClass('d-none');
        } else {
            $('#o_match_warn').addClass('d-none');
        }
    }

    // รหัสสินค้าในกล่องราคา = รหัสของแถวแรกที่กรอกไว้
    function syncItemnoToPrice(){
        var itemno = '';
        $('#orderItems [data-f="Itemno"]').each(function(){
            if (!itemno && ($(this).val() || '').trim()) itemno = $(this).val().trim();
        });
        $('#o_itemno').val(itemno);
        refreshOrderPrice();
    }

    // ดึงกล่องราคาใหม่ตามคู่ (ลูกค้า, รหัสสินค้า) + น้ำหนักรวม (ใช้หากลุ่มราคา A/B/C)
    var priceXhr = null;
    function refreshOrderPrice(){
        var custno = ($('#o_Custno').val() || '').trim();
        var itemno = ($('#o_itemno').val() || '').trim();
        if (!custno || !itemno){ fillPriceBox({}); return; }

        if (priceXhr) priceXhr.abort();
        priceXhr = $.getJSON("{{ $page_url }}/price-info", {
            custno: custno, itemno: itemno, weight: numVal('#o_netqty')
        }, function(res){ fillPriceBox(res); });
    }

    // ── ค้นลูกค้าจากรหัส (เติมชื่อ + สถานที่ส่ง + ค่าตั้งต้น RP/CER) ──
    var custLookupTimer = null, custLookupXhr = null;
    function lookupOrderCustomer(code){
        code = (code || '').trim();
        clearTimeout(custLookupTimer);
        if (!code){ $('#o_Custname').val(''); fillDvpoints([], ''); refreshItemContext(); return; }
        custLookupTimer = setTimeout(function(){
            if (custLookupXhr) custLookupXhr.abort();
            custLookupXhr = $.getJSON("{{ $page_url }}/customer/" + encodeURIComponent(code), function(res){
                if ($('#o_Custno').val().trim() !== code) return;   // กันผลเก่ามาทับ
                if (!res.found){
                    $('#o_Custname').val('');
                    fillDvpoints([], '');
                    return;
                }
                var c = res.customer;

                // ลูกค้าติด Blacklist → เตือน แล้วล้างรหัสลูกค้าทิ้ง (19/09/2569 ตามที่ผู้ใช้สั่ง)
                // return ก่อนเติมค่าใด ๆ ⇒ ไม่มีข้อมูลของลูกค้ารายนี้หลุดขึ้นฟอร์มเลย
                if (c.is_black){ orderBlacklistBlock(code, c); return; }

                $('#o_Custname').val(c.name || '');
                fillDvpoints(res.dvpoints, '');
                // itype ไม่ได้ผูกกับลูกค้าแล้ว (เป็นประเภทสินค้าที่สั่ง ผู้ใช้เลือกเอง) จึงไม่แตะที่นี่

                // ── ค่าที่ดึงจากข้อมูลลูกค้า ──
                // ทำทุกครั้งที่ "ผู้ใช้เปลี่ยนรหัสลูกค้า" (ฟังก์ชันนี้ถูกเรียกจาก oninput เท่านั้น
                // ไม่ถูกเรียกตอนโหลดใบเดิม ค่าที่บันทึกไว้จึงไม่โดนทับ)
                $('#o_supno').val(c.sale || '');        // รหัสผู้ขายประจำลูกค้า
                $('#o_RP').prop('checked', !!c.RP);
                $('#o_Cer').prop('checked', !!c.CER);
                $('#o_MSDS').prop('checked', !!c.MSDS);
                // ส่งก่อนได้ (Send) / SPEC (Spec) ไม่มีค่าประจำลูกค้าใน customer — ผู้ใช้ติ๊กเอง

                refreshOrderPrice();   // เปลี่ยนลูกค้า → ราคาของคู่ (ลูกค้า, สินค้า) เปลี่ยนตาม
                refreshItemContext();  // แถบ "เกิน 3 ปี" ผูกกับคู่ (ลูกค้า, สินค้า) — 15/10/2569
            });
        }, 350);
    }

    // ล้างทุกช่องที่ถูกเติมจากข้อมูลลูกค้า — ใช้ตอนเจอ Blacklist (19/09/2569)
    // ⚠ ต้องล้างเองทั้งหมด: การ .val('') ที่ช่องรหัสลูกค้าไม่ยิง event `input`
    //   ⇒ lookupOrderCustomer() ไม่ถูกเรียกซ้ำ ช่องอื่นจึงไม่ถูกล้างให้เอง
    function clearOrderCustomerFields(){
        $('#o_Custname').val('');
        fillDvpoints([], '');
        $('#o_supno').val('');
        $('#o_RP').prop('checked', false);
        $('#o_Cer').prop('checked', false);
        $('#o_MSDS').prop('checked', false);
        refreshOrderPrice();     // กล่องราคาผูกกับคู่ (ลูกค้า, สินค้า) — ไม่มีลูกค้าแล้วต้องล้างตาม
        refreshItemContext();    // แถบ "เกิน 3 ปี" ก็ผูกกับลูกค้าเช่นกัน
    }

    // แจ้งเตือนลูกค้าติด Blacklist แล้วล้างรหัสลูกค้าเมื่อกดตกลง
    // ⚠ Swal ต้องตั้ง target = #orderModal + heightAuto:false ไม่งั้นโดน focus trap ของ modal
    function orderBlacklistBlock(code, c){
        var detail = '';
        if ((c.blackrem || '').trim() !== ''){
            detail += '<div class="mt-2">เหตุผล: <strong>' + escHtml(c.blackrem) + '</strong></div>';
        }
        if (c.blackdate){
            detail += '<div class="text-muted small">ขึ้นบัญชีเมื่อ ' + fmtDate(c.blackdate, true) + '</div>';
        }

        Swal.fire({
            icon:  'error',
            title: 'ลูกค้าติด Blacklist',
            html:  'รหัส <strong>' + escHtml(code) + '</strong> — ' + escHtml(c.name || '') + detail
                 + '<div class="mt-3">กรุณากรอกรหัสลูกค้ารายอื่น</div>',
            confirmButtonText: 'ตกลง',
            allowOutsideClick: false,
            target: document.getElementById('orderModal') || 'body',
            heightAuto: false
        }).then(function(){
            $('#o_Custno').val('');
            clearOrderCustomerFields();
            $('#o_Custno').trigger('focus');
        });
    }

    // ════════════════════════════════════════════════════════
    //  บันทึกใบสั่งซื้อ
    // ════════════════════════════════════════════════════════

    // เก็บค่าจากตารางรายการ — ข้ามแถวที่ยังไม่กรอกรหัสสินค้า
    function collectOrderItems(){
        var items = [];
        $('#orderItems tr').each(function(){
            var $tr = $(this), row = {};
            $tr.find('[data-f]').each(function(){
                row[$(this).data('f')] = $(this).val();
            });
            // ช่องตัวเลขมีคอมมา → ถอดออกก่อนส่ง ไม่งั้น '1,000.00' จะลง DB เป็น 1.00
            row.Stock      = numOf(row.Stock);
            row.Production = numOf(row.Production);
            if ((row.Itemno || '').trim() !== '') items.push(row);
        });
        return items;
    }

    function saveOrder(){
        var isEdit = !!$('#o_Orderno').data('existing');
        var type   = $('input[name="order_type_form"]:checked').val() || '';
        var items  = collectOrderItems();

        // ── ตรวจก่อนส่ง ให้ผู้ใช้รู้ปัญหาทันทีโดยไม่ต้องรอ server ──
        if (!isEdit && !type){
            Swal.fire('ยังไม่ได้เลือกประเภทใบสั่ง', 'เลือกประเภทแล้วกด "เพิ่มใบสั่งซื้อใหม่" เพื่อรับเลขที่', 'warning');
            return;
        }
        if (!($('#o_Custno').val() || '').trim()){
            Swal.fire('ยังไม่ได้ระบุลูกค้า', 'กรอกรหัสลูกค้าก่อนบันทึก', 'warning');
            return;
        }
        if (!items.length){
            Swal.fire('ยังไม่มีรายการสินค้า', 'กรอกรหัสสินค้าในตารางอย่างน้อย 1 แถว', 'warning');
            return;
        }
        // ใบที่เลขที่ขึ้นต้นด้วย W ต้องเลือก itype
        // ⚠ ตอนนี้กันได้แค่ฝั่งจอ — ด่านฝั่ง server ใน OrderController::save() ยังคอมเมนต์ไว้
        //   (itype บันทึกลง morder.itype ได้แล้ว 12/09/2569)
        if (itypeRequired() && !$('.o-itype-opt:checked').length){
            syncItypeRequired();
            Swal.fire({
                icon:  'warning',
                title: 'ใบสั่งที่ขึ้นต้นด้วย W ต้องระบุ itype',
                text:  'กดที่ช่อง itype แล้วเลือกประเภทสินค้า 1 ข้อ ก่อนบันทึก'
            });
            return;
        }

        // ติ๊ก Require Document แล้วต้องกรอกข้อความ (15/10/2569)
        if ($('#o_ReqDoc').is(':checked') && !($('#o_ReqDocRem').val() || '').trim()){
            Swal.fire({icon: 'warning', title: 'ยังไม่ได้กรอก Require Document',
                       text: 'ติ๊ก Require Document แล้ว กรุณากรอกเอกสารที่ต้องใช้',
                       target: '#orderModal', heightAuto: false})
                .then(function(){ $('#o_ReqDocRem').trigger('focus'); });
            return;
        }

        // เบอร์ที่สั่งครั้งล่าสุดเกิน 3 ปี (หรือไม่พบประวัติ) → ถามยืนยันอีกชั้นก่อนบันทึก (15/10/2569)
        // ใบ WI / ผลิตที่ CP / ลูกค้าที่กำหนด → ขึ้นฟอร์มตรวจราคาเม็ด CP ก่อน (16/10/2569)
        confirmMatchOver3Years(items, function(){
            if (cpCheckRequired(isEdit, type)) cpCheckOpen(isEdit, type, items);
            else submitOrder(isEdit, type, items);
        });
    }

    // ════════════════════════════════════════════════════════
    //  ฟอร์มตรวจราคาเม็ด CP ก่อนบันทึก (cp_itemprice) — 16/10/2569
    //  markup: order/cp-price-check.blade.php · บันทึกพร้อมใบสั่งซื้อใน OrderController::save()
    // ════════════════════════════════════════════════════════
    var CP_CHECK_CUSTOMERS = @json($cp_check_customers ?? []);
    var cpPending = null;   // {isEdit, type, items} ที่รอบันทึกหลังกดยืนยันในฟอร์มนี้

    function cpCheckRequired(isEdit, type){
        var no     = ($('#o_Orderno').val() || '').trim();
        var prefix = (isEdit && no ? no : type).substring(0, 2).toUpperCase();
        var custno = ($('#o_Custno').val() || '').trim();
        // ลูกค้ารหัสขึ้นต้นด้วย E ไม่ต้องผ่านฟอร์มนี้ — มาก่อนเงื่อนไขอื่นทั้งหมด (16/10/2569 ตามที่ผู้ใช้สั่ง)
        if (custno.charAt(0).toUpperCase() === 'E') return false;
        return prefix === 'WI'
            || ($('#o_Company').val() || '') === 'CP'
            || CP_CHECK_CUSTOMERS.indexOf(custno) !== -1;
    }

    function cpCheckOpen(isEdit, type, items){
        cpPending = {isEdit: isEdit, type: type, items: items};
        var orderno = ($('#o_Orderno').val() || '').trim();
        var itemno  = (items[0].Itemno || '').trim();

        // 3 ช่องบน — ดึงจากฟอร์มใบสั่งซื้อ
        $('#cp_Orderno').val(orderno);
        $('#cp_itemno').val(itemno);
        $('#cp_OrderPrice').val(commaFmt($('#o_price').val(), 2));

        cpFill(null);
        $('#cpCheckDialog').removeClass('d-none');

        // ใบเดิมที่เคยบันทึกไว้แล้ว → เติมค่าเดิมกลับมา
        if (orderno){
            $.getJSON("{{ $page_url }}/cp-price", {orderno: orderno, itemno: itemno})
                .done(function(res){ if (res.found) cpFill(res.row); });
        }
        setTimeout(function(){ $('#cp_Qdate').trigger('focus'); }, 50);
    }

    function cpFill(r){
        r = r || {};
        var fp = document.getElementById('cp_Qdate')._flatpickr;
        if (r.Qdate) fp.setDate(String(r.Qdate).substring(0, 10), false, 'Y-m-d'); else fp.clear();
        $('#cp_wage').val(commaFmt(r.wage, 2));
        $('#cp_Resin1Code').val(r.Resin1Code || '');
        $('#cp_Resin1Price').val(commaFmt(r.Resin1Price, 2));
        $('#cp_Resin1Per').val(commaFmt(r.Resin1Per, 0));
        $('#cp_Resin2Code').val(r.Resin2Code || '');
        $('#cp_Resin2Price').val(commaFmt(r.Resin2Price, 2));
        $('#cp_Resin2Per').val(commaFmt(r.Resin2Per, 0));
        $('input[name="cp_ResinFrom"]').prop('checked', false);
        if (r.ResinFrom) $('#cp_ResinFrom' + r.ResinFrom).prop('checked', true);
        cpRecalc();
        cpQdateWarn();
    }

    // ข้อ 4 = ราคาขาย − ค่าเม็ด × % (ทั้ง 2 เม็ด) · ข้อ 5 = ข้อ 4 − ข้อ 2 — สูตรเดียวกับ saveCpItemPrice()
    function cpRecalc(){
        var price = numVal('#cp_OrderPrice');
        var wage  = numVal('#cp_wage');
        var calc  = price === null ? null
            : price - (numVal('#cp_Resin1Price') || 0) * (numVal('#cp_Resin1Per') || 0) / 100
                    - (numVal('#cp_Resin2Price') || 0) * (numVal('#cp_Resin2Per') || 0) / 100;
        var diff  = (calc === null || wage === null) ? null : calc - wage;
        var pass  = diff !== null && diff >= -0.005;

        $('#cp_wageCal').val(calc === null ? '' : fmtNum(calc, 2));
        $('#cp_Diff').val(diff === null ? '' : fmtNum(diff, 2));
        $('#cp_wageCal_note').text(diff === null ? '' : (pass ? 'สูงกว่า ข้อ 2. / อนุมัติได้' : 'ต่ำกว่า ข้อ 2. / ราคาไม่ผ่าน'))
            .toggleClass('text-primary', pass).toggleClass('text-danger', !pass);
        $('#cp_Diff_note').text(diff === null ? '' : (pass ? '>= 0 บาท / อนุมัติได้' : '< 0 บาท / ราคาไม่ผ่าน'))
            .toggleClass('text-primary', pass).toggleClass('text-danger', !pass);
        $('#cp_status').text(diff === null ? '—' : (pass ? 'อนุมัติได้' : 'ราคาไม่ผ่าน แจ้งปรับลูกค้า'))
            .toggleClass('cp-fail', diff !== null && !pass);
    }

    // ใบเสนอราคาเกิน 90 วัน → ขึ้นข้อความเตือน
    function cpQdateWarn(){
        var d = document.getElementById('cp_Qdate')._flatpickr.selectedDates[0];
        var over = !!d && (new Date() - d) / 86400000 > 90;
        $('#cp_qdate_warn').toggleClass('d-none', !over);
    }

    function cpCheckClose(){
        $('#cpCheckDialog').addClass('d-none');
        cpPending = null;
    }

    function cpCheckConfirm(){
        if (!cpPending) return;
        var p = cpPending;
        var cp = {
            Qdate:       $('#cp_Qdate').val(),
            wage:        numVal('#cp_wage'),
            ResinFrom:   $('input[name="cp_ResinFrom"]:checked').val() || '',
            Resin1Code:  $('#cp_Resin1Code').val(),
            Resin1Price: numVal('#cp_Resin1Price'),
            Resin1Per:   numVal('#cp_Resin1Per'),
            Resin2Code:  $('#cp_Resin2Code').val(),
            Resin2Price: numVal('#cp_Resin2Price'),
            Resin2Per:   numVal('#cp_Resin2Per')
        };
        cpCheckClose();
        submitOrder(p.isEdit, p.type, p.items, cp);
    }

    $(function(){
        flatpickr('#cp_Qdate', { dateFormat: 'd/m/Y', allowInput: true, static: true, disableMobile: true,
                                 onChange: cpQdateWarn, onClose: cpQdateWarn });
        $(document).on('input change blur', '#cpCheckDialog .cp-calc', cpRecalc);
        // Esc ปิดเฉพาะฟอร์มนี้ — ไม่ให้ไหลขึ้นไปปิดฟอร์มใบสั่งซื้อ
        $('#cpCheckDialog').on('keydown', function(e){
            if (e.key === 'Escape'){ e.stopPropagation(); e.preventDefault(); cpCheckClose(); }
        });
        // ปิดฟอร์มใบสั่งซื้อ = ปิดฟอร์มนี้ด้วย
        $('#orderModal').on('hidden.bs.modal', function(e){ if (e.target === this) cpCheckClose(); });
    });

    /* ถามยืนยันเมื่อมีรหัสสินค้าในใบที่สั่งครั้งล่าสุดเกิน 3 ปี — 15/10/2569 ตามที่ผู้ใช้สั่ง
       เช็คใหม่จาก server ทุกรหัส (ไม่อ่านจากแถบแดงบนฟอร์ม ซึ่งอาจยังโหลดไม่เสร็จตอนกดบันทึก)
       ไม่พบประวัติ / เรียก item-lookup ไม่สำเร็จ = ถือว่าเกิน 3 ปีเหมือนกัน */
    function confirmMatchOver3Years(items, proceed){
        var codes = [];
        $.each(items, function(_, it){
            var c = (it.Itemno || '').trim();
            if (c && codes.indexOf(c) === -1) codes.push(c);
        });
        if (!codes.length){ proceed(); return; }

        var custno = ($('#o_Custno').val() || '').trim();
        var lines  = [];
        var calls  = $.map(codes, function(code){
            var d = $.Deferred();
            $.getJSON("{{ $page_url }}/item-lookup", {
                itemno: code, custno: custno,
                orderno: ($('#o_Orderno').val() || '').trim(),
                mdate:   $('#o_Mdate').val() || ''
            })
                .done(function(res){
                    if (!res || res.need_match){
                        lines.push(code + ' — ' + (res && res.last_order_date
                            ? 'สั่งครั้งล่าสุด ' + fmtDate(res.last_order_date, true)
                            : 'ลูกค้ารายนี้ไม่เคยสั่งซื้อ'));
                    }
                })
                .fail(function(){ lines.push(code + ' — ไม่พบประวัติการสั่งซื้อของลูกค้ารายนี้'); })
                .always(function(){ d.resolve(); });
            return d.promise();
        });

        $.when.apply($, calls).then(function(){
            if (!lines.length){ proceed(); return; }
            Swal.fire({
                icon:  'warning',
                title: 'สีที่สั่งซื้อล่าสุดเกิน 3 ปี',
                html:  'จะต้อง Match ใหม่<br>' + $.map(lines, escHtml).join('<br>')
                     + '<br><br>จะดำเนินการบันทึกต่อไหม?',
                showCancelButton:  true,
                confirmButtonText: 'ดำเนินการต่อ',
                cancelButtonText:  'ยกเลิก',
                reverseButtons:    true,
                target:     '#orderModal',
                heightAuto: false
            }).then(function(r){ if (r.isConfirmed) proceed(); });
        });
    }

    function submitOrder(isEdit, type, items, cp){
        // ถอดคอมมาออกจากช่องตัวเลขทั้งฟอร์มก่อนอ่านค่า (น้ำหนักรวม / นน.คลัง / ส่งมอบเดือนละ)
        stripCommaFields('#orderModal');

        var payload = {
            _token:     '{{ csrf_token() }}',
            mode:       isEdit ? 'update' : 'insert',
            order_type: type,
            Orderno:    $('#o_Orderno').val(),
            Mdate:      $('#o_Mdate').val(),
            Company:    $('#o_Company').val(),
            PO:         $('#o_PO').val(),
            Custno:     $('#o_Custno').val(),
            Emp:        $('#o_Emp').val(),
            supno:      $('#o_supno').val(),
            DVpoint:    $('#o_DVpoint').val(),
            RsvNo:      $('#o_RsvNo').val(),
            netqty:     $('#o_netqty').val(),
            price:      $('#o_price').val(),
            sendend:    $('#o_sendend').val(),
            SendCust:   $('#o_SendCust').val(),
            HMStore:    $('#o_HMStore').val(),
            sendmth:    $('#o_sendmth').val(),
            Send:       $('#o_Send').is(':checked')  ? 1 : 0,
            RP:         $('#o_RP').is(':checked')    ? 1 : 0,
            Spec:       $('#o_Spec').is(':checked')  ? 1 : 0,
            Cer:        $('#o_Cer').is(':checked')   ? 1 : 0,
            MSDS:       $('#o_MSDS').is(':checked')  ? 1 : 0,
            ReqDoc:     $('#o_ReqDoc').is(':checked') ? 1 : 0,
            ReqDocRem:  $('#o_ReqDocRem').val(),
            itype:      $('.o-itype-opt:checked').val() || '',
            items:      items
        };
        // ค่าจากฟอร์มตรวจราคาเม็ด CP (16/10/2569) — ส่งเฉพาะใบที่เข้าเงื่อนไข
        if (cp) payload.cp = cp;

        var $btn = $('#btnSaveOrder').prop('disabled', true);

        $.post("{{ $page_url }}/save", payload)
            .done(function(res){
                if (!res.status){
                    Swal.fire('บันทึกไม่สำเร็จ', res.message || '', 'error');
                    return;
                }
                Swal.fire({icon: 'success', title: res.message, text: 'เลขที่ใบสั่ง ' + res.orderno});
                // ใบใหม่ → เปลี่ยนเป็นโหมดแก้ไขของใบที่เพิ่งบันทึก แล้วโหลดค่าจริงกลับมา
                orderOpen(res.orderno);
                loadData(page);
            })
            .fail(function(xhr){
                var body = xhr.responseJSON || {};
                // ติดด่านราคา → เสนอทางไปต่อ (ทำใบขออนุมัติราคาพิเศษ) แทนที่จะบอกแค่ว่าบันทึกไม่ได้
                if (body.price_blocked){ showPriceBlocked(body); return; }
                Swal.fire('บันทึกไม่สำเร็จ', body.message || 'เกิดข้อผิดพลาดในการบันทึก', 'error');
            })
            .always(function(){
                $btn.prop('disabled', false);
                // ใส่คอมมากลับให้ช่องตัวเลขหลังส่งข้อมูลแล้ว
                $('#orderModal .js-comma').trigger('blur');
            });
    }

    // ราคาขายต่ำกว่าราคาช่อง 2 และไม่มีราคาอนุมัติพิเศษรองรับ
    // → พาไปทำใบขออนุมัติราคาพิเศษของคู่ (ลูกค้า, เบอร์) นั้นได้เลย
    function showPriceBlocked(body){
        Swal.fire({
            icon: 'warning',
            title: 'ราคาขายต่ำกว่าเกณฑ์',
            html: esc(body.message || ''),
            showCancelButton: true,
            confirmButtonText: '<i class="ti ti-file-dollar me-1"></i>ขออนุมัติราคาพิเศษ',
            cancelButtonText: 'กลับไปแก้ราคา',
            reverseButtons: true
        }).then(function(r){
            if (!r.isConfirmed) return;
            // ปิดฟอร์มใบสั่งซื้อก่อน แล้วค่อยเปิดฟอร์มขออนุมัติ — modal ซ้อนกันจะปิดยาก
            $('#orderModal').modal('hide');
            approvalOpen(body.custno || '', body.itemno || '');
        });
    }

    // ════════════════════════════════════════════════════════
    //  ฟอร์มอนุมัติใบสั่งซื้อ (morderAPPV)
    //  — เปิดมาเจอ "รายการใบที่รออนุมัติ" ก่อน คลิกใบไหนถึงเข้าฟอร์มอนุมัติใบนั้น (25/08/2569)
    //    ในฟอร์มยังมีตัวเดินระเบียนของ Access เดิม (ระเบียน N จาก M) ไว้ไล่ใบต่อกันได้
    // ════════════════════════════════════════════════════════
    var OA_URL    = "{{ $page_url }}/order-approval";
    var oaQueue   = [];      // รายการใบที่รออนุมัติ
    var oaIndex   = 0;       // ระเบียนที่กำลังแสดง (0-based)
    var oaPrices  = {};      // ราคาอ้างอิงของแต่ละเบอร์ในใบปัจจุบัน
    var oaCurrent = null;    // ระเบียนที่โหลดมาแสดงอยู่ — ใช้ตัดสินว่าปุ่มอนุมัติจะทำอะไร

    // นับคิวรออนุมัติตั้งแต่เปิดหน้า → โชว์เป็น badge บนปุ่ม
    $(function(){ oaLoadQueue(); });

    // โหลดคิว + วาดรายการ + อัปเดต badge (ไม่เปิดใบไหนให้เอง — ผู้ใช้เป็นคนเลือก)
    function oaLoadQueue(){
        return $.getJSON(OA_URL + '/queue', function(res){
            oaQueue = res.rows || [];
            $('#oa_total').text(oaQueue.length);
            $('#oa_queue_count').text(oaQueue.length);
            var $badge = $('#oaQueueBadge');
            if (oaQueue.length) $badge.text(oaQueue.length).removeClass('d-none');
            else                $badge.addClass('d-none');
            oaRenderQueue();
        });
    }

    // ── สลับมุมมอง: รายการ ⇄ ฟอร์มอนุมัติ ──
    function oaShowList(){
        $('#oaListView').removeClass('d-none');
        $('#oaDetailView').addClass('d-none');
    }
    function oaShowDetail(){
        $('#oaListView').addClass('d-none');
        $('#oaDetailView').removeClass('d-none');
    }

    // วาดตารางคิว (กรองด้วยช่องค้นหาฝั่งจอ — คิวไม่ยาวพอที่จะต้องค้นที่ server)
    function oaRenderQueue(){
        var kw = ($('#oa_search').val() || '').trim().toLowerCase();
        var body = '';

        oaQueue.forEach(function(r, i){
            if (kw){
                var hay = [r.Orderno, r.Custno, r.custname, r.Company].join(' ').toLowerCase();
                if (hay.indexOf(kw) === -1) return;
            }
            // escHtml (ไม่ใช่ esc) — ชื่อลูกค้ามาจาก DB ต้อง escape ก่อนยัดลง HTML
            body += '<tr onclick="oaOpenOrder(' + i + ')">'
                 +  '<td class="text-center text-muted">' + (i + 1) + '</td>'
                 +  '<td class="fw-bold text-primary">' + escHtml(r.Orderno || '-') + '</td>'
                 +  '<td>' + (fmtDateTime(r.Mdate) || '-') + '</td>'
                 +  '<td class="text-center">' + escHtml(r.Company || '-') + '</td>'
                 +  '<td>' + escHtml(r.Custno || '-') + '</td>'
                 +  '<td>' + escHtml(r.custname || '-') + '</td>'
                 +  '<td class="text-end">' + (fmtNum(r.price, 2) || '—') + '</td>'
                 +  '<td class="text-center">'
                 +    '<span class="btn btn-sm btn-label-warning border">'
                 +      '<i class="ti ti-gavel me-1"></i>รออนุมัติ</span>'
                 +  '</td>'
                 +  '</tr>';
        });

        if (!body){
            body = '<tr><td colspan="8" class="text-center py-4 text-muted">'
                 + (oaQueue.length ? 'ไม่พบใบสั่งซื้อที่ตรงกับคำค้น' : 'ไม่มีใบสั่งซื้อที่รออนุมัติ')
                 + '</td></tr>';
        }
        $('#oaQueueRows').html(body);
    }

    // คลิกใบในรายการ → เข้าฟอร์มอนุมัติของใบนั้น
    function oaOpenOrder(i){
        oaShowDetail();
        oaGo(i);
    }

    function orderApprovalOpen(){
        $('#orderApprovalModal').modal('show');
        $('#oa_search').val('');
        oaShowList();
        oaLoadQueue();
    }

    // Refresh — อยู่หน้ารายการก็โหลดรายการใหม่, อยู่ในฟอร์มก็โหลดใบที่ค้างอยู่ใหม่ด้วย
    function orderApprovalRefresh(){
        var inDetail = !$('#oaDetailView').hasClass('d-none');
        var at       = (oaCurrent && oaCurrent.Orderno) || null;

        oaLoadQueue().done(function(){
            if (!inDetail) return;

            // ใบเดิมยังอยู่ในคิวไหม — หลุดไปแล้ว (มีคนอนุมัติก่อน) ให้กลับหน้ารายการ
            var i = oaIndexOf(at);
            if (i === -1){ oaShowList(); oaClear(); return; }
            oaGo(i);
        });
    }

    /** ตำแหน่งของใบในคิว (-1 = ไม่อยู่ในคิวแล้ว) */
    function oaIndexOf(orderno){
        if (!orderno) return -1;
        for (var i = 0; i < oaQueue.length; i++){
            if (oaQueue[i].Orderno === orderno) return i;
        }
        return -1;
    }

    // ไปยังระเบียนที่ i (i = -1 หมายถึงท้ายสุด)
    function oaGo(i){
        if (!oaQueue.length){ oaClear(); return; }
        i = parseInt(i, 10);
        if (isNaN(i) || i < 0) i = oaQueue.length - 1;
        if (i > oaQueue.length - 1) i = oaQueue.length - 1;
        oaIndex = i;
        $('#oa_pos').val(i + 1);
        oaLoadRecord(oaQueue[i].Orderno);
    }
    function oaStep(delta){
        if (!oaQueue.length) return;
        var i = oaIndex + delta;
        if (i < 0) i = 0;
        if (i > oaQueue.length - 1) i = oaQueue.length - 1;
        oaGo(i);
    }

    function oaClear(){
        $('#orderApprovalModal input[type="text"]').val('');
        $('#orderApprovalModal input[type="checkbox"]').prop('checked', false);
        $('#oa_pos').val('');
        $('#oaItems').html('<tr><td colspan="7" class="text-center py-3 text-muted">ไม่มีใบสั่งซื้อที่รออนุมัติ</td></tr>');
        $('#oa_appv').prop('disabled', true);
        oaPrices  = {};
        oaCurrent = null;
    }

    function oaLoadRecord(orderno){
        $.getJSON(OA_URL + '/record', {orderno: orderno}, function(res){
            if (!res.found){ oaClear(); return; }
            fillOrderApproval(res);
        });
    }

    function fillOrderApproval(res){
        var o = res.order || {};
        oaCurrent = o;
        $('#oa_Mdate').val(fmtDateTime(o.Mdate));
        $('#oa_Orderno').val(o.Orderno || '');
        $('#oa_Company').val(o.Company || '');
        $('#oa_PO').val(o.PO || '');
        $('#oa_Custno').val(o.Custno || '');
        $('#oa_Custname').val(o.Custname || '');
        $('#oa_Emp').val(o.Emp || '');
        $('#oa_sale').val(o.sale || '');
        $('#oa_HMStore').val(fmtNum(o.HMStore, 2));
        $('#oa_DVpoint').val(o.DVpoint || '');
        $('#oa_SendCust').val(o.SendCust != null ? o.SendCust : '');

        $('#oa_Send').prop('checked', !!o.Send);
        $('#oa_RP').prop('checked', !!o.RP);
        $('#oa_Spec').prop('checked', !!o.Spec);
        $('#oa_Cer').prop('checked', !!o.Cer);

        $('#oa_price').val(fmtNum(o.price, 2));
        $('#oa_appv').prop('checked', !!o.appv)
            // ใบจอง R / ใบสั่งทำสต๊อก ไม่ต้องผ่านการอนุมัติ — ล็อกช่องไว้
            .prop('disabled', res.approvable === false)
            .closest('.form-check')
            .attr('title', res.approvable === false ? 'ใบสั่งนี้ไม่ต้องผ่านการอนุมัติ' : '');
        $('#oa_appvDT').val(o.appvDT ? fmtDateTime(o.appvDT) : '');
        // ท้ายฟอร์มเดิม: "(<เทอม> - <ส่วนลดเงินสด>%)"
        $('#oa_term').val(o.term ? '(' + o.term + ' - ' + (o.cashdisc || 0) + '%)' : '');

        oaPrices = res.prices || {};
        oaRenderItems(res.items || []);
    }

    function oaRenderItems(items){
        if (!items.length){
            $('#oaItems').html('<tr><td colspan="7" class="text-center py-3 text-muted">ไม่มีรายการ</td></tr>');
            oaFillPrice(null);
            return;
        }

        var body = '';
        items.forEach(function(r, i){
            body += '<tr onclick="oaSelectItem(' + i + ', \'' + esc(r.Itemno || '') + '\')">'
                 +  '<td class="text-primary">' + esc(r.Itemno || '-') + '</td>'
                 +  '<td>' + esc(r.prodname || '-') + '</td>'
                 +  '<td class="text-primary">' + esc(r.Lotno || '-') + '</td>'
                 +  '<td class="text-end">' + (fmtNum(r.Stock, 2) || '0.00') + '</td>'
                 +  '<td class="text-end">' + (fmtNum(r.Production, 2) || '0.00') + '</td>'
                 +  '<td class="text-center text-primary">' + (fmtDate(r.senddate) || '-') + '</td>'
                 +  '<td>' + esc(r.Remark || '') + '</td>'
                 +  '</tr>';
        });
        $('#oaItems').html(body);
        oaSelectItem(0, items[0].Itemno);   // เปิดมาเลือกแถวแรกให้เลย
    }

    function oaSelectItem(idx, itemno){
        $('#oaItems tr').removeClass('oa-selected').eq(idx).addClass('oa-selected');
        oaFillPrice(oaPrices[itemno] || null);
    }

    function oaFillPrice(p){
        p = p || {};
        $('#oa_rem1').val(p.rem1 || '');
        $('#oa_rem2').val(p.rem2 || '');
        $('#oa_fixed_price').val(fmtNum(p.fixed_price, 2));
        // ราคา 1/2/3 โชว์เป็นจำนวนเต็ม เหมือนฟอร์ม "กำหนดราคา" — 08/10/2569
        $('#oa_price1').val(fmtNum(p.price1, 0));
        $('#oa_price2').val(fmtNum(p.price2, 0));
        $('#oa_price3').val(fmtNum(p.price3, 0));
        // DB 3-4 / 1-2 Kg. — คำนวณสดจากระบบกำหนดราคา โชว์เป็นจำนวนเต็มเหมือนราคา 1/2/3 (12/10/2569)
        $('#oa_db_3_4').val(fmtNum(p.db_3_4, 0));
        $('#oa_db_1_2').val(fmtNum(p.db_1_2, 0));
        // ราคากลุ่ม A/B/C (zcolorrate) ใต้ราคา 3 ช่อง — ทศนิยม 2 ตำแหน่งเหมือนตาราง "ดูกลุ่มราคา" (12/10/2569)
        // รหัสไม่มีในกลุ่มราคา = ขีด — (ไม่ปล่อยว่าง จะได้รู้ว่าไม่มี ไม่ใช่ยังไม่โหลด)
        var cr = p.color_rate || null;
        ['A', 'B', 'C'].forEach(function(g){
            $('#oa_group_' + g).val(cr ? (fmtNum(cr[g], 2) || '—') : '—');
        });
    }

    // ── ปุ่มอนุมัติ — เขียน morder.appv + morder.appvDT ──
    // ติ๊ก checkbox เองไม่มีผล: กันการติ๊กไว้ก่อน ถามยืนยัน แล้วค่อยโหลดสถานะจริงกลับมา
    function orderApprovalApprove(e){
        e.preventDefault();

        var o = oaCurrent;
        if (!o || !o.Orderno) return;

        // อ่านสถานะจากระเบียนที่โหลดมา ไม่พึ่งค่า checked ตอนคลิก (ขึ้นกับจังหวะ toggle ของเบราว์เซอร์)
        var approve = !o.appv;

        var html = 'เลขที่ใบสั่ง <b>' + esc(o.Orderno) + '</b><br>'
                 + 'ลูกค้า ' + esc(o.Custname || o.Custno || '-') + '<br>'
                 + 'ราคาขายครั้งนี้ <b>' + (fmtNum(o.price, 2) || '—') + '</b>';
        if (approve && (o.price === null || o.price === undefined || o.price === '')){
            html += '<br><span class="text-danger">ใบนี้ยังไม่ได้กรอกราคาขาย</span>';
        }

        Swal.fire({
            icon: approve ? 'question' : 'warning',
            title: approve ? 'อนุมัติใบสั่งซื้อนี้?' : 'ยกเลิกการอนุมัติ?',
            html: html,
            // ต้องกรอก **รหัสพนักงาน** ก่อนถึงจะอนุมัติได้ (16/09/2569 ตามที่ผู้ใช้สั่ง —
            // เดิม 12/09/2569 เป็นรหัสผ่าน) ตรวจที่ server เสมอว่ามีใน `emp` และยังใช้งานอยู่
            // (ดู OrderApprovalController::approveEmpnoError)
            // ต้อง render ใน #orderApprovalModal ไม่งั้น focus trap ของ modal ดึงโฟกัสกลับ พิมพ์ไม่ได้
            target: document.getElementById('orderApprovalModal') || 'body',
            heightAuto: false,
            input: 'text',
            inputLabel: 'รหัสพนักงาน',
            inputAttributes: {autocomplete: 'off', maxlength: 4},
            inputValidator: function(v){ if (!((v || '').trim())) return 'กรอกรหัสพนักงานก่อน'; },
            showCancelButton: true,
            confirmButtonText: approve ? 'อนุมัติ' : 'ยกเลิกการอนุมัติ',
            cancelButtonText: 'ปิด',
            confirmButtonColor: approve ? '#28a745' : '#d33'
        }).then(function(r){
            if (!r.isConfirmed) return;

            $('#oa_appv').prop('disabled', true);
            $.post(OA_URL + '/approve', {
                _token:  '{{ csrf_token() }}',
                orderno: o.Orderno,
                appv:    approve ? 1 : 0,
                empno:   (r.value || '').trim()
            })
                .done(function(res){
                    if (!res.status){ Swal.fire('ทำรายการไม่สำเร็จ', res.message || '', 'error'); return; }
                    Swal.fire({icon: 'success', title: res.message, timer: 1800, showConfirmButton: false});
                    oaAfterApprove();
                })
                .fail(function(xhr){
                    var msg = (xhr.responseJSON && xhr.responseJSON.message) || 'เกิดข้อผิดพลาดในการบันทึก';
                    Swal.fire('ทำรายการไม่สำเร็จ', msg, 'error');
                })
                .always(function(){ $('#oa_appv').prop('disabled', false); });
        });
    }

    // ใบที่เพิ่งอนุมัติจะหลุดจากคิว → โหลดคิวใหม่แล้วกลับไปหน้ารายการ
    // (ผู้ใช้จะได้เห็นว่าเหลือกี่ใบ แล้วเลือกใบถัดไปเอง — ตรงกับ flow "เลือกจากรายการ")
    function oaAfterApprove(){
        oaLoadQueue().done(function(){
            oaClear();
            oaShowList();
        });
        // อนุมัติแล้ว คอลัมน์ "สถานะ" ของใบนั้นในตารางรายการเปลี่ยน → โหลดตารางใหม่ (19/09/2569)
        loadData(page);
    }

    // ════════════════════════════════════════════════════════
    //  ฟอร์มขออนุมัติราคาพิเศษ (MD)
    // ════════════════════════════════════════════════════════
    var APPROVAL_URL = "{{ $page_url }}/price-approval";

    // ── 2 โหมดของฟอร์ม ──────────────────────────────────────────
    //   ขอราคา   = ค่าเริ่มต้น — กรอก/แก้ใบขอราคาได้ แต่ช่องอนุมัติถูกล็อก
    //   อนุมัติ  = กรอกรหัสผ่านแล้วกดปลดล็อกก่อน จึงจะติ๊กอนุมัติได้
    // ⚠ ยังไม่ยืนยันว่ารหัสนี้เป็นของ MD โดยเฉพาะ — บนจอจึงเรียกแค่ "รหัส" ไม่ผูกกับตำแหน่ง
    // ตัวแปรนี้เป็นแค่สถานะฝั่งจอ — ตัวตัดสินจริงอยู่ที่ session ฝั่ง server (save() ตรวจซ้ำเสมอ)
    var apvMdUnlocked = false;

    function setApprovalMdMode(unlocked){
        unlocked = !!unlocked;
        // ล้างรหัสที่พิมพ์ไว้เฉพาะตอนเพิ่งเข้าโหมด — ไม่งั้นจะไปลบรหัสที่ผู้ใช้กำลังพิมพ์อยู่
        if (unlocked && !apvMdUnlocked) $('#a_mdpass').val('');
        apvMdUnlocked = unlocked;

        $('#a_mdLockBox').toggleClass('d-none', unlocked);
        $('#a_mdUnlockedBox').toggleClass('d-none', !unlocked);

        // ช่องที่แตะได้เฉพาะโหมดอนุมัติ
        $('#a_Appv, #a_validto').prop('disabled', !unlocked);
        // "อนุมัติราคาถึง" — ไม่ได้อยู่ในโหมดอนุมัติ = ไม่ให้เห็นเลย (05/10/2569 ตามที่ผู้ใช้สั่ง)
        $('#a_validtoBox').toggleClass('d-none', !unlocked);
        $('#a_Appv').closest('.form-check')
            .attr('title', unlocked ? '' : 'ต้องกรอกรหัสเพื่อเข้าสู่โหมดอนุมัติก่อน');
    }

    function approvalUnlock(){
        var pass = ($('#a_mdpass').val() || '').trim();
        if (!pass){
            Swal.fire('ยังไม่ได้กรอกรหัสผ่าน', 'กรอกรหัสก่อนเข้าสู่โหมดอนุมัติ', 'warning');
            return;
        }
        $.post(APPROVAL_URL + '/unlock', {_token: '{{ csrf_token() }}', md_password: pass})
            .done(function(res){
                if (!res.status){ Swal.fire('เข้าสู่โหมดอนุมัติไม่สำเร็จ', res.message || '', 'error'); return; }
                setApprovalMdMode(true);
                Swal.fire({icon: 'success', title: res.message, timer: 1600, showConfirmButton: false});
            })
            .fail(function(xhr){
                var msg = (xhr.responseJSON && xhr.responseJSON.message) || 'รหัสผ่านไม่ถูกต้อง';
                Swal.fire('เข้าสู่โหมดอนุมัติไม่สำเร็จ', msg, 'error');
                $('#a_mdpass').val('').trigger('focus');
            });
    }

    function approvalLock(){
        $.post(APPROVAL_URL + '/lock', {_token: '{{ csrf_token() }}'})
            .always(function(){ setApprovalMdMode(false); });
    }

    // กด Enter ในช่องรหัสผ่าน = กดปุ่มปลดล็อก
    $(document).on('keydown', '#a_mdpass', function(e){
        if (e.key === 'Enter'){ e.preventDefault(); approvalUnlock(); }
    });

    // ── โหมด "แก้ไข" / "สร้างใหม่" ของใบขอราคา (05/10/2569 ตามที่ผู้ใช้สั่ง) ──────────
    // เดิมปุ่มเดียว "เพิ่ม / บันทึก" ทำทั้งสองอย่าง — เลือกคู่ที่ยังไม่เคยขอ = ขึ้นใบใหม่เงียบ ๆ จึงกำกวม
    //   edit = ค่าเริ่มต้น: ดู/แก้ใบเดิม ปุ่ม = "บันทึกการแก้ไข"
    //          คู่ (ลูกค้า, เบอร์) ที่ยังไม่มีใบ → ช่องกรอก + ปุ่มบันทึกถูกปิด ต้องกด "สร้างราคาพิเศษใหม่" ก่อน
    //   new  = หลังกดปุ่ม "สร้างราคาพิเศษใหม่": ฟอร์มว่าง ปุ่ม = "เพิ่ม"
    //          เลือกคู่ที่มีใบอยู่แล้ว → เด้งกลับเป็น edit เอง (server เก็บ 1 คู่ = 1 ใบ จะแก้ทับใบเดิมอยู่ดี)
    // ⚠ เป็นการคุมฝั่งจอล้วน — PriceApprovalController::save() ยังตัดสินเองว่าแก้ทับหรือขึ้นใบใหม่
    var apvMode = 'edit';
    var apvReq = null;          // ใบขอราคาที่โหลดมาล่าสุด (null = ยังไม่มีใบ)
    var apvAutoNew = false;     // เปิดฟอร์มมาพร้อมคู่ (เช่นจากด่านราคาในใบสั่งซื้อ) — ไม่มีใบ = เข้าโหมดสร้างใหม่ให้เลย

    // ผู้ใช้แก้ช่อง "อนุมัติราคาถึง" เองหรือยัง (05/10/2569) — ส่งไปกับ save เป็น valid_to_changed
    // setFp() ตั้งค่าด้วย triggerChange=false จึงไม่ยิง event นี้ ⇒ ธงขึ้นเฉพาะตอนผู้ใช้เลือก/พิมพ์วันเอง
    // ล้างธงทุกครั้งที่ฟอร์มถูกเติม/ล้างใหม่ (fillApprovalForm / clearApprovalForm)
    var apvValidToTouched = false;
    $(document).on('change', '#a_validto', function(){ apvValidToTouched = true; });

    function setApprovalFormMode(mode){
        apvMode = (mode === 'new') ? 'new' : 'edit';
        var isNew = apvMode === 'new';
        $('#btnApprovalSaveText').text(isNew ? 'เพิ่ม' : 'บันทึกการแก้ไข');
        $('#btnApprovalSaveIcon').attr('class', 'ti me-1 ' + (isNew ? 'ti-plus' : 'ti-device-floppy'));
        $('#btnApprovalNew').prop('disabled', isNew);
        syncApprovalEditable();
        renderApprovalReqState(apvReq);
    }

    // ช่องกรอกของใบขอราคา + ปุ่มบันทึก ใช้ได้เมื่อ: อยู่โหมดสร้างใหม่ หรือ มีใบเดิมให้แก้
    function syncApprovalEditable(){
        var canEdit = apvMode === 'new' || !!(apvReq && apvReq.ReqDate);
        $('#a_price, #a_weight, #a_remark, #a_costup, #btnApprovalSave').prop('disabled', !canEdit);
    }

    // ปุ่ม "สร้างราคาพิเศษใหม่" — ล้างฟอร์มแล้วเข้าโหมดสร้างใหม่ (ออกจากโหมดนี้ = กด Refresh หรือเลือกใบจากตัวเดินระเบียน)
    function approvalNew(){
        clearTimeout(apvCustTimer);
        apvAutoNew = false;
        clearApprovalForm();
        paIndex = -1;
        paRenderNav();
        setApprovalFormMode('new');
        $('#a_ReqDate').val(approvalNowText());   // วันที่ขอราคา = ปัจจุบัน (แสดงผล — server ประทับเวลาจริงตอนบันทึก)
        $('#a_custno').trigger('focus');
    }

    // วันเวลาปัจจุบันในรูปแบบเดียวกับช่อง "วันที่ขอราคา"
    function approvalNowText(){
        var d = new Date();
        var p = function(n){ return (n < 10 ? '0' : '') + n; };
        return fmtDateTime(todayYmd() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':00');
    }

    // ════════════════════════════════════════════════════════
    //  ตัวเดินระเบียน: ใบขอราคาที่ "ยังไม่อนุมัติ" ทั้งหมด (12/09/2569)
    //  เปิดฟอร์มมาเจอใบแรกของคิว แล้วกดลูกศรซ้าย/ขวาไล่ดูใบอื่นได้
    // ════════════════════════════════════════════════════════
    var paQueue = [], paIndex = -1;

    // นับใบที่รออนุมัติตั้งแต่เปิดหน้า → โชว์เป็น badge บนปุ่ม "ขออนุมัติราคาพิเศษ"
    $(function(){ paLoadQueue(); });

    function paLoadQueue(cb){
        return $.getJSON(APPROVAL_URL + '/pending', function(res){
            paQueue = res.rows || [];
            $('#pa_total').text(paQueue.length);

            // ป้ายจำนวนบนปุ่ม "ขออนุมัติราคาพิเศษ" ของหน้ารายการ
            var $badge = $('#paQueueBadge');
            if (paQueue.length) $badge.text(paQueue.length).removeClass('d-none');
            else                $badge.addClass('d-none');

            if (typeof cb === 'function') cb();
            else paRenderNav();
        });
    }

    // ตำแหน่งปัจจุบัน + บอกว่ากำลังดูใบของใคร/เบอร์อะไร
    function paRenderNav(){
        var r = paQueue[paIndex];
        $('#pa_pos').val(r ? paIndex + 1 : '');
        $('#pa_info').text(r
            ? (r.custno || '') + ' · ' + (r.itemno || '') + (r.custname ? ' · ' + r.custname : '')
            : (paQueue.length ? '' : 'ไม่มีใบที่รออนุมัติ'));
    }

    // เปิดใบลำดับที่ i ในคิว (i < 0 หรือเกินท้าย = ใบท้ายสุด)
    function paGo(i){
        if (!paQueue.length){ paIndex = -1; paRenderNav(); return; }
        i = parseInt(i, 10);
        if (isNaN(i) || i < 0)          i = paQueue.length - 1;
        if (i > paQueue.length - 1)     i = paQueue.length - 1;
        paIndex = i;
        paRenderNav();

        // เลือกใบจากคิว = ดู/แก้ใบเดิมเสมอ (ออกจากโหมดสร้างใหม่ถ้าค้างอยู่)
        apvAutoNew = false;
        if (apvMode !== 'edit') setApprovalFormMode('edit');

        // เติมลูกค้า+เบอร์ของใบนั้น แล้วให้ flow เดิมโหลดข้อมูลทั้งฟอร์มต่อ
        var r = paQueue[i];
        $('#a_custno').val(r.custno || '');
        onApprovalCustChange(r.custno || '', r.itemno || '', true);   // true = ใบเดิมจากคิว ไม่ตรวจ Blacklist
    }

    function paStep(delta){
        if (!paQueue.length) return;
        var i = (paIndex < 0 ? 0 : paIndex + delta);
        if (i < 0)                  i = 0;
        if (i > paQueue.length - 1) i = paQueue.length - 1;
        paGo(i);
    }

    // โหลดคิวใหม่แล้วชี้กลับไปที่คู่ที่กำลังดูอยู่
    // (ใบที่เพิ่งอนุมัติจะหลุดจากคิว → ไม่เจอ = ตำแหน่งว่าง แต่ยังดูใบนั้นบนฟอร์มต่อได้)
    function paRefreshQueue(){
        var custno = ($('#a_custno').val() || '').trim();
        var itemno = $('#a_itemno').val() || '';
        paLoadQueue(function(){
            paIndex = -1;
            paQueue.forEach(function(r, i){
                if (r.custno === custno && r.itemno === itemno) paIndex = i;
            });
            paRenderNav();
        });
    }

    // เปิดฟอร์ม — ระบุลูกค้า/เบอร์สินค้ามาด้วยก็ได้ (เช่นเรียกจากใบสั่งซื้อในอนาคต)
    function approvalOpen(custno, itemno){
        clearApprovalForm();
        setApprovalFormMode('edit');    // เปิดมาเป็นโหมดแก้ไขเสมอ — จะเพิ่มใบใหม่ต้องกด "สร้างราคาพิเศษใหม่"
        apvAutoNew = !!custno;
        $('#approvalModal').modal('show');
        // เริ่มที่โหมดขอราคาไว้ก่อน แล้วค่อยถาม server ว่าปลดล็อกค้างไว้จากรอบก่อนหรือเปล่า
        // (ล็อกไว้ระหว่างรอผลดีกว่าปล่อยช่องอนุมัติเปิดค้างชั่วขณะ)
        setApprovalMdMode(false);
        $.getJSON(APPROVAL_URL + '/md-state', function(res){ setApprovalMdMode(res.unlocked); });
        if (custno){
            // เรียกมาพร้อมคู่ (ลูกค้า, เบอร์) เช่นจากด่านราคาในใบสั่งซื้อ → เปิดคู่นั้นเลย
            $('#a_custno').val(custno);
            onApprovalCustChange(custno, itemno);
            paLoadQueue();
        } else {
            // เปิดเปล่า ๆ → แสดงใบที่รออนุมัติใบแรก (ไล่ดูใบอื่นด้วยลูกศรซ้าย/ขวา)
            paLoadQueue(function(){ paQueue.length ? paGo(0) : paRenderNav(); });
        }
    }

    function clearApprovalForm(){
        $('#approvalModal input[type="text"], #approvalModal input[type="number"], #approvalModal input[type="password"]').val('');
        $('#approvalModal textarea').val('');
        $('#approvalModal input[type="checkbox"]').prop('checked', false);
        $('#a_itemno').html('<option value="">— เลือกลูกค้าก่อน —</option>');
        // .val('') ไม่ล้าง .data() — ต้องล้างเอง ไม่งั้นปุ่มลบ/การเช็ค "อนุมัติไปแล้ว" จะอ้างใบก่อนหน้า
        $('#a_ReqDate').data('reqdate', '').data('appv', 0);
        $('#btnApprovalDelete').prop('disabled', true);
        apvReq = null;
        setFp('a_validto', defaultValidToYmd());   // ค่าเริ่มต้น "อนุมัติราคาถึง" = วันทำการถัดไป
        apvValidToTouched = false;
        setApprovalGroupPrices(null, null, null);  // <span> ไม่ถูกล้างด้วย selector input ด้านบน
        highlightPriceGroup();
        syncApprovalEditable();
        renderApprovalReqState(null);
        renderApprovalGrid('ราคาที่ยืนไว้ของเบอร์นี้', ZCUST_COLS, []);
    }

    // แถบบอกขั้นตอนของคู่ (ลูกค้า, เบอร์) — 1 คู่ = 1 ใบที่แก้ได้ (ใบล่าสุด)
    function renderApprovalReqState(r){
        var $box = $('#a_reqState').removeClass('alert-secondary alert-warning alert-success alert-info d-none');

        if (!r || !r.ReqDate){
            if (apvMode === 'new'){
                $box.addClass('alert-info')
                    .html('<i class="ti ti-file-plus me-1"></i><b>สร้างใบขอราคาใหม่</b> — '
                        + 'เลือกลูกค้าและรหัสสินค้า กรอกราคา แล้วกด "เพิ่ม" · ยกเลิกให้กด Refresh');
            } else if ($('#a_itemno').val()){
                $box.addClass('alert-secondary')
                    .html('<i class="ti ti-file-off me-1"></i>ยังไม่มีใบขอราคาของคู่ลูกค้า/เบอร์นี้ — '
                        + 'จะขอราคาให้กดปุ่ม "สร้างราคาพิเศษใหม่" ก่อน');
            } else {
                // ยังไม่ได้เลือกลูกค้า+เบอร์ (โหมดแก้ไข) — ไม่ต้องขึ้นข้อความ ซ่อนแถบไปเลย (05/10/2569 ตามที่ผู้ใช้สั่ง)
                $box.addClass('d-none').html('');
            }
            return;
        }

        var when = esc(fmtDateTime(r.ReqDate));
        if (r.Appv){
            $box.addClass('alert-success')
                .html('<i class="ti ti-circle-check me-1"></i>ใบขอราคาเมื่อ <b>' + when + '</b> — '
                    + '<b>อนุมัติแล้ว</b> · กดบันทึกจะแก้ทับใบเดิม');
        } else {
            $box.addClass('alert-warning')
                .html('<i class="ti ti-clock-hour-4 me-1"></i>ใบขอราคาเมื่อ <b>' + when + '</b> — '
                    + '<b>รออนุมัติ</b> · กดบันทึกจะแก้ทับใบเดิม');
        }
    }

    // เปลี่ยนรหัสลูกค้า → โหลดรายการเบอร์สินค้าของลูกค้ารายนั้น
    var apvCustTimer = null;
    // ลูกค้าติด Blacklist ขอราคาไม่ได้ (05/10/2569) — ยกเว้นใบเดิมที่เปิดจากคิวรออนุมัติ (fromQueue)
    // ซึ่งยังต้องเปิดดู/อนุมัติได้ (แบบเดียวกับใบสั่งซื้อเดิมที่ยังเปิดแก้ได้)
    var apvBlackExempt = false;
    function onApprovalCustChange(code, preselectItem, fromQueue){
        code = (code || '').trim();
        apvBlackExempt = !!fromQueue;
        clearTimeout(apvCustTimer);
        if (!code){
            $('#a_itemno').html('<option value="">— เลือกลูกค้าก่อน —</option>');
            $('#a_custname').val('');
            $('#a_sale').val('');
            return;
        }
        apvCustTimer = setTimeout(function(){
            $.getJSON(APPROVAL_URL + '/items', {custno: code}, function(res){
                if ($('#a_custno').val().trim() !== code) return;   // กันผลเก่ามาทับ
                var html = '<option value="">— เลือกเบอร์สินค้า —</option>';
                (res.items || []).forEach(function(it){
                    html += '<option value="' + esc(it) + '">' + esc(it) + '</option>';
                });
                $('#a_itemno').html(html);
                if (preselectItem) $('#a_itemno').val(preselectItem);
                loadApprovalData();
            });
        }, 350);
    }

    // โหลดข้อมูลของคู่ (ลูกค้า, เบอร์สินค้า) มาเติมฟอร์ม
    function loadApprovalData(){
        var custno = $('#a_custno').val().trim();
        var itemno = $('#a_itemno').val() || '';
        if (!custno) return;

        $.getJSON(APPROVAL_URL + '/data', {custno: custno, itemno: itemno}, function(res){
            if (!res.found){
                $('#a_custname').val('');
                $('#a_sale').val('');
                return;
            }
            var c = res.customer || {};
            if (c.is_black && !apvBlackExempt){ approvalBlacklistBlock(custno, c); return; }
            fillApprovalForm(res);
        });
    }

    // แจ้งเตือนลูกค้าติด Blacklist แล้วล้างฟอร์มเมื่อกดตกลง — แบบเดียวกับ orderBlacklistBlock() (05/10/2569)
    // ⚠ Swal ต้องตั้ง target = #approvalModal + heightAuto:false ไม่งั้นโดน focus trap ของ modal
    function approvalBlacklistBlock(code, c){
        var detail = '';
        if ((c.blackrem || '').trim() !== ''){
            detail += '<div class="mt-2">เหตุผล: <strong>' + escHtml(c.blackrem) + '</strong></div>';
        }
        if (c.blackdate){
            detail += '<div class="text-muted small">ขึ้นบัญชีเมื่อ ' + fmtDate(c.blackdate, true) + '</div>';
        }

        Swal.fire({
            icon:  'error',
            title: 'ลูกค้าติด Blacklist',
            html:  'รหัส <strong>' + escHtml(code) + '</strong> — ' + escHtml(c.name || '') + detail
                 + '<div class="mt-3">ไม่สามารถขอราคาได้ กรุณากรอกรหัสลูกค้ารายอื่น</div>',
            confirmButtonText: 'ตกลง',
            allowOutsideClick: false,
            target: document.getElementById('approvalModal') || 'body',
            heightAuto: false
        }).then(function(){
            // ล้างทั้งฟอร์ม (รวมรหัสลูกค้า + รายการเบอร์) — กันข้อมูลของใบก่อนหน้าค้างคู่กับช่องลูกค้าที่ว่าง
            clearApprovalForm();
            paIndex = -1;       // ฟอร์มไม่ได้ชี้ใบไหนในคิวแล้ว (clearApprovalForm ล้างช่องตำแหน่งไปด้วย)
            paRenderNav();
            $('#a_custno').trigger('focus');
        });
    }

    function fillApprovalForm(res){
        var c = res.customer || {};
        $('#a_custname').val(c.name || '');
        $('#a_sale').val(c.sale || '');

        var req = res.request || {};

        // สลับโหมดให้ตรงกับข้อมูลที่โหลดมา (05/10/2569)
        var hasItem = !!$('#a_itemno').val();
        if (apvMode === 'edit' && !req.ReqDate && apvAutoNew && hasItem){
            // เปิดมาพร้อมคู่ (เช่นจากด่านราคาในใบสั่งซื้อ) และยังไม่มีใบ → เข้าโหมดสร้างใหม่ให้เลย
            apvMode = 'new';
        }
        if (hasItem) apvAutoNew = false;

        // โหมดสร้างใหม่ = ใบใหม่เสมอ ไม่ดึงใบขอราคาเดิมของคู่นี้มาแก้ (08/10/2569 ตามที่ผู้ใช้สั่ง)
        // เดิมคู่ที่เคยขอแล้วจะเด้งกลับเป็นโหมดแก้ไข + เติมข้อมูลใบเก่า ⇒ สร้างใบใหม่ของคู่นั้นไม่ได้เลย
        // ข้อมูลอ้างอิงของคู่ (ราคา 1/2/3 · ราคากลุ่ม · ราคาที่ตกลงไว้ล่าสุด · ตารางล่าง) ยังดึงมาแสดงตามปกติ
        var isNew = apvMode === 'new';
        var r = isNew ? {} : req;
        apvReq = r.ReqDate ? r : null;
        setApprovalFormMode(apvMode);

        // เก็บ ReqDate ของใบเดิมไว้ให้ปุ่มลบใช้ — ไม่มี = ยังไม่เคยขอราคาคู่นี้ (ใบใหม่)
        // เก็บสถานะอนุมัติเดิมไว้ด้วย เพื่อแยก "อนุมัติใหม่" (ต้องอยู่ในโหมด MD) ออกจาก "ใบที่อนุมัติไปแล้ว"
        // โหมดสร้างใหม่: โชว์วันเวลาปัจจุบันเป็นวันที่ขอราคา (08/10/2569 ตามที่ผู้ใช้สั่ง)
        // — แสดงผลอย่างเดียว server ประทับเวลาจริงตอนกด "เพิ่ม" · data('reqdate') ต้องว่างไว้ (= ยังไม่มีใบ)
        $('#a_ReqDate').val(r.ReqDate ? fmtDateTime(r.ReqDate) : (isNew ? approvalNowText() : ''))
            .data('reqdate', r.ReqDate || '')
            .data('appv', r.Appv ? 1 : 0);
        // โหมดสร้างใหม่: ไม่แตะช่องที่ผู้ใช้กรอกเอง — เปลี่ยนลูกค้า/เบอร์แล้วค่าที่พิมพ์ไว้ไม่หาย
        if (!isNew){
            $('#a_price').val(commaFmt(r.price, 2));
            $('#a_weight').val(commaFmt(r.weight, 2));
            $('#a_remark').val(r.remark || '');
            $('#a_costup').prop('checked', !!r.costup);
            $('#a_Appv').prop('checked', !!r.Appv);
        }

        // ราคา 3 ช่อง = ราคาขาย 1/2/3 จากเมนู "กำหนดราคา" — คำนวณสด ๆ จากรหัสสินค้าเสมอ
        // (ค่าที่เคยบันทึกใน appvreq ใช้เป็นค่าสำรองเฉพาะตอนคำนวณไม่ได้ จะได้ไม่โชว์ช่องว่างเปล่า)
        fillApprovalPrices(res.calc, r);

        // ป้ายกลุ่ม A/B/C = ราคาของกลุ่มราคา (zcolorrate) เท่านั้น — รหัสที่ไม่มีในตาราง = ขีด (26/09/2569)
        var cr = res.color_rate || {};
        setApprovalGroupPrices(cr.rate_A, cr.rate_B, cr.rate_C);

        // ลบได้เฉพาะใบที่มีอยู่จริง
        $('#btnApprovalDelete').prop('disabled', !r.ReqDate);

        // ขั้นตอนของคู่นี้ + สถานะโหมดอนุมัติล่าสุดจาก server (session อาจหมดอายุระหว่างเปิดฟอร์มค้างไว้)
        renderApprovalReqState(r);
        setApprovalMdMode(res.md_unlocked);

        // ราคาที่ตกลงไว้ล่าสุด (uprice)
        var u = res.uprice || {};
        $('#a_uprice').val(fmtNum(u.PRICE, 2));
        $('#a_uprice_date').val(fmtDate(u.DATE, true));
        $('#a_uprice_rem1').val(u.REM1 || '');
        $('#a_uprice_rem2').val(u.REM2 || '');

        // "อนุมัติราคาถึง" = วันที่ยืนราคาของเบอร์ที่เลือก (zcustprice.enddate)
        // ยังไม่เคยยืนราคาให้เบอร์นี้ → ค่าเริ่มต้น = วันทำการถัดไป (ตรงกับที่ server เติมให้ถ้าปล่อยว่าง)
        // รับค่าที่ server คำนวณสด ๆ มาทุกครั้ง กันค่าค้างเมื่อเปิดฟอร์มทิ้งไว้ข้ามวัน/ข้ามวันหยุด
        if (res.default_valid_to) APPROVAL_DEFAULT_VALID_TO = res.default_valid_to;
        var first = (res.rows || [])[0];
        var endYmd = (first && first.enddate) ? String(first.enddate).substring(0, 10) : '';
        // ใบที่ "ยังไม่อนุมัติ" แต่วันยืนราคาเดิมของเบอร์นี้เลยมาแล้ว → ใช้ค่าเริ่มต้น (วันทำการถัดไป) แทน (05/10/2569)
        // เดิมโชว์วันเก่าที่หมดอายุค้างไว้ ผู้อนุมัติกดอนุมัติโดยไม่แก้ ⇒ ราคาที่เพิ่งอนุมัติหมดอายุทันที
        // และใช้ปลดล็อกด่านราคาในใบสั่งซื้อไม่ได้ (ข้อมูลจริง: ใบที่อนุมัติช่วง 18/09–05/10/2569 ได้ enddate ย้อนหลังทุกใบ)
        // ใบที่อนุมัติไปแล้วยังโชว์วันที่บันทึกไว้ตามจริง แม้จะเลยมาแล้ว
        if (endYmd && !r.Appv && endYmd < todayYmd()) endYmd = '';
        setFp('a_validto', endYmd || defaultValidToYmd());
        apvValidToTouched = false;

        highlightPriceGroup();
        renderApprovalGrid('ราคาที่ยืนไว้ของเบอร์นี้', ZCUST_COLS, res.rows || []);
    }

    // ราคา 3 ช่อง + DB 3-4 / 1-2 Kg. — มาจากระบบกำหนดราคา (ProductPriceService.lookup)
    //   calc = payload จาก /price-approval/data → key `calc`
    //   req  = ใบขออนุมัติเดิม (ใช้เป็นค่าสำรองเมื่อคำนวณไม่ได้เท่านั้น)
    /* ราคา 1/2/3 โชว์เป็นจำนวนเต็ม (ปัดเศษ) เหมือนฟอร์ม "กำหนดราคา" — 08/10/2569
       ปัดเฉพาะตอนแสดงผล: ค่าจริง (มีทศนิยม) เก็บไว้ที่ data('raw') ให้ approvalSave() ส่งไปบันทึก
       ไม่งั้นสำเนาราคาใน appvreq.price1/2/3 จะกลายเป็นค่าที่ปัดแล้ว */
    function setApvPrice(sel, v){
        $(sel).val(fmtNum(v, 0)).data('raw', (v === null || v === undefined) ? '' : v);
    }
    // ช่องว่าง (ถูกล้างด้วย .val('')) = ไม่มีค่า — ไม่เอา raw ที่ค้างจากใบก่อนหน้า
    function apvPriceRaw(sel){
        var $el = $(sel), raw = $el.data('raw');
        if ($el.val() === '') return '';
        return (raw === undefined || raw === '') ? $el.val() : raw;
    }

    function fillApprovalPrices(calc, req){
        calc = calc || {};
        req  = req  || {};
        var p = calc.prices || null;
        var $note = $('#a_price_note').removeClass('of-price-note-warn');

        if (p){
            setApvPrice('#a_price1', p.price_1);
            setApvPrice('#a_price2', p.price_2);
            setApvPrice('#a_price3', p.price_3);
            $('#a_price_34').val(fmtNum(p.db_3_4, 0));
            $('#a_price_12').val(fmtNum(p.db_1_2, 0));

            /* 19/09/2569: เอาบรรทัดบอกที่มาของราคาออกตามที่ผู้ใช้สั่ง
               (เดิมโชว์ "ราคาทุน … · <เงื่อนไขที่เข้า> · × mul ÷ div + add")
               ⚠ ต้องล้างข้อความด้วย ไม่งั้นค่าของเบอร์ก่อนหน้าค้างบนจอ
               ⚠ อย่าลบ #a_price_note ทิ้ง — ขา else ยังใช้บอกเหตุผลที่คำนวณราคาไม่ได้ */
            $note.text('');
            return;
        }

        // คำนวณไม่ได้ (ไม่มีรหัสในตารางราคาทุน / ไม่มีเงื่อนไขรองรับ) — บอกเหตุผลไว้ ไม่ปล่อยว่างเงียบ ๆ
        setApvPrice('#a_price1', req.price1);
        setApvPrice('#a_price2', req.price2);
        setApvPrice('#a_price3', req.price3);
        $('#a_price_34').val('');
        $('#a_price_12').val('');

        var msg = calc.reason || '';
        if (msg && (req.price1 != null || req.price2 != null || req.price3 != null)){
            msg += ' — แสดงราคาที่บันทึกไว้ในใบเดิมแทน';
        }
        // ยังไม่ได้เลือกรหัสสินค้า = ไม่มีเหตุผลให้บอก ปล่อยว่างไว้ อย่าขึ้นกรอบเตือนเปล่า ๆ
        $note.text(msg);
        if (msg) $note.addClass('of-price-note-warn');
    }

    // ราคาของแต่ละกลุ่มบนป้ายเกณฑ์ A/B/C ใต้ช่องจำนวนสั่งซื้อ (19/09/2569)
    //   A/B/C = zcolorrate.rate_A/B/C ของรหัสสินค้า (26/09/2569 — เดิมใช้ราคาขาย 1/2/3) เรียกจาก fillApprovalForm
    //   ไม่มีค่า (ยังไม่เลือกเบอร์ / รหัสไม่มีในกลุ่มราคา) = ขีด — ไม่ปล่อยว่างให้ป้ายเตี้ยลง
    function setApprovalGroupPrices(p1, p2, p3){
        $('#a_gprice1').text(fmtNum(p1, 2) || '—');
        $('#a_gprice2').text(fmtNum(p2, 2) || '—');
        $('#a_gprice3').text(fmtNum(p3, 2) || '—');
    }

    // เน้นช่องราคาที่ตรงกับจำนวนสั่งซื้อ (A ≥1,000 / B ≥500 / C ต่ำกว่า 500)
    function highlightPriceGroup(){
        var w = numVal('#a_weight');                 // ถอดคอมมาก่อน — '1,000' ต้องได้ 1000 ไม่ใช่ 1
        // เน้นทั้งกล่องราคาและป้ายเกณฑ์กลุ่ม (ป้ายอยู่ใต้ช่องจำนวนสั่งซื้อ)
        $('.pa-pricebox, .pa-gitem').removeClass('pa-active');
        if (w === null) { $('#a_group').val(''); return; }
        var box = (w >= 1000) ? {id: '#a_box1', cap: '#a_glabel1', g: 'A'}
                : (w >= 500)  ? {id: '#a_box2', cap: '#a_glabel2', g: 'B'}
                :               {id: '#a_box3', cap: '#a_glabel3', g: 'C'};
        $(box.id).add(box.cap).addClass('pa-active');
        $('#a_group').val(box.g);
    }

    // ── ตารางล่าง — ใช้ร่วมกันทั้งข้อมูลหลักและผลของปุ่มตรวจสอบ/ประวัติ ──
    var ZCUST_COLS = [
        {key: 'colorno', label: 'รหัสสี'},
        {key: 'exprice', label: 'ราคาขาย', num: 2},
        {key: 'enddate', label: 'ยืนราคาถึงวันที่', date: true},
        {key: 'remark',  label: 'หมายเหตุ', wide: true}
    ];
    var OTHERCUST_COLS = [
        {key: 'custno',   label: 'รหัสลูกค้า'},
        {key: 'custname', label: 'ชื่อลูกค้า'},
        {key: 'exprice',  label: 'ราคาขาย', num: 2},
        {key: 'enddate',  label: 'ยืนราคาถึงวันที่', date: true},
        {key: 'remark',   label: 'หมายเหตุ', wide: true}
    ];
    // ⚠ ไม่ถูกเรียกแล้วตั้งแต่ 12/09/2569 — ปุ่ม "ประวัติของเบอร์นี้" เปลี่ยนไปเปิดรายงาน PDF แทน
    //    (เก็บไว้คู่กับ endpoint JSON `/history` เผื่อกลับมาแสดงในตารางล่างอีก)
    var HISTORY_COLS = [
        {key: 'ReqDate', label: 'วันที่ขอราคา', datetime: true},
        {key: 'weight',  label: 'จำนวนสั่งซื้อ', num: 2},
        {key: 'group',   label: 'กลุ่ม'},
        {key: 'price',   label: 'ราคาขายครั้งนี้', num: 2},
        {key: 'price1',  label: 'ช่อง A', num: 2},
        {key: 'price2',  label: 'ช่อง B', num: 2},
        {key: 'price3',  label: 'ช่อง C', num: 2},
        {key: 'Appv',    label: 'อนุมัติ', bool: true},
        {key: 'remark',  label: 'หมายเหตุ', wide: true}
    ];
    // ⚠ ไม่ถูกเรียกแล้วตั้งแต่ 12/09/2569 — ปุ่ม "ประวัติ ราคาเม็ด CP" เปลี่ยนไปเปิดรายงาน PDF แทน
    var RESIN_COLS = [
        {key: 'Orderno',     label: 'เลขที่ใบสั่ง'},
        {key: 'Qdate',       label: 'วันที่', date: true},
        {key: 'OrderPrice',  label: 'ราคาต่อใบสั่ง', num: 2},
        {key: 'wage',        label: 'ค่าแรง', num: 2},
        {key: 'Resin1Code',  label: 'รหัสเม็ด'},
        {key: 'Resin1Price', label: 'ราคาเม็ด', num: 2},
        {key: 'Resin1Per',   label: '%'},
        {key: 'Diff',        label: 'ส่วนต่าง', num: 2},
        {key: 'status',      label: 'สถานะ'}
    ];

    function renderApprovalGrid(title, cols, rows){
        $('#a_gridTitle').text(title);
        $('#a_gridCount').text(rows.length ? ('ระเบียน ' + rows.length + ' รายการ') : '');

        var head = '<tr>';
        cols.forEach(function(c){
            head += '<th' + (c.wide ? ' style="min-width:320px;"' : '') + '>' + esc(c.label) + '</th>';
        });
        $('#a_gridHead').html(head + '</tr>');

        if (!rows.length){
            $('#a_gridBody').html('<tr><td colspan="' + cols.length + '" class="text-center py-3 text-muted">ไม่มีข้อมูล</td></tr>');
            return;
        }

        var body = '';
        rows.forEach(function(r){
            body += '<tr>';
            cols.forEach(function(c){
                var v = r[c.key], cls = '', txt;
                if (c.num !== undefined)      { txt = fmtNum(v, c.num); cls = ' class="text-end"'; }
                else if (c.datetime)          { txt = fmtDateTime(v);   cls = ' class="text-center"'; }
                else if (c.date)              { txt = fmtDate(v);       cls = ' class="text-center"'; }
                else if (c.bool)              { txt = v ? 'อนุมัติแล้ว' : '-'; cls = ' class="text-center"'; }
                else                          { txt = v == null ? '' : String(v); }
                body += '<td' + cls + '>' + esc(txt || '-') + '</td>';
            });
            body += '</tr>';
        });
        $('#a_gridBody').html(body);
    }

    // ── ปุ่มตรวจสอบ / ประวัติ ──
    // ปุ่ม "ตรวจสอบ เบอร์อื่น ..." → ถามรหัสสินค้าก่อน แล้วเปิดรายงาน PDF ผังเดียวกับ
    // "ประวัติของเบอร์นี้" แต่เป็น **ทุกลูกค้า ทั้งอนุมัติและไม่อนุมัติ** (12/09/2569)
    // เดิมโหลดราคาที่ยืนไว้ (zcustprice) ของลูกค้ารายนี้ลงตารางล่าง — endpoint JSON `/other-items`
    // ยังอยู่ แต่ไม่มีคนเรียกแล้ว
    function approvalOtherItems(){
        Swal.fire({
            title: 'ประวัติการขออนุมัติราคา',
            // ต้อง render ไว้ใน #approvalModal — ไม่งั้น focus trap ของ Bootstrap modal
            // จะดึงโฟกัสกลับ ทำให้พิมพ์ในช่องของ Swal ไม่ได้
            target: document.getElementById('approvalModal') || 'body',
            heightAuto: false,
            input: 'text',
            inputLabel: 'รหัสสินค้า (เบอร์)',
            inputValue: $('#a_itemno').val() || '',
            showCancelButton: true,
            confirmButtonText: 'ดูรายงาน',
            cancelButtonText: 'ยกเลิก',
            inputValidator: function(v){
                if (!(v || '').trim()) return 'กรอกรหัสสินค้าก่อน';
            }
        }).then(function(res){
            if (!res.isConfirmed) return;
            var itemno = (res.value || '').trim();
            if (!itemno) return;
            window.open(APPROVAL_URL + '/other-items-pdf?itemno=' + encodeURIComponent(itemno), '_blank');
        });
    }
    // ปุ่ม "ตรวจสอบเฉพาะร้าน ..." → เปิดรายงาน PDF ผังเดียวกับ "ประวัติของเบอร์นี้"
    // แต่เป็น **ลูกค้ารายที่เปิดอยู่ ทุกเบอร์ ทั้งอนุมัติและไม่อนุมัติ** (12/09/2569)
    // เดิมโหลดลูกค้ารายอื่นที่ใช้เบอร์นี้ (zcustprice) ลงตารางล่าง — endpoint JSON `/other-customers`
    // ยังอยู่ แต่ไม่มีคนเรียกแล้ว
    // 05/10/2569 ตามที่ผู้ใช้สั่ง: เด้งถามรหัสลูกค้าก่อน (ค่าเริ่มต้น = ลูกค้าที่เปิดอยู่บนฟอร์ม) แล้วพิมพ์ของลูกค้ารายนั้น
    // — แบบเดียวกับปุ่ม "ตรวจสอบ เบอร์อื่น ..." ที่ถามรหัสสินค้า · เดิมใช้ลูกค้าบนฟอร์มทันทีโดยไม่ถาม
    function approvalOtherCustomers(){
        Swal.fire({
            title: 'ประวัติการขออนุมัติราคา',
            // ต้อง render ไว้ใน #approvalModal — ไม่งั้น focus trap ของ Bootstrap modal
            // จะดึงโฟกัสกลับ ทำให้พิมพ์ในช่องของ Swal ไม่ได้
            target: document.getElementById('approvalModal') || 'body',
            heightAuto: false,
            input: 'text',
            inputLabel: 'รหัสลูกค้า',
            inputValue: ($('#a_custno').val() || '').trim(),
            showCancelButton: true,
            confirmButtonText: 'ดูรายงาน',
            cancelButtonText: 'ยกเลิก',
            inputValidator: function(v){
                if (!(v || '').trim()) return 'กรอกรหัสลูกค้าก่อน';
            }
        }).then(function(res){
            if (!res.isConfirmed) return;
            var custno = (res.value || '').trim();
            if (!custno) return;
            window.open(APPROVAL_URL + '/customer-history-pdf?custno=' + encodeURIComponent(custno), '_blank');
        });
    }
    // ปุ่ม "ประวัติของเบอร์นี้" → เปิดรายงาน PDF ตามผังรายงานกระดาษเดิม (12/09/2569)
    // เดิมโหลดผลลงตารางล่างในฟอร์ม — endpoint JSON `/history` + HISTORY_COLS ยังอยู่ แต่ไม่มีคนเรียกแล้ว
    function approvalHistory(){
        var custno = $('#a_custno').val().trim();
        var itemno = $('#a_itemno').val() || '';
        if (!custno || !itemno){
            Swal.fire('ยังไม่ได้เลือกลูกค้า/เบอร์สินค้า', 'เลือกลูกค้าและรหัสสินค้าก่อนดูประวัติ', 'warning');
            return;
        }
        window.open(APPROVAL_URL + '/history-pdf?custno=' + encodeURIComponent(custno)
            + '&itemno=' + encodeURIComponent(itemno), '_blank');
    }
    // ปุ่ม "ประวัติ ราคาเม็ด CP" → เปิดรายงาน PDF ของเบอร์นี้ ทุกลูกค้า (12/09/2569)
    // เดิมโหลดผลลงตารางล่างในฟอร์ม — endpoint JSON `/resin-history` + RESIN_COLS ยังอยู่ แต่ไม่มีคนเรียกแล้ว
    function approvalResinHistory(){
        var itemno = $('#a_itemno').val() || '';
        if (!itemno){
            Swal.fire('ยังไม่ได้เลือกเบอร์สินค้า', 'เลือกรหัสสินค้าก่อนดูประวัติราคาเม็ด CP', 'warning');
            return;
        }
        window.open(APPROVAL_URL + '/resin-history-pdf?itemno=' + encodeURIComponent(itemno), '_blank');
    }
    // ── ม่านโหลดข้อมูลของฟอร์มขออนุมัติราคา (12/09/2569) ──
    // ปิดม่านเมื่อ ajax ของหน้าเงียบจริง ๆ — ต้องเงียบติดกัน 2 รอบ (~600ms) เพราะ
    // onApprovalCustChange หน่วง 350ms ก่อนยิง /items ⇒ ถ้าดูรอบเดียวจะเห็นว่า "ว่าง"
    // ทั้งที่ยังไม่เริ่มโหลด แล้วม่านจะหายก่อนข้อมูลมา · มีเพดานเวลากันม่านค้างถ้า ajax พัง
    var apvIdleTimer = null, apvIdleHits = 0, apvIdleDeadline = 0;

    function apvOverlay(on){ $('#approvalLoading').toggleClass('d-none', !on); }

    // ปิด modal ระหว่างโหลด = ไม่ต้องรอต่อ (กันม่านค้างไว้รอบหน้า)
    $(document).on('hidden.bs.modal', '#approvalModal', function(){
        clearTimeout(apvIdleTimer);
        apvOverlay(false);
    });

    function apvWaitIdle(){
        clearTimeout(apvIdleTimer);
        apvIdleTimer = setTimeout(function(){
            apvIdleHits = ($.active > 0) ? 0 : apvIdleHits + 1;
            if (apvIdleHits >= 2 || Date.now() > apvIdleDeadline){ apvOverlay(false); return; }
            apvWaitIdle();
        }, 300);
    }
    // ปุ่ม "Refresh" = เหมือนปิดแล้วกดเปิดฟอร์มใหม่ (ผู้ใช้สั่ง 12/09/2569 — เดิมแค่โหลดข้อมูล
    // ของคู่ ลูกค้า+เบอร์ ที่ค้างอยู่ใหม่): ล้างฟอร์ม + ถามสถานะโหมดอนุมัติจาก server ใหม่
    // + โหลดคิวใบที่รออนุมัติแล้วเด้งเข้าใบแรก · `modal('show')` กับ modal ที่เปิดอยู่แล้ว = no-op
    function approvalRefresh(){
        apvOverlay(true);
        apvIdleHits = 0;
        apvIdleDeadline = Date.now() + 20000;   // เพดาน 20 วิ กันม่านค้าง
        apvWaitIdle();
        approvalOpen();
    }

    // ── เพิ่ม / บันทึกใบขออนุมัติราคา ──
    function approvalSave(){
        var custno = ($('#a_custno').val() || '').trim();
        var itemno = $('#a_itemno').val() || '';

        if (!custno){ Swal.fire('ยังไม่ได้ระบุลูกค้า', 'กรอกรหัสลูกค้าก่อนบันทึก', 'warning'); return; }
        if (!itemno){ Swal.fire('ยังไม่ได้เลือกรหัสสินค้า', 'เลือกเบอร์สินค้าก่อนบันทึก', 'warning'); return; }

        stripCommaFields('#approvalModal');
        var approve = $('#a_Appv').is(':checked');
        var wasApproved = !!($('#a_ReqDate').data('appv'));   // ใบนี้อนุมัติไปแล้วก่อนหน้านี้

        // ติ๊กอนุมัติใหม่ = ต้องอยู่ในโหมดอนุมัติก่อน (ใบที่อนุมัติไปแล้ว MK แก้ต่อได้)
        if (approve && !wasApproved && !apvMdUnlocked){
            Swal.fire('ยังไม่ได้เข้าสู่โหมดอนุมัติ',
                'กรอกรหัสด้านบนแล้วกด "เข้าสู่โหมดอนุมัติ" ก่อนอนุมัติราคา', 'warning');
            $('#approvalModal .js-comma').trigger('blur');
            return;
        }

        // "อนุมัติราคาถึง" ห้ามน้อยกว่า "วันที่ขอราคา" (05/10/2569 ตามที่ผู้ใช้สั่ง) — server ตรวจซ้ำใน save()
        // ตรวจเฉพาะรอบที่วันที่จะถูกบันทึกจริง: อยู่ในโหมดอนุมัติ และ (ติ๊กอนุมัติ หรือ แก้ช่องวันที่เอง)
        // ใบใหม่ยังไม่มีวันที่ขอราคา → เทียบกับวันนี้ (server จะใช้เวลาปัจจุบันเป็นวันที่ขอ)
        if (apvMdUnlocked && (approve || apvValidToTouched)){
            var vm = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(($('#a_validto').val() || '').trim());
            var validYmd = vm ? vm[3] + '-' + ('0' + vm[2]).slice(-2) + '-' + ('0' + vm[1]).slice(-2) : '';
            var reqYmd = String($('#a_ReqDate').data('reqdate') || '').substring(0, 10) || todayYmd();
            if (validYmd && validYmd < reqYmd){
                Swal.fire('วันที่ไม่ถูกต้อง',
                    '"อนุมัติราคาถึง" ต้องไม่น้อยกว่าวันที่ขอราคา (' + fmtDate(reqYmd, true) + ')', 'warning');
                $('#approvalModal .js-comma').trigger('blur');
                return;
            }
        }

        var payload = {
            _token:      '{{ csrf_token() }}',
            custno:      custno,
            itemno:      itemno,
            price:       $('#a_price').val(),
            weight:      $('#a_weight').val(),
            // ส่งค่าจริง (มีทศนิยม) ไม่ใช่ค่าที่ปัดเป็นจำนวนเต็มบนจอ — ดู setApvPrice()
            price1:      apvPriceRaw('#a_price1'),
            price2:      apvPriceRaw('#a_price2'),
            price3:      apvPriceRaw('#a_price3'),
            remark:      $('#a_remark').val(),
            costup:      $('#a_costup').is(':checked') ? 1 : 0,
            Appv:        approve ? 1 : 0,
            valid_to:    $('#a_validto').val(),
            // ผู้ใช้แตะช่อง "อนุมัติราคาถึง" เองไหม — server ใช้ตัดสินว่าจะเก็บวันที่ของใบที่ยังไม่อนุมัติหรือไม่
            valid_to_changed: apvValidToTouched ? 1 : 0,
            // โหมดสร้างใหม่ = ขึ้นใบใหม่เสมอ แม้คู่นี้เคยขอราคาแล้ว (08/10/2569)
            'new':       apvMode === 'new' ? 1 : 0
        };
        // หมายเหตุ: ไม่ต้องส่ง ReqDate — server หาใบล่าสุดของคู่นี้เอง (มี = แก้ทับ, ไม่มี = ใบใหม่)
        // ยกเว้นส่ง new=1 มา = ไม่หาใบเดิม ขึ้นใบใหม่ด้วยเวลาปัจจุบัน

        var $btn = $('#btnApprovalSave').prop('disabled', true);

        $.post(APPROVAL_URL + '/save', payload)
            .done(function(res){
                if (!res.status){ Swal.fire('บันทึกไม่สำเร็จ', res.message || '', 'error'); return; }
                Swal.fire({icon: 'success', title: res.message});
                // เพิ่มใบใหม่สำเร็จ = จากนี้คือการแก้ใบนั้น (ตั้งก่อนโหลด ไม่งั้นจะขึ้นเตือน "มีใบอยู่แล้ว")
                if (apvMode === 'new') setApprovalFormMode('edit');
                loadApprovalData();     // โหลดค่าที่บันทึกจริงกลับมา
                paRefreshQueue();       // อนุมัติแล้วใบจะหลุดจากคิว → นับใหม่
                loadData(page);         // โหลดตารางรายการใหม่ทุกครั้งที่บันทึก (19/09/2569)
            })
            .fail(function(xhr){
                var body = xhr.responseJSON || {};
                // โหมดอนุมัติหมดอายุระหว่างกรอก — ล็อกจอกลับให้ตรงกับ server แล้วให้กรอกรหัสใหม่
                if (body.md_locked) setApprovalMdMode(false);
                Swal.fire('บันทึกไม่สำเร็จ', body.message || 'เกิดข้อผิดพลาดในการบันทึก', 'error');
            })
            .always(function(){
                $btn.prop('disabled', false);
                syncApprovalEditable();                          // คืนสถานะปุ่มตามโหมด/ใบที่เปิดอยู่
                $('#approvalModal .js-comma').trigger('blur');   // ใส่คอมมากลับ
            });
    }

    // ── ลบใบขออนุมัติราคาใบที่กำลังดูอยู่ ──
    function approvalDelete(){
        var reqdate = $('#a_ReqDate').data('reqdate') || '';
        if (!reqdate){ Swal.fire('ไม่มีใบให้ลบ', 'คู่ลูกค้า/เบอร์นี้ยังไม่เคยมีใบขออนุมัติราคา', 'info'); return; }

        Swal.fire({
            icon: 'warning',
            title: 'ลบใบขออนุมัติราคา?',
            html: 'วันที่ขอราคา ' + fmtDateTime(reqdate) + '<br>ราคาที่ยืนไว้ (ตารางล่าง) จะไม่ถูกลบ',
            showCancelButton: true,
            confirmButtonText: 'ลบ',
            cancelButtonText: 'ยกเลิก',
            confirmButtonColor: '#d33'
        }).then(function(r){
            if (!r.isConfirmed) return;
            $.post(APPROVAL_URL + '/delete', {
                _token:  '{{ csrf_token() }}',
                custno:  ($('#a_custno').val() || '').trim(),
                itemno:  $('#a_itemno').val() || '',
                ReqDate: reqdate
            }).done(function(res){
                if (!res.status){ Swal.fire('ลบไม่สำเร็จ', res.message || '', 'error'); return; }
                Swal.fire({icon: 'success', title: res.message});
                loadApprovalData();
                paRefreshQueue();       // ใบถูกลบ → หลุดจากคิว
                loadData(page);         // โหลดตารางรายการใหม่ทุกครั้งที่มีการเขียนข้อมูล (19/09/2569)
            }).fail(function(xhr){
                var msg = (xhr.responseJSON && xhr.responseJSON.message) || 'เกิดข้อผิดพลาดในการลบ';
                Swal.fire('ลบไม่สำเร็จ', msg, 'error');
            });
        });
    }

    // พิมพ์ — รายการที่อนุมัติราคาแล้วใน 3 วันล่าสุด ตามผังกระดาษเดิม (12/09/2569)
    // เดิมเป็น window.print() เพราะยังไม่มีแบบฟอร์มให้อ้างอิง
    // ────────────────────────────────────────────────────────
    //  รายงานผลิตภัณฑ์ที่ต้องผลิต (07/10/2569) — หน้าต่างเลือกเงื่อนไขก่อนพิมพ์
    //  ค่าเริ่มต้น: วันนี้ · 08:00–18:00 · P  (ช่องเวลาใช้ flatpickr 24 ชม. ตามข้อตกลงของระบบ)
    // ────────────────────────────────────────────────────────
    var prFp = null;
    function prodReportInit(){
        if (prFp) return;
        var timeOpt = {
            enableTime: true, noCalendar: true, time_24hr: true, dateFormat: 'H:i',
            allowInput: true, static: true, disableMobile: true,
            plugins: (typeof scrollPlugin === 'function') ? [scrollPlugin()] : []
        };
        prFp = {
            date: flatpickr('#pr_date', { dateFormat: 'd/m/Y', allowInput: true, static: true, disableMobile: true }),
            from: flatpickr('#pr_time_from', timeOpt),
            to:   flatpickr('#pr_time_to', timeOpt)
        };
    }
    function prodReportOpen(){
        prodReportInit();
        prFp.date.setDate(new Date(), false);
        prFp.from.setDate('08:00', false);
        prFp.to.setDate('18:00', false);
        $('#pr_type_p').prop('checked', true);
        $('#prodReportModal').modal('show');
    }
    function prodReportPrint(){
        var q = {
            dept:      $('#pr_dept').val() || '',
            date:      $('#pr_date').val() || '',
            time_from: $('#pr_time_from').val() || '',
            time_to:   $('#pr_time_to').val() || '',
            type:      $('input[name="pr_type"]:checked').val() || 'P'
        };
        if (!q.date) { Swal.fire({ icon: 'warning', title: 'กรุณาเลือกวันที่' }); return; }
        if (q.time_from && q.time_to && q.time_from > q.time_to) {
            Swal.fire({ icon: 'warning', title: 'ช่วงเวลาไม่ถูกต้อง', text: 'เวลาเริ่มต้องไม่มากกว่าเวลาสิ้นสุด' });
            return;
        }
        window.open('{{ url('order/order-approval/approved-today-pdf') }}?' + $.param(q), '_blank');
    }

    function approvalPrint(){
        window.open(APPROVAL_URL + '/approved-pdf', '_blank');
    }

    // ────────────────────────────────────────────────────────
    //  ประมาณการยอดขาย ตามรหัสพนักงานขาย (15/10/2569) — ฟอร์ม Access "SaleOrder"
    //  ค่าเริ่มต้น: ต้นเดือน 00:00 → สิ้นเดือน 23:59 · รหัสพนักงานขาย = รวม
    // ────────────────────────────────────────────────────────
    var sfFp = null;
    function salesForecastOpen(){
        if (!sfFp) {
            var opt = {
                enableTime: true, time_24hr: true, dateFormat: 'd/m/Y H:i',
                allowInput: true, static: true, disableMobile: true
            };
            sfFp = { from: flatpickr('#sf_from', opt), to: flatpickr('#sf_to', opt) };
        }
        var now = new Date();
        sfFp.from.setDate(new Date(now.getFullYear(), now.getMonth(), 1, 0, 0), false);
        sfFp.to.setDate(new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59), false);
        $('#sf_sale').val('');
        $('#salesForecastModal').modal('show');
    }
    function salesForecastPrint(kind){
        if (kind !== 'order') {
            Swal.fire({ icon: 'info', title: 'ยังไม่เปิดใช้งาน', text: 'รายงานนี้ยังไม่ได้ทำ', target: '#salesForecastModal', heightAuto: false });
            return;
        }
        var from = sfFp.from.selectedDates[0], to = sfFp.to.selectedDates[0];
        if (!from || !to) {
            Swal.fire({ icon: 'warning', title: 'กรุณาเลือกช่วงวันที่-เวลา', target: '#salesForecastModal', heightAuto: false });
            return;
        }
        if (from > to) {
            Swal.fire({ icon: 'warning', title: 'ช่วงวันที่ไม่ถูกต้อง', text: 'วันที่เริ่มต้องไม่มากกว่าวันที่สิ้นสุด', target: '#salesForecastModal', heightAuto: false });
            return;
        }
        var q = { sale: $('#sf_sale').val() || '', from: $('#sf_from').val(), to: $('#sf_to').val() };
        window.open('{{ url('order/sales-forecast/order-pdf') }}?' + $.param(q), '_blank');
    }

    // ────────────────────────────────────────────────────────
    //  DataTable filter machinery
    // ────────────────────────────────────────────────────────
    function collectSearchData(){
        var data = {};
        $('.p_search').each(function(){
            var v = $(this).val();
            if (v !== '' && v !== null) data[$(this).attr('name')] = v;
        });
        return data;
    }

    function updateFilterButtonState(){
        var count = 0;
        $('.p_search:not([name="limit"]):not([name="sort_col"]):not([name="sort_dir"])').each(function(){
            var v = $(this).val();
            if (v !== '' && v !== null) count++;
        });
        var $btn = $('#btnResetFilters');
        if (count > 0) { $btn.removeClass('btn-label-secondary').addClass('btn-danger'); $btn.find('.filter-count').text('(' + count + ')'); }
        else           { $btn.removeClass('btn-danger').addClass('btn-label-secondary'); $btn.find('.filter-count').text(''); }

        renderFilterSummary();
    }

    // ── รายละเอียดการค้นหา (โชว์ตอนพับตัวกรอง) — ป้ายชื่อ FILTER_LABELS ประกาศไว้ต้นสคริปต์ ──
    // escape ค่าที่ผู้ใช้พิมพ์ก่อนยัดลง HTML (กัน XSS จากคำค้น)
    function escHtml(s){ return $('<div>').text(s == null ? '' : s).html(); }

    function renderFilterSummary(){
        var chips = [];
        $('.p_search:not([name="limit"]):not([name="sort_col"]):not([name="sort_dir"])').each(function(){
            var label = FILTER_LABELS[$(this).attr('name')];
            if (!label) return;
            // ตัดสินว่า "ไม่ได้กรอง" จาก value เสมอ — ตัวเลือก "ทั้งหมด" มี value ว่างแต่มีข้อความ
            var raw = $(this).val();
            if (raw === '' || raw === null) return;
            // select: แสดงข้อความของตัวเลือก ไม่ใช่ value
            var val = $(this).is('select') ? $(this).find('option:selected').text().trim() : raw;
            chips.push('<span class="badge bg-label-primary fw-normal">'
                + '<span class="text-dark fw-medium">' + escHtml(label) + ':</span> '
                + escHtml(val) + '</span>');
        });
        $('#filterSummary').html(chips.join(''));   // ไม่มีตัวกรอง = ปล่อยว่าง
    }

    // หมุนลูกศรตามสถานะพับ/กาง + ซ่อนแถบสรุปตอนกาง (ข้างในเห็นค่าจริงอยู่แล้ว)
    $(document).on('show.bs.collapse hide.bs.collapse', '#orderFilterBox', function(e){
        $('#btnToggleFilters .toggle-caret')
            .toggleClass('ti-chevron-down', e.type === 'hide')
            .toggleClass('ti-chevron-up',   e.type === 'show');
        $('#filterSummary').toggleClass('d-none', e.type === 'show');
    });

    // กัน AJAX race: รับเฉพาะผลของ request ล่าสุด
    function loadData(pages){
        updateFilterButtonState();
        searchData = collectSearchData();
        page = pages;
        var seq = ++dtSeq;
        if (dtXhr) dtXhr.abort();
        showTableLoading();   // server ช้า — บอกผู้ใช้ว่ากำลังดึงข้อมูล (16/09/2569)
        dtXhr = $.ajax({
            type: "GET", url: pages, data: searchData,
            success: function(data){ if (seq === dtSeq) $("#table-data").html(data); },
            error: function(xhr, status){
                if (seq !== dtSeq || status === 'abort') return;   // request เก่าถูกตัดทิ้ง = ปกติ
                showTableError();
            },
            complete: function(){ if (seq === dtSeq) dtXhr = null; }
        });
    }

    function resetFilters(){
        // ไม่ล้าง limit + sort_col/sort_dir (เป็นการตั้งค่าแสดงผล ไม่ใช่ตัวกรอง)
        $('.p_search:not([name="limit"]):not([name="sort_col"]):not([name="sort_dir"])').each(function(){
            if (this._flatpickr) this._flatpickr.clear();
            else $(this).val('');
        });
        loadData("{{ $page_url }}/datatable");
    }
</script>
</body>

</html>
