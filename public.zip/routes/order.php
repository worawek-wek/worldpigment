<?php

use App\Http\Controllers\OrderController;
use App\Http\Controllers\OrderApprovalController;
use App\Http\Controllers\PriceApprovalController;
use App\Http\Controllers\SalesForecastController;

Route::prefix('order')->group(function () {

    // ─── หน้า + ตารางรายการ ──────────────────────────────────────────
    Route::get('/',          [OrderController::class, 'index'])->name('order.index');
    Route::get('/datatable', [OrderController::class, 'datatable'])->name('order.datatable');

    // ─── ฟอร์มบันทึกใบสั่งซื้อ (อ่านข้อมูลมาเติมฟอร์ม) ──────────────────
    // ใช้ query string ?orderno= เพราะเลขที่ใบสั่งเก่าบางตัวมีช่องว่าง/อักขระแปลก
    Route::get('/form', [OrderController::class, 'form'])->name('order.form');

    // ─── Lookup ที่ฟอร์มเรียกระหว่างกรอก ─────────────────────────────
    Route::get('/customer/{code}', [OrderController::class, 'customerLookup'])->name('order.customer_lookup');
    Route::get('/price-info',      [OrderController::class, 'priceInfo'])->name('order.price_info');
    Route::get('/next-orderno',    [OrderController::class, 'nextOrderno'])->name('order.next_orderno');
    Route::get('/item-lookup',     [OrderController::class, 'itemLookup'])->name('order.item_lookup');
    // ฟอร์มตรวจราคาเม็ด CP ก่อนบันทึก — ค่าที่เคยบันทึกไว้ใน cp_itemprice (16/10/2569)
    Route::get('/cp-price',        [OrderController::class, 'cpPrice'])->name('order.cp_price');

    // ─── บันทึก (สร้างใหม่ / แก้ไข) ───────────────────────────────────
    Route::post('/save', [OrderController::class, 'save'])->name('order.save');

    // ปุ่ม "เพิ่มใบสั่งซื้อใหม่" ในฟอร์ม — สร้างใบสั่งซื้อทันที (12/09/2569)
    Route::post('/create', [OrderController::class, 'create'])->name('order.create');

    // ปุ่ม "+ เพิ่ม" ข้างช่องสถานที่ส่ง — เขียนลง naddress ของลูกค้ารายนั้น (19/09/2569)
    Route::post('/dvpoint', [OrderController::class, 'addDvpoint'])->name('order.dvpoint_add');

    // ─── ประมาณการยอดขาย ตามรหัสพนักงานขาย (ฟอร์ม Access "SaleOrder", 15/10/2569) ───
    Route::get('/sales-forecast/order-pdf', [SalesForecastController::class, 'orderPdf'])->name('order.salesforecast.order_pdf');

    // ─── ฟอร์มขออนุมัติราคาพิเศษ (MD) — ฟอร์มลูกของเมนูนี้ ─────────────
    Route::prefix('price-approval')->group(function () {
        Route::get('/items',           [PriceApprovalController::class, 'items'])->name('order.approval.items');
        // ใบที่ยังไม่อนุมัติทั้งหมด — ตัวเดินระเบียนบนหัวฟอร์ม (12/09/2569)
        Route::get('/pending',         [PriceApprovalController::class, 'pending'])->name('order.approval.pending');
        Route::get('/data',            [PriceApprovalController::class, 'data'])->name('order.approval.data');
        Route::get('/other-items',     [PriceApprovalController::class, 'otherItems'])->name('order.approval.other_items');
        // พิมพ์ประวัติการขออนุมัติราคาของเบอร์ที่กรอก — ทุกลูกค้า ทั้งอนุมัติและไม่อนุมัติ (12/09/2569)
        Route::get('/other-items-pdf', [PriceApprovalController::class, 'otherItemsPdf'])->name('order.approval.other_items_pdf');
        Route::get('/other-customers', [PriceApprovalController::class, 'otherCustomers'])->name('order.approval.other_customers');
        // พิมพ์ประวัติการขออนุมัติราคาของลูกค้ารายนี้ — ทุกเบอร์ ทั้งอนุมัติและไม่อนุมัติ (12/09/2569)
        Route::get('/customer-history-pdf', [PriceApprovalController::class, 'customerHistoryPdf'])->name('order.approval.customer_history_pdf');
        Route::get('/history',         [PriceApprovalController::class, 'history'])->name('order.approval.history');
        // พิมพ์ประวัติของเบอร์นี้เป็น PDF ตามผังรายงานกระดาษเดิม (12/09/2569)
        Route::get('/history-pdf',     [PriceApprovalController::class, 'historyPdf'])->name('order.approval.history_pdf');
        Route::get('/resin-history',   [PriceApprovalController::class, 'resinHistory'])->name('order.approval.resin_history');
        // ปุ่ม "พิมพ์" ท้ายฟอร์ม — รายการที่อนุมัติราคาแล้วใน 3 วันล่าสุด (12/09/2569)
        Route::get('/approved-pdf', [PriceApprovalController::class, 'approvedRecentPdf'])->name('order.approval.approved_pdf');
        // พิมพ์ประวัติราคาเม็ด CP ของเบอร์นี้ (ทุกลูกค้า) เป็น PDF (12/09/2569)
        Route::get('/resin-history-pdf', [PriceApprovalController::class, 'resinHistoryPdf'])->name('order.approval.resin_history_pdf');

        // โหมดอนุมัติ (MD) — ปลดล็อกด้วยรหัสผ่านก่อนจึงจะติ๊ก "อนุมัติ" ได้
        Route::get('/md-state', [PriceApprovalController::class, 'mdState'])->name('order.approval.md_state');
        Route::post('/unlock',  [PriceApprovalController::class, 'unlock'])->name('order.approval.unlock');
        Route::post('/lock',    [PriceApprovalController::class, 'lock'])->name('order.approval.lock');

        Route::post('/save',   [PriceApprovalController::class, 'save'])->name('order.approval.save');
        Route::post('/delete', [PriceApprovalController::class, 'destroy'])->name('order.approval.delete');
    });

    // ─── ฟอร์มอนุมัติใบสั่งซื้อ (morderAPPV) ────────────────────────
    Route::prefix('order-approval')->group(function () {
        Route::get('/queue',  [OrderApprovalController::class, 'queue'])->name('order.orderappv.queue');
        Route::get('/record', [OrderApprovalController::class, 'record'])->name('order.orderappv.record');

        // กดอนุมัติ / ยกเลิกอนุมัติ — เขียน morder.appv + morder.appvDT
        Route::post('/approve', [OrderApprovalController::class, 'approve'])->name('order.orderappv.approve');

        // ปุ่ม "พิมพ์รายการที่อนุมัติวันนี้" — รายงานผลิตภัณฑ์ที่ต้องผลิต (P) ของใบที่อนุมัติวันนี้ (06/10/2569)
        Route::get('/approved-today-pdf', [OrderApprovalController::class, 'approvedTodayPdf'])->name('order.orderappv.approved_today_pdf');
    });

});
