<?php

use App\Http\Controllers\ColorMatchingController;

Route::prefix('color-matching')->group(function () {

    // ─── หน้า + datatable + summary ──────────────────────────────────
    Route::get('/',          [ColorMatchingController::class, 'index'])->name('color_matching.index');
    Route::get('/datatable', [ColorMatchingController::class, 'datatable'])->name('color_matching.datatable');
    Route::get('/summary',   [ColorMatchingController::class, 'getSummary'])->name('color_matching.summary');

    // ─── Lookup ลูกค้า (ต้องอยู่ก่อน /{sendno} เพราะ .+ จับ slash ได้) ───
    Route::get('/customer/{code}',     [ColorMatchingController::class, 'customerLookup'])->name('color_matching.customer_lookup');

    // ─── Lookup record CM จาก SendNo (ฟอร์มใบส่ง ต.ย. → เลขอ้างอิง) ───
    // ใช้ query string (?sendno=) เพราะ SendNo มี "/" (เช่น 69/0143) — Apache บล็อก %2F ใน path (404)
    Route::get('/ref',                 [ColorMatchingController::class, 'lookupBySendNo'])->name('color_matching.ref');

    // ─── รายละเอียด (อ่านอย่างเดียว) — อ้างอิงด้วย id ───
    Route::get('/detail/{id}',         [ColorMatchingController::class, 'detail'])->whereNumber('id')->name('color_matching.detail');

    // ─── CRUD (อ้างอิงด้วย id auto-increment) ────────────────────────
    Route::post('/insert',             [ColorMatchingController::class, 'insert'])->name('color_matching.insert');
    Route::post('/update/{id}',        [ColorMatchingController::class, 'update'])->whereNumber('id')->name('color_matching.update');
    Route::post('/delete/{id}',        [ColorMatchingController::class, 'destroy'])->whereNumber('id')->name('color_matching.delete');
    // ผลการทดสอบตัวอย่างสี ของใบส่ง ต.ย. (10/08/2569) — แตะเฉพาะ TyResp/Resp/Respdate
    Route::post('/result/{id}',        [ColorMatchingController::class, 'saveResult'])->whereNumber('id')->name('color_matching.result');
    Route::get('/{id}',                [ColorMatchingController::class, 'edit'])->whereNumber('id')->name('color_matching.edit');

});
